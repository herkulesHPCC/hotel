<?php
class ControllerCatalogwkhotelbookingexport extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		if($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()){
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$results = $this->model_catalog_wk_hotelbooking_hotels->exportHistory($this->request->post['product_id'],$this->request->post['from'],$this->request->post['to']);
			if(empty($results)){
				$this->session->data['error']= $this->language->get('error_no_slot');
				$this->response->redirect($this->url->link('catalog/wk_hotelbooking_res_booking','&user_token=' . $this->session->data['user_token'].'&id='.$this->request->post['product_id']  , 'true'));
			}
			if($this->request->post['format']==1)
				$this->exportXLS($results);
			else
				$this->exportCSV($results);

		}
	}

	public function validate(){
				$this->language->load('catalog/wk_hotelbooking_hotels');
				$difference = strtotime($this->request->post['to']) - strtotime($this->request->post['from']);
				if($difference<0){
					$this->session->data['error']= $this->language->get('error_invalid_date');
					$this->response->redirect($this->url->link('catalog/wk_hotelbooking_res_booking','&user_token=' . $this->session->data['user_token'].'&id='.$this->request->post['product_id'] , 'true'));
				} else {
					return true;
				}
	}

	public function exportXLS($results) {
		$data=array();

		foreach($results as $result) {
			    $data[] = array(
			    'Customer' =>$result['customer_name'],
			    'Email' => $result['customer_email'],
			    'Telephone' =>$result['customer_telephone'],
			    'Quantity' =>$result['quantity'],
			    'From'   => $result['start_day'],
			    'Till' =>$result['end_day']
			    );

		}
		function filterData(&$str) {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", "\\n", $str);
        if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
   		 }
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache");
		header("Expires: 0");
		header("Content-Type: application/xls");
		header("Content-Disposition: attachment; filename=Booking_XLS-".date('d-m-Y').".xls");
		$sep = "\t\t";
		$flag=false;
    foreach($data as $row) {
        if(!$flag) {
            // display column names as first row
            echo implode("\t", array_keys($row)) . "\n";
            $flag = true;
        }
        // filter data
        array_walk($row, 'filterData');
        echo implode("\t", array_values($row)) . "\n";
    }

	}
	public function exportCSV($results) {
		$data=array();
		$data[] = array(
				'Customer' =>'Customer Name',
			    'Email' =>'Customer Email',
			    'Telephone' =>'Customer Telephone',
			    'Quantity' =>'Quantity',
			    'From'   => 'From',
			    'Till' =>'Till'
			);
		foreach($results as $result) {
			    $data[] = array(
			    'Customer' =>$result['customer_name'],
			    'Email' =>$result['customer_email'],
			    'Telephone' =>$result['customer_telephone'],
			    'Quantity' =>$result['quantity'],
			    'From'   => $result['start_day'],
			    'Till' =>$result['end_day']

			    );

		}
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache");
		header("Expires: 0");
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=Booking_CSV-".date('d-m-Y').".csv");
		$output = fopen("php://output", "w");
		foreach($data as $row) {
			 fputcsv($output, $row);
		}


	}

}
