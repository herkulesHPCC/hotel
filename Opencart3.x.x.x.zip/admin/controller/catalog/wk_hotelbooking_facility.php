<?php

class ControllerCatalogWkhotelbookingfacility extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('facility_heading_title'));
		$this->getList();
	}
	public function getList() {
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('facility_heading_title'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_facility', '&user_token=' . $this->session->data['user_token'] , 'true'),
   		);
   		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}
		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}
		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}
		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}
		if(isset($this->request->get['type'])){
			$data['type'] = $type = $this->request->get['type'];
		}else{
			$type = null;
		}
		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'name'	=> $name,
				'order'	=> $order,
				'status'	=> $status,
				'start'	=> $start,
				'end'	=> $end,
				'type'  =>$type
				);
   		$facility = $this->model_catalog_wk_hotelbooking_hotels->getFacilities($filterValues);
   		$facility_total = $this->model_catalog_wk_hotelbooking_hotels->getTotalFacilities($filterValues);
   		$data['facility'] =array();
   		$this->load->model('tool/image');
   		$this->load->model('customer/customer');

   		if(!empty($facility)) {

	   		foreach ($facility as $result) {
	   			if($result['owner']) {
					$owner_name = $this->model_customer_customer->getCustomer($result['owner']);
					if($owner_name && isset($owner_name['firstname'])) {
						$owner_name = $owner_name['firstname'].' '.$owner_name['lastname'];
						$approve_action = true;
					}
					else {
						$owner_name = 'Admin';
						$approve_action = false;
					}
				} else {
					$owner_name = 'Admin';
					$approve_action = false;
				}
				if (is_file(DIR_IMAGE.$result['facility_image'])) {
					$image = $this->model_tool_image->resize($result['facility_image'], 40, 40);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 40, 40);
				}
				$data['facility'][] = array(
					'facility_ocid' =>$result['facility_ocid'],
					'facility_id' => $result['facility_id'],
					'image'      => $image,
					'name'       => $result['facility_name'],
					'status'  	 => $result['status'],
					'sort_order' => $result['sort_order'],
					'owner_name'  => $result['owner'],
					'approve'		 => $approve_action,
					'edit'       => $this->url->link('catalog/wk_hotelbooking_facility/edit', 'user_token=' . $this->session->data['user_token'] . '&facility_id=' . $result['facility_id'].'&facility_ocid='.$result['facility_ocid'], true)
				);
			}
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		$pagination = new Pagination();
		$pagination->total = $facility_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'] . '&page={page}', 'true');

		$data['results'] = sprintf($this->language->get('text_pagination'), ($facility_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($facility_total- $this->config->get('config_limit_admin'))) ? $facility_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $facility_total, ceil($facility_total / $this->config->get('config_limit_admin')));

		$data['pagination'] = $pagination->render();
		$data['user_token'] = $this->session->data['user_token'];
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['add']	=	$this->url->link('catalog/wk_hotelbooking_facility/add', 'user_token='.$this->session->data['user_token'],true);
		$data['delete']	=	$this->url->link('catalog/wk_hotelbooking_facility/delete', 'user_token='.$this->session->data['user_token'],true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_facility',$data));
	}

	public function add() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('facility_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {

			$this->request->post['facility_ocid'] =  $this->addToOc($this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->addFacility($this->request->post,1);

			$this->session->data['success'] = $this->language->get('text_facility_add_success');
			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'] , true));
		}
		$this->getForm();
	}
	public function edit() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('facility_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {


			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 2;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = $this->request->post['name'];
			}

			$this->updateToOc($this->request->get['facility_ocid'],$name,$this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->editFacility($this->request->get['facility_ocid'], $this->request->post,1);

			$this->session->data['success'] = $this->language->get('text_facility_edit_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getForm();
	}
	public function getForm() {
		$data['text_form'] = !isset($this->request->get['facility_ocid']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$this->load->model('catalog/wk_hotelbooking_hotels');
		if(isset($this->request->get['facility_ocid'])) {
			$facility_info =  $this->model_catalog_wk_hotelbooking_hotels->getFacility($this->request->get['facility_ocid']);
		}
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['facility_name']){
			$data['name'] = $facility_info['facility_name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['sort_order']){
			$data['sort_order'] = $facility_info['sort_order'];
		} else {
			$data['sort_order'] = '';
		}
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['status']){
			$data['status'] = $facility_info['status'];
		}  else {
			$data['status'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE. $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
			$data['image'] = $this->request->post['image'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['facility_image'] && is_file(DIR_IMAGE .$facility_info['facility_image'] )){
			$data['thumb'] = $this->model_tool_image->resize($facility_info['facility_image'] , 100, 100);
			$data['image'] = $facility_info['facility_image'];
		}  else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['image'] = '';
		}
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('facility_heading_title'),
			'href' => $this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['cancel'] = $this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'] , true);
		if (!isset($this->request->get['facility_id'])) {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_facility/add', 'user_token=' . $this->session->data['user_token'], true);
		} else {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_facility/edit', 'user_token=' . $this->session->data['user_token'] .'&facility_id='.$this->request->get['facility_id'].'&facility_ocid='.$this->request->get['facility_ocid'] , true);
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_facility_form', $data));
	}

	public function delete() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/attribute');
		$this->load->model('catalog/wk_hotelbooking_hotels');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {

			foreach ($this->request->post['selected'] as $attribute_id) {

				$this->model_catalog_attribute->deleteAttribute($attribute_id);

				$this->model_catalog_wk_hotelbooking_hotels->deleteFxFacility($attribute_id);
			}

			$this->session->data['success'] = $this->language->get('text_facility_delete_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_facility', 'user_token=' . $this->session->data['user_token'] , true));
		}

		$this->getList();
	}
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_facility')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		$this->load->model('catalog/product');
		foreach ($this->request->post['selected'] as $attribute_id) {
			$product_total = $this->model_catalog_product->getTotalProductsByAttributeId($attribute_id);

			if ($product_total) {
				$this->error['warning'] = sprintf($this->language->get('error_attribute_delete'), $product_total);
			}
		}

		return !$this->error;
	}
	public function validate() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_facility')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if(!trim($this->request->post['name'])) {
			$this->error['warning'] = $this->language->get('error_name');
		}
		return !$this->error;
	}


	public function deleteFromOc($facility_type,$id,$data) {
			$this->load->model('catalog/attribute');
			$this->model_catalog_attribute->deleteAttribute($id);
	}
	public function updateToOc($id,$name,$data) {
				//Update facilitiy as attribute
				$attribute_info = array(
					'attribute_group_id' => $this->config->get('wk_hotelbookingattr_attrgroupid'),
					'sort_order' => $data['sort_order'],
					'attribute_description' => $name,
					);
				$this->load->model('catalog/attribute');

				 $this->model_catalog_attribute->editAttribute($id,$attribute_info);

	}
	public function addToOc($add_data) {
			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 2;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = $add_data['name'];
				$option_name[$language['language_id']]['name'] = 'Hotel Management';
			}
			$attribute_info = array(
				'attribute_group_id' => $this->config->get('wk_hotelbookingattr_attrgroupid'),
				'sort_order' => $sort_order,
				'attribute_description' => $name,
			);
			$this->load->model('catalog/attribute');

			$facility_ocid = $this->model_catalog_attribute->addAttribute($attribute_info);
			return $facility_ocid;
	}
	public function approve(){
		$this->load->language('catalog/wk_hotelbooking_hotels');
			if($this->request->server['REQUEST_METHOD'] == "POST" && $this->request->post['facility_ocid']) {
				$json = array();
				$this->load->model('catalog/wk_hotelbooking_hotels');
				$this->model_catalog_wk_hotelbooking_hotels->approveFixed($this->request->post['facility_ocid']);
				$json['success'] = $this->language->get("text_fxfac_success");
			}
		if(isset($json) && $json['success']) {
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));

		}
	}
}
?>
