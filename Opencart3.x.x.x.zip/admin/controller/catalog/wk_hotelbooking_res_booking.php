<?php
class ControllerCatalogwkhotelbookingresbooking extends Controller {

	private $error = array();

	public function index() {
		$this->language->load('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('booking_information'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		$this->getList();
  	}


	protected function getList() {


		$id = 0;
		if(isset($this->request->get['id'])){
			$id = $this->request->get['id'];
			$data['product_id'] =$id;
		}

		$this->load->model('catalog/wk_hotelbooking_hotels');

		$this->language->load('catalog/wk_hotelbooking_hotels');

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
					'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('booking_information'),
					'href'      => $this->url->link('catalog/wk_hotelbooking_res_booking','&user_token=' . $this->session->data['user_token'] , 'true'),
      		'separator' => ' :: '
   		);
   		if(isset($this->request->get['name'])){
		$name = $this->request->get['name'];
		}else{
			$name = null;
		}

		if(isset($this->request->get['from'])){
		 $from = $this->request->get['from'];
		}else{
			$from = null;
		}

		if(isset($this->request->get['to'])){
			$to = $this->request->get['to'];
		}else{
			$to = null;
		}
		if(isset($this->request->get['email'])){
			$email= $this->request->get['email'];
		}else{
			$email = null;
		}
		if(isset($this->request->get['telephone'])){
			$telephone= $this->request->get['telephone'];
		}else{
			$telephone = null;
		}

		$this->document->addStyle('view/stylesheet/wk_booking_res/jquery-ui-1.10.4.custom.css');
		$this->document->addStyle('view/javascript/wk_booking_res/jquery-ui.css');
		$this->document->addScript('view/javascript/wk_booking_res/jquery-ui-1.10.4.custom.js');

		$data['back'] = $this->url->link('catalog/wk_hotelbooking_res', '&user_token=' . $this->session->data['user_token'] , 'true');
		$data['export'] = $this->url->link('catalog/wk_hotelbooking_export','&user_token=' . $this->session->data['user_token'].'&id='.$id , 'true');

		$data['questionarray'] = array();

		$questionarray = array();

		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
	 		'name'	=> $name,
	 		'from'	=> $from,
	 		'to'	=> $to,
	 		'email'	=> $email,
	 		'telephone'	=> $telephone,
			'start'	=> $start,
			'limit'	=> $end,
	 	);

		if(isset($this->session->data['error'])){
			$data['error'] = $this->session->data['error'];
			unset($this->session->data['error']);
		}

		$results = $this->model_catalog_wk_hotelbooking_hotels->viewtotalbookings($id,$filterValues);
		$results_total = $this->model_catalog_wk_hotelbooking_hotels->viewtotalbookingsCount($id,$filterValues);

		$data['column_quantity'] = $this->language->get('column_quantity');
        foreach ($results as $result) {
		       $data['result_book'][] = array(
						'selected'=>False,
						'order_id' => $result['order_id'],
						'firstname' => $result['customer_name'],
						'lastname' => '',
						'email' => $result['customer_email'],
						'telephone' => $result['customer_telephone'],
						'from' => $result['start_day'],
						'to' => $result['end_day'],
						'status' => $result['status'],
						'quantity' => $result['quantity'],
						'cancel' => $this->url->link('catalog/wk_hotelbooking_res_booking/cancel','user_token='.$this->session->data['user_token'].'&order_id='.$result['order_id'].'&id='.$this->request->get['id'],'true')
					);
			}
		$data['sub_heading_title']='Booking And Reservation';
 		$data['user_token'] = $this->session->data['user_token'];

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];

			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$pagination = new Pagination();
		$pagination->total = $results_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/wk_hotelbooking_res_booking', 'user_token=' . $this->session->data['user_token'] . '&id='.(int)$id.'&page={page}', 'true');

		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($results_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($results_total - $this->config->get('config_limit_admin'))) ? $results_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $results_total, ceil($results_total / $this->config->get('config_limit_admin')));

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_res_booking',$data));
  	}


  	public function cancel() {
    	$this->language->load('catalog/wk_hotelbooking_res_booking');

    	$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		$order_id = $this->request->get['order_id'];
		if($this->validateForm()) {
				$this->model_catalog_wk_hotelbooking_hotels->cancelBooking($order_id);
		}
		$this->session->data['success'] = $this->language->get('text_success_cancel');
		$this->response->redirect($this->url->link('catalog/wk_hotelbooking_res_booking', 'user_token=' . $this->session->data['user_token'] .'&id='.$this->request->get['id'], 'true'));
  	}


	private function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_res_booking')) {
			$this->session->data['error_warning'] = $this->language->get('error_warning');
		}

		if (!$this->session->data['error_warning']) {
				return true;
		} else {
			return false;
		}
		}
}
?>
