<?php
//query
// Heading
$_['heading_title']							= 'Hosts Query';
$_['query_heading_title']     				= 'queries';

// Text
$_['text_query_success']      				= 'Success: You have modified queries!';
$_['text_query_list']         				= 'Host Query List';

$_['text_query_edit']         				= 'Edit Host Query';

// Column
$_['column_query_product']    				= 'Host';
$_['column_query_author']     				= 'Author';
$_['column_query_rating']     				= 'Rating';
$_['column_query_status']     				= 'Status';
$_['column_date_added'] 	   				= 'Date Added';
$_['column_action']     	   				= 'Action';

$_['column_owner']							= 'Owner';
$_['column_author']   = 'Author';
$_['column_seller']   = 'Host';
$_['column_status'] ='Status';
// Entry
$_['entry_query_product']     				= 'Host';
$_['entry_query_author']      				= 'Author';
$_['entry_rating']      	   				= 'Rating';
$_['entry_query_status']     				= 'Status';
$_['entry_query_text']        				= 'Text';
$_['entry_date_added']  	   				= 'Date Added';
$_['entry_subject']			   				= 'Subject';

$_['entry_text']							= 'Query';
$_['entry_status']							= 'Status';

$_['entry_price']							= 'Price';
$_['entry_value']							= 'Value';
$_['entry_quality']							= 'Quality';
$_['error_subject']							= 'Subject can not be empty';
$_['error_text']							= 'Query can not be empty';

$_['column_subject']						= 'Subject';
$_['text_query_delete_success']				= 'Query Deleted Successfully';
$_['tab_modify']              = 'Modify';
$_['tab_info']                ='Information';
$_['text_hotel']			 = 'Hotel';
$_['text_from']				 = 'From';
$_['text_till']				 = 'Till';
$_['text_ask'] 	  			  = 'Message';
$_['text_customer_name'] 	  = 'Customer';
$_['text_id']       		  = 'Query Id';
$_['text_product_name']    	  = 'Room';
$_['error_permission']         = 'Warning: You do not have permission to modify Query!';
?>
