<?php
// Heading Goes here:
$_['heading_title']      	  		= 'Advanced Layer Navigation';
$_['module_version']      	  		= 'Version 1.0.0.0';


// Text
$_['text_module']     	 	  		= 'Modules';
$_['text_success']    	 	  		= 'Success: You have modified module Advanced Layer Navigation !';
$_['entry_layer_status']     		= 'Module Status';
$_['text_enabled']			  		= 'Enabled';
$_['text_disabled']			  		= 'Disabled';
$_['entry_selectall']			  		= 'Select All';
$_['entry_deselectall']			  		= 'Diselect All';

$_['entry_attribute_group_list'] 	= 'Attribute Group List';
$_['entry_category_list'] 			= 'Show in Categories';
$_['text_categories'] 			    = 'Select Categories';

$_['text_attribute_group']    	  	= 'Select Group';

$_['tab_general']    	      		= 'General';
$_['tab_module_version']      		= 'Version-Info';
$_['entry_version']    	      		= 'Module Version';

$_['help_category_list']    	    = 'Module Version';


$_['button_save'] 			  		= 'Save';
$_['button_cancel']           		= 'Cancel';

$_['text_extension'] = 'Extension';
// Error

$_['error_warning']  	  			= ' Warning: Select all neccessary fields!! ';
$_['error_price']  	  				= 'Warning: You have to select the Price Attribute with min and max value! ';
$_['error_permission']  	  		= 'Warning: You do not have permission to modify module Advanced Layer Navigation ';
?>
