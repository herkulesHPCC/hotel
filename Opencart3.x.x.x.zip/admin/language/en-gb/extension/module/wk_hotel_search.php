<?php
// Heading
$_['heading_title']    = 'Marketplace Hotel Search';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified  Marketplace Hotel Search module!';
$_['text_edit']        = 'Edit Marketplace Hotel Search Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Marketplace hotel search module!';
