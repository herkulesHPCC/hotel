<?php
class ModelCustomerpartnerquery extends Model {
	/**
 * [getTotalQueries number of allreview]
 * @param  array  $data [filter values]
 * @return [int]       [number of all reviewws according to the filter value]
 */
  public function getTotalQueries($data = array()) {

    $sql = "SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,chq.* FROM " . DB_PREFIX . "customerpartner_hotel_query chq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = chq.customer_id) WHERE chq.id!='' ";

    // if (!empty($data['filter_product'])) {
    //   $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    // }

    // if (!empty($data['filter_author'])) {
    //   $sql .= " CONCAT(c.firstname, ' ', c.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
    // }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND c.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(chq.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $query = $this->db->query($sql);

    return count($query->rows);
  }
  /**
 * [getQueries array of all reviews]
 * @param  array  $data [filter values]
 * @return [array]       [details of all reviews]
 */
  public function getQueries($data = array()) {

     $sql = "SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,chq.* FROM " . DB_PREFIX . "customerpartner_hotel_query chq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = chq.customer_id) WHERE chq.id!='' ";

    // if (!empty($data['filter_product'])) {
    //   $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    // }
 	// if (!empty($data['filter_author'])) {
  //     $sql .= " AND c.nickname LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
  //   }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND chq.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(chq.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $sort_data = array(
      //'c.name',
      'chq.status',
      'chq.date_added'
    );

    if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
      $sql .= " ORDER BY " . $data['sort'];
    } else {
      $sql .= " ORDER BY chq.date_added";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
    }

    $query = $this->db->query($sql);
   
   
    return $query->rows;
  }

  /**
 * [query information about particular ]
 * @param  [int] $_id [ id of ]
 * @return [array]            [details of  in array]
 */
  public function getQuery($id) {
    $query = $this->db->query("SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,chq.* FROM " . DB_PREFIX . "customerpartner_hotel_query chq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = chq.customer_id) WHERE id = '" . (int)$id . "'");

    return $query->row;
  }
  /**
 * [edit update the existing ]
 * @param  [int] $id [ id ]
 * @param  [array] $data      [details of ]
 */
  public function editQuery($id, $data) {
    $this->db->query("UPDATE ".DB_PREFIX."customerpartner_hotel_query SET status = '".(int)$data['status']."',message = '".$this->db->escape($data['query'])."',subject ='".$this->db->escape($data['subject'])."' WHERE id ='".(int)$id."'");
  }
  /**
 * [delete delete particular  by  id]
 * @param  [int] $id [ id which is to be delete]
 */
  public function deleteQuery($id) {
    $this->db->query("DELETE FROM " . DB_PREFIX . "customerpartner_hotel_query WHERE id = '" . (int)$id . "'");

  }

}
?>