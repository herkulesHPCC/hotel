<?php
class ModelExtensionModuleLayerNavigation extends Model {
		
	public function getAttributeGroups(){
		$results = $this->db->query("SELECT * FROM ".DB_PREFIX."attribute_group ag LEFT JOIN ".DB_PREFIX."attribute_group_description agd ON (ag.attribute_group_id = agd.attribute_group_id) WHERE agd.language_id = '".(int)$this->config->get('config_language_id')."' ")->rows;
		foreach ($results as $key => $value) {
			
			if(isset($value['name']) && (lcfirst($value['name']) == 'price' || lcfirst($value['name']) == 'manufacturer')){
				$results[$key] = $value;
			} else{
				unset($results[$key]);
			}
			
		}		
	
		return $results;
		
	}

	public function getGroup($data){

		$result = $this->db->query("SELECT * FROM ".DB_PREFIX."attribute_group ag LEFT JOIN ".DB_PREFIX."attribute_group_description agd ON (ag.attribute_group_id = agd.attribute_group_id) WHERE ag.attribute_group_id = '".(int)$data."' AND agd.language_id = '".(int)$this->config->get('config_language_id')."' ")->row;
		
		return $result;
		
	}

	public function getCategory($category_id) {
		$query = $this->db->query("SELECT c.sort_order, cd.name, c.category_id FROM ".DB_PREFIX."category c LEFT JOIN ".DB_PREFIX."category_description cd ON (c.category_id = cd.category_id) WHERE c.parent_id = '0' AND cd.language_id = '".(int)$this->config->get('config_language_id')."' AND c.category_id = '".(int)$category_id."' ORDER BY cd.name ASC ");

		return $query->row;
	}

	public function getCategories($data = array()) {

		$sql = "SELECT c.sort_order, cd.name, c.category_id FROM ".DB_PREFIX."category c LEFT JOIN ".DB_PREFIX."category_description cd ON (c.category_id = cd.category_id) WHERE c.parent_id = '0' AND cd.language_id = '".(int)$this->config->get('config_language_id')."' ";

		if (!empty($data['filter_name'])) {
			$sql .= " AND cd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY cd.category_id";

		$sort_data = array(
			'name',
			'sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY sort_order";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

}
?>
