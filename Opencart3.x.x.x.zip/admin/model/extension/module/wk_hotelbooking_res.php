<?php
class ModelExtensionModulewkhotelbookingres  extends Model {

	public function createTableReservation()
		{
			$this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "wk_hotel_details (
			                        `category_id` int(10) NOT NULL ,
			                        `status` int(2) NOT NULL ,
			                        `address` varchar(255) NOT NULL ,
			                        `email` varchar(50) ,
			                        `website` varchar(100) ,
			                        `contact` varchar(200) ,
			                        `faxno` varchar(50) ,
			                        `checkin` int(10) ,
			                        `checkin_ap` varchar(2) ,
			                        `checkout` int(10) ,
			                        `checkout_ap` varchar(2),
			                        `latitude` float(20) NOT NULL ,
			                        `longitude` float(20) NOT NULL,
			                        `owner` int(10),
															`approve` int(2), PRIMARY KEY (`category_id`)
						 								) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
			$this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "wk_hotel_facility (
															`id` int(10) NOT NULL AUTO_INCREMENT,
			                        `facility_id` int(10) NOT NULL ,
			                        `facility_name` varchar(20) NOT NULL ,
			                        `facility_image` varchar(50),
			                        `status` int(2) ,
			                        `sort_order` int(3) ,
			                        `facility_type` int(2) ,
			                        `facility_ocid` varchar(50),
			                        `owner` int(10),PRIMARY KEY (`id`)
						 								) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
			$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wk_hotel_room` (
								  `product_id` int(11) NOT NULL,
								  `quantity` int(11) NOT NULL,
								  `image` varchar(200) NOT NULL,
								  `status` int(2) NOT NULL,
								  `price` float(11) NOT NULL,
								  `max_adult` int(11) DEFAULT '1',
								  `max_child` int(11) NOT NULL,
								  `hotel_id` int(11) NOT NULL,
								  `start_from` date NOT NULL,
								  `till` date NOT NULL,
								  `owner` int(10),
									`approve` int(2),
								  PRIMARY KEY (`product_id`)
								) ENGINE=MyISAM  DEFAULT CHARSET=utf8");


			 $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wk_booking_slots` (
								  `id` int(11) NOT NULL AUTO_INCREMENT,
								  `product_id` int(11) NOT NULL,
								  `order_id` int(11) NOT NULL,
								  `start_day` date NOT NULL,
								  `end_day` date NOT NULL,
								  `quantity` int(11) NOT NULL,
								  `customer_name` varchar(255) CHARACTER SET utf8,
								  `customer_email` varchar(255) CHARACTER SET utf8,
								  `customer_telephone` varchar(30) CHARACTER SET utf8,
								  `ementies` varchar(200),
								  `status` int(2),
								  PRIMARY KEY (`id`)
								) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
			 $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wk_booking_quantity` (
								  `id` int(11) NOT NULL AUTO_INCREMENT,
								  `customer_id` int(11) NOT NULL,
								  `product_id` int(11) NOT NULL,
								  `quantity` int(11) NOT NULL,
								  `options` varchar(200) CHARACTER SET utf8 NOT NULL,
								  `session_id` varchar(200),
								  PRIMARY KEY (`id`)
								) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
			  $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wk_hotel_reviews` (
								  `id` int(11) NOT NULL AUTO_INCREMENT,
								  `customer_name` varchar(200),
								  `email` varchar(200),
								  `response` text,
								  `image` varchar(200),
								  `rating` int(2),
								  `date` date NOT NULL,
								  `status` int(2),
								  `hotel_id` int(11) NOT NULL,
								   PRIMARY KEY (`id`)
								)");
			   $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "wk_hotel_tab` (
								  `module` varchar(50),
								  `heading` text,
								  `description` longtext,
								  `language_id` int(2)
								)");


		}
public function createTablePartner(){

		//Table structure for table `customerpartner_to_customer`
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_customer` (
		  `customer_id` int(11) NOT NULL,
		  `is_partner` int(1) NOT NULL,
		  `screenname` varchar(255) NOT NULL,
		  `gender` varchar(255) NOT NULL,
		  `shortprofile` text NOT NULL,
		  `avatar` varchar(255) NOT NULL,
		  `twitterid` varchar(255) NOT NULL,
		  `paypalid` varchar(255) NOT NULL,
		  `country` varchar(255) NOT NULL,
		  `facebookid` varchar(255) NOT NULL,
		  `backgroundcolor` varchar(255) NOT NULL,
		  `companybanner` varchar(255) NOT NULL,
		  `companylogo` varchar(255) NOT NULL,
		  `companylocality` varchar(255) NOT NULL,
		  `countrylogo` varchar(1000) NOT NULL,
		  `otherpayment` text NOT NULL,
		  `commission` decimal(10,2) NOT NULL,
		  PRIMARY KEY (`customer_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1");
		//Table structure for table `customerpartner_to_product`
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_product` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `customer_id` int(100) NOT NULL,
		  `product_id` int(100) NOT NULL,
		  `price` float NOT NULL,
		  `seller_price` float NOT NULL,
		  `currency_code` varchar(11) NOT NULL,
		  `quantity` int(100) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;

		//Table structure for table `customerpartner_feedbacks`  LIVE
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_feedback` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `customer_id` smallint(6) NOT NULL,
		  `seller_id` smallint(6) NOT NULL,
		  `feedprice` smallint(6) NOT NULL,
		  `feedvalue` smallint(6) NOT NULL,
		  `feedquality` smallint(6) NOT NULL,
		  `nickname` varchar(255) NOT NULL,
		  `summary` text NOT NULL,
		  `review` text NOT NULL,
		  `createdate` datetime NOT NULL,
		  `status` int(2),
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;

		//Table structure for table `customerpartner_transaction`
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_transaction` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `customer_id` int(11) NOT NULL,
		  `order_id` varchar(500) NOT NULL,
		  `order_product_id` varchar(500) NOT NULL,
		  `amount` float NOT NULL,
		  `text` varchar(255) NOT NULL,
		  `details` varchar(255) NOT NULL,
		  `date_added` date NOT NULL DEFAULT '0000-00-00',
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;

		//Table structure for table `customerpartner_payment`
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_payment` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `customer_id` int(11) NOT NULL,
		  `amount` float NOT NULL,
		  `text` varchar(255) NOT NULL,
		  `details` varchar(255) NOT NULL,
		  `request_type` varchar(255) NOT NULL,
		  `paid` int(10) NOT NULL,
		  `balance_reduced` int(10) NOT NULL,
		  `payment` varchar(255) NOT NULL,
		  `date_added` date NOT NULL DEFAULT '0000-00-00',
		  `date_modified` date NOT NULL DEFAULT '0000-00-00',
		  `added_by` varchar(255) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;

		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_hotel_query` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `customer_id` int(11),
		  `seller_id` int(11),
		  `hotel_id` int(11),
		  `room_id` int(11),
		  `bfrom` date,
		  `bto` date,
		  `subject` varchar(5000),
		  `message` varchar(5000),
		  `status` int(2),
		  `date_added` date NOT NULL DEFAULT '0000-00-00',
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;


		//Table structure for table `customerpartner_mail` LIVE
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_mail` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `name` varchar(100) NOT NULL,
		  `subject` varchar(1000) NOT NULL,
		  `message` varchar(5000) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;
		$this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX ."customerpartner_to_order` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `order_id` int(11) NOT NULL,
		  `customer_id` int(11) NOT NULL,
		  `product_id` int(11) NOT NULL,
		  `order_product_id` int(100) NOT NULL,
		  `price` float NOT NULL,
		  `quantity` float(11) NOT NULL,
		  `payment` varchar(255) NOT NULL,
		  `payment_rate` float NOT NULL,
		  `admin` float NOT NULL,
		  `customer` float NOT NULL,
		  `commission_applied` decimal(10,2) NOT NULL,
		  `currency_code` varchar(10) NOT NULL,
		  `currency_value` decimal(15,8) NOT NULL,
		  `details` varchar(255) NOT NULL,
		  `paid_status` tinyint(1) NOT NULL,
		  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
		  `order_product_status` INT(10) NOT NULL,
		  `option_data` varchar(5000),
		  PRIMARY KEY (`id`)
		) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1") ;

}
public function deleteTableReservation() {
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_booking_quantity");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_booking_slots");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_hotel_room");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_hotel_facility");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_hotel_details");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_hotel_reviews");
	$this->db->query("DROP TABLE ".DB_PREFIX."wk_hotel_tab");
	$this->db->query("DELETE  FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'wk_hotelbooking_options' ");
}
public function deleteTablePartner() {
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_mail");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_payment");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_transaction");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_feedback");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_product");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_hotel_query");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_customer");
	// $this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_commission_category");
	$this->db->query("DROP TABLE ".DB_PREFIX."customerpartner_to_order");

}

public function addTabData($postData) {
	$this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_tab");
	if($postData) {
		foreach ($postData as $key => $value) {
			foreach ($value as $key1 => $value1) {
				$this->db->query("INSERT INTO ".DB_PREFIX."wk_hotel_tab SET module = '".$this->db->escape($key)."', heading = '".$this->db->escape($value1['heading'])."', description = '".$this->db->escape($value1['description'])."', language_id = '".(int)$key1."'");
			}
		}

	}

}
public function getTabData() {
	$retrun_result = array();
	$results = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_tab")->rows;

	foreach ($results as $key=>$result) {
			$retrun_result[$result['module']][$result['language_id']] = array(
				'heading'             => $result['heading'],
				'description'      => $result['description'],
			);
		}

	return $retrun_result;
}
}
?>
