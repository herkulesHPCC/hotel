<?php
class ControllerAccountCustomerpartnerDashboardsBooking extends Controller {

	public function index() {

		$lang_array= $this->load->language('account/customerpartner/dashboards/booking');
		foreach ($lang_array as $key => $value) {
			$data[$key] = $value;
		}
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_order'] = $this->language->get('text_order');
		$data['text_sale'] = $this->language->get('text_sale');
		$this->load->model('customerpartner/dashboard');
		$this->load->model('extension/module/wk_hotel_booking');
		$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');

		$data['rooms'] = $this->model_extension_module_wk_hotel_booking->getSellerRooms($this->customer->getId());
		$data['allBookings'] = $this->model_customerpartner_dashboard->getTotalBooking($this->customer->getId());

		return ($this->load->view('account/customerpartner/dashboards/booking' , $data));
	}

	public function getBookings(){

		$this->load->model('extension/module/wk_hotel_booking');
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$product_id = $this->request->post['room_id'];
		$book_from = $this->request->post['from'];
		$book_till = $this->request->post['to'];
		if($this->request->post['room_id']) {
			$room_info =  $this->model_catalog_wk_hotelbooking_hotels->getRoom($this->request->post['room_id']);
			if(!$room_info) {
				$this->response->addHeader('Content-Type:application/json');
				$this->response->setOutput(json_encode(array()));
				return;
			}
		}
		if((!$this->request->post['from'] || !$this->request->post['to']) && $product_id) {
			$bookedSlots = $this->model_extension_module_wk_hotel_booking->getAllRoomBooking($product_id);
		}elseif(($this->request->post['from'] && $this->request->post['to']) && !$product_id){
			$bookedSlots = $this->model_catalog_wk_hotelbooking_hotels->getTotalBookings($this->request->post['from'],$this->request->post['to']);
		}else {
			$bookedSlots = $this->model_extension_module_wk_hotel_booking->getBookedSlots($product_id,$book_from,$book_till);
			foreach ($bookedSlots as $key => $value) {
				$bookedSlots[$key]['name'] = $room_info['name'];
			}
		}
		if(empty($bookedSlots)){
			$bookedSlots['error'] = 'error';
		}
		$this->response->addHeader('Content-Type:application/json');
		$this->response->setOutput(json_encode($bookedSlots));
	}
}
