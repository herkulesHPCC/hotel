<?php

class ControllerAccountCustomerpartnerhotelWkhotelbookingbooking extends Controller {
	private $error = array();

	public function index() {
		if (!$this->customer->isLogged() || !$this->config->get('wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_booking', '', 'SSL');
			$this->response->redirect($this->url->link('account/login', '', 'SSL'));
		}

		$this->load->model('account/customerpartner');

		$this->data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();	
			
		if(!$this->data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('booking_heading_title'));
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$lang = array(
			'booking_heading_title',
			'booking_information',
			'booking_select_from',
			'booking_select_till',
			'booking_select_hotel',
			'booking_select_room',
			'booking_number_rooms',
			'booking_check_avail',
			'booking_total',
			'booking_avail',
			'text_enabled',
			'booking_booked',
			'booking_partially',
			'booking_unavailable',
			'booking_adult',
			'booking_child',
			'text_total_room',
			'text_fully_avail',
			'text_partially_avial',
			'text_booked_rooms'
		);
		foreach ($lang as $key) {
			$data[$key] = $this->language->get($key);
		}
		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'SSL'),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('booking_heading_title'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_booking', '' , 'SSL'),       		
   		);

   		$data['hotels'] = $this->model_catalog_wk_hotelbooking_hotels->getHotels();
		

		$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_booking/manualBooking', 'SSL');

		
		
		

   		$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
   		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_booking.tpl',$data));	
	}
	public function getRooms(){
		if($this->request->server['REQUEST_METHOD'] == 'POST'){
			$hotel_id = $this->request->post['hotel_id'];
			$this->load->model('catalog/wk_hotelbooking_hotels');
			$rooms = $this->model_catalog_wk_hotelbooking_hotels->getRoomOfHotel($hotel_id);
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($rooms));
		}
	}

	public function updateQuantity($data){
		$del=$this->db->query("DELETE FROM ".DB_PREFIX."wk_booking_quantity WHERE product_id='".$data['product_id']."'AND customer_id='".(int)$this->customer->getId()."'AND options= '".$data['options']."'");
		$this->db->query("INSERT " . DB_PREFIX . "wk_booking_quantity SET customer_id = '" . (int)$this->customer->getId() . "', product_id = '" . $data['product_id'] ."', quantity = '" . $data['hours'] . "',options = '".$data['options']."'");
	}


  	public function manualBooking(){

  		if(!isset($this->request->post['room'])){
  			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_booking', 'SSL'));	
  		}

  		$this->document->addScript("view/javascript/hotel/jquery-ui-1.10.4.custom.js");

  		$id = $this->request->post['room'];
 

		$this->load->model('catalog/product');
		$this->load->model('catalog/wk_hotelbooking_hotels');


		$data['product_info']= $this->model_catalog_product->getProduct($id);
		$data['product_info']['price'] = $this->currency->format($data['product_info']['price'],$this->config->get('config_currency'));
		$product_options= $this->model_catalog_product->getProductOptions($id);
		$this->load->model('catalog/option');
				
		foreach ($product_options as $key => $value) {
			$i=0;
			foreach ($product_options[$key]['product_option_value'] as $product_option_value) {
					$option_value_info = $this->model_catalog_option->getOptionValue($product_option_value['option_value_id']);
					if ($option_value_info) {
						$product_option_value_data[$i] = array(
						'product_option_value_id' => $product_option_value['product_option_value_id'],
						'option_value_id'         => $product_option_value['option_value_id'],
						'name'                    => $option_value_info['name'],
						'price'                   => (float)$product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
						'price_prefix'            => $product_option_value['price_prefix']
						);
					}
					$product_options[$key]['product_option_value']= $product_option_value_data;
					$i++;
		 	}

		}
		$data['product_options'] = $product_options;
			

      	$this->load->language('catalog/wk_hotelbooking_hotels');
      	$this->document->setTitle($this->language->get('heading_title'));

		// $data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'SSL'),
      		'separator' => false
   		);
   		$data['duration'] = $this->config->get('wk_hotelbooking_options0');
   		$data['rate'] = $this->config->get('wk_hotelbooking_options1');
   		$data['from'] = $this->config->get('wk_hotelbooking_options2');
   		$data['to'] = $this->config->get('wk_hotelbooking_options3');
   		$data['adult'] = $this->config->get('wk_hotelbooking_options4');
   		$data['child'] = $this->config->get('wk_hotelbooking_options5');
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_booking', '' , 'SSL'),       		
      		'separator' => ' :: '
   		);

   		$this->load->model('catalog/category');
		$data['text_hotel_name'] = $this->language->get('text_hotel_name');
  		$data['text_address'] = $this->language->get('text_address');
  		$data['text_email'] = $this->language->get('text_email');
  		$data['text_website'] = $this->language->get('text_website');
  		$data['text_contact'] = $this->language->get('text_contact');
  		$data['text_checkin'] = $this->language->get('text_checkin');
  		$data['text_checkout'] = $this->language->get('text_checkout');
  		$data['text_room_name'] = $this->language->get('text_room_name');
  		$data['text_from'] = $this->language->get('text_from');
  		$data['text_till'] = $this->language->get('text_till');
  		$data['text_price'] = $this->language->get('text_price');
  		$data['text_pernight']	= $this->language->get('text_pernight');
  		$data['text_customer_detail'] =$this->language->get('text_customer_detail');
  		$data['text_customer_required_detail'] =$this->language->get('text_customer_required_detail');
  		$data['text_address_details'] = $this->language->get('text_address_details');
  		$data['text_address_required'] = $this->language->get('text_address_required');
  		$data['text_payment_detail'] = $this->language->get('text_payment_detail');
  		$data['text_cart_details']	= $this->language->get('text_cart_details');
  		$data['text_room']	= $this->language->get('text_room');

		$data['text_heading_slots'] = $this->language->get('text_heading_slots');
      	$data['text_add_to_cart'] = $this->language->get('text_add_to_cart');
      	$data['text_booked'] = $this->language->get('text_booked');
      	$data['text_closed'] = $this->language->get('text_closed');
      	$data['text_start_time'] = $this->language->get('text_start_time');
      	$data['text_last_time'] = $this->language->get('text_last_time');
      	$data['text_action'] = $this->language->get('text_action');
      	$data['text_error_no_slots'] = $this->language->get('text_error_no_slots');
      	$data['text_no_booking_option'] = $this->language->get('text_no_booking_option');
      	$data['text_booking_closed'] = $this->language->get('text_booking_closed');
		
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_form'] = !isset($this->request->get['order_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_select'] = $this->language->get('text_select');
		$data['text_none'] = $this->language->get('text_none');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['text_ip_add'] = sprintf($this->language->get('text_ip_add'), $this->request->server['REMOTE_ADDR']);
		$data['text_product'] = $this->language->get('text_product');
		$data['text_voucher'] = $this->language->get('text_voucher');
		$data['text_order_detail'] = $this->language->get('text_order_detail');

		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_customer'] = $this->language->get('entry_customer');
		$data['entry_customer_group'] = $this->language->get('entry_customer_group');
		$data['entry_firstname'] = $this->language->get('entry_firstname');
		$data['entry_lastname'] = $this->language->get('entry_lastname');
		$data['entry_email'] = $this->language->get('entry_email');
		$data['entry_telephone'] = $this->language->get('entry_telephone');
		$data['entry_fax'] = $this->language->get('entry_fax');
		$data['entry_comment'] = $this->language->get('entry_comment');
		$data['entry_affiliate'] = $this->language->get('entry_affiliate');
		$data['entry_address'] = $this->language->get('entry_address');
		$data['entry_company'] = $this->language->get('entry_company');
		$data['entry_address_1'] = $this->language->get('entry_address_1');
		$data['entry_address_2'] = $this->language->get('entry_address_2');
		$data['entry_city'] = $this->language->get('entry_city');
		$data['entry_postcode'] = $this->language->get('entry_postcode');
		$data['entry_zone'] = $this->language->get('entry_zone');
		$data['entry_zone_code'] = $this->language->get('entry_zone_code');
		$data['entry_country'] = $this->language->get('entry_country');
		$data['entry_product'] = $this->language->get('entry_product');
		$data['entry_option'] = $this->language->get('entry_option');
		$data['entry_quantity'] = $this->language->get('entry_quantity');
		$data['entry_to_name'] = $this->language->get('entry_to_name');
		$data['entry_to_email'] = $this->language->get('entry_to_email');
		$data['entry_from_name'] = $this->language->get('entry_from_name');
		$data['entry_from_email'] = $this->language->get('entry_from_email');
		$data['entry_theme'] = $this->language->get('entry_theme');
		$data['entry_message'] = $this->language->get('entry_message');
		$data['entry_amount'] = $this->language->get('entry_amount');
		$data['entry_currency'] = $this->language->get('entry_currency');
		$data['entry_shipping_method'] = $this->language->get('entry_shipping_method');
		$data['entry_payment_method'] = $this->language->get('entry_payment_method');
		$data['entry_coupon'] = $this->language->get('entry_coupon');
		$data['entry_voucher'] = $this->language->get('entry_voucher');
		$data['entry_reward'] = $this->language->get('entry_reward');
		$data['entry_order_status'] = $this->language->get('entry_order_status');

		$data['column_product'] = $this->language->get('column_product');
		$data['column_model'] = $this->language->get('column_model');
		$data['column_quantity'] = $this->language->get('column_quantity');
		$data['column_price'] = $this->language->get('column_price');
		$data['column_total'] = $this->language->get('column_total');
		$data['column_action'] = $this->language->get('column_action');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_continue'] = $this->language->get('button_continue');
		$data['button_back'] = $this->language->get('button_back');
		$data['button_refresh'] = $this->language->get('button_refresh');
		$data['button_product_add'] = $this->language->get('button_product_add');
		$data['button_voucher_add'] = $this->language->get('button_voucher_add');
		$data['button_apply'] = $this->language->get('button_apply');
		$data['button_upload'] = $this->language->get('button_upload');
		$data['button_remove'] = $this->language->get('button_remove');
		$data['button_ip_add'] = $this->language->get('button_ip_add');

		$data['tab_order'] = $this->language->get('tab_order');
		$data['tab_customer'] = $this->language->get('tab_customer');
		$data['tab_payment'] = $this->language->get('tab_payment');
		$data['tab_shipping'] = $this->language->get('tab_shipping');
		$data['tab_product'] = $this->language->get('tab_product');
		$data['tab_voucher'] = $this->language->get('tab_voucher');
		$data['tab_total'] = $this->language->get('tab_total');
		
		$url = '';
		$data['order_id'] = 0;
		$data['store_id'] = '';
		$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
			
		$data['customer'] = '';
		$data['customer_id'] = '';
		$data['customer_group_id'] = $this->config->get('config_customer_group_id');
		$data['firstname'] = '';
		$data['lastname'] = '';
		$data['email'] = '';
		$data['telephone'] = '';
		$data['fax'] = '';
		$data['customer_custom_field'] = array();

		$data['addresses'] = array();

		$data['payment_firstname'] = '';
		$data['payment_lastname'] = '';
		$data['payment_company'] = '';
		$data['payment_address_1'] = '';
		$data['payment_address_2'] = '';
		$data['payment_city'] = '';
		$data['payment_postcode'] = '';
		$data['payment_country_id'] = '';
		$data['payment_zone_id'] = '';
		$data['payment_custom_field'] = array();
		$data['payment_method'] = '';
		$data['payment_code'] = '';

		$data['shipping_firstname'] = '';
		$data['shipping_lastname'] = '';
		$data['shipping_company'] = '';
		$data['shipping_address_1'] = '';
		$data['shipping_address_2'] = '';
		$data['shipping_city'] = '';
		$data['shipping_postcode'] = '';
		$data['shipping_country_id'] = '';
		$data['shipping_zone_id'] = '';
		$data['shipping_custom_field'] = array();
		$data['shipping_method'] = '';
		$data['shipping_code'] = '';

		$data['order_products'] = array();
		$data['order_vouchers'] = array();
		$data['order_totals'] = array();

		$data['order_status_id'] = $this->config->get('config_order_status_id');
		$data['comment'] = '';
		$data['affiliate_id'] = '';
		$data['affiliate'] = '';
		$data['currency_code'] = $this->config->get('config_currency');

		$data['coupon'] = '';
		$data['voucher'] = '';
		$data['reward'] = '';
		$this->load->model('setting/store');

		$data['stores'] = array();

		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default'),
		);

		$results = $this->model_setting_store->getStores();

		foreach ($results as $result) {
			$data['stores'][] = array(
				'store_id' => $result['store_id'],
				'name'     => $result['name']
			);
		}

		// Customer Groups
		$this->load->model('customer/customer_group');

		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		// Custom Fields
		$this->load->model('customer/custom_field');

		$data['custom_fields'] = array();
		$custom_fields = $this->model_customer_custom_field->getCustomFields();

		foreach ($custom_fields as $custom_field) {
			$data['custom_fields'][] = array(
				'custom_field_id'    => $custom_field['custom_field_id'],
				'custom_field_value' => $this->model_customer_custom_field->getCustomFieldValues($custom_field['custom_field_id']),
				'name'               => $custom_field['name'],
				'value'              => $custom_field['value'],
				'type'               => $custom_field['type'],
				'location'           => $custom_field['location'],
				'sort_order'         => $custom_field['sort_order']
			);
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->model('localisation/country');

		$data['countries'] = $this->model_localisation_country->getCountries();

		$this->load->model('localisation/currency');

		$data['currencies'] = $this->model_localisation_currency->getCurrencies();

		$data['voucher_min'] = $this->config->get('config_voucher_min');

		$this->load->model('sale/voucher_theme');

		$data['voucher_themes'] = $this->model_sale_voucher_theme->getVoucherThemes();

		// API login
		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info) {
			$data['api_id'] = $api_info['api_id'];
			$data['api_key'] = $api_info['key'];
			$data['api_ip'] = $this->request->server['REMOTE_ADDR'];
		} else {
			$data['api_id'] = '';
			$data['api_key'] = '';
			$data['api_ip'] = '';
		}

		$data['booking_from'] = $this->request->post['from'];
		$data['booking_till'] = $this->request->post['till'];
		$data['booking_adult'] = $this->request->post['adult'];
		$data['booking_child'] = $this->request->post['child'];
		$data['booking_rate'] = $data['product_info']['price'];
		$data['booking_quantity'] = $this->request->post['quantity'];

		$diff = abs(strtotime($data['booking_till']) - strtotime($data['booking_from']));

		$days = $diff/(24*60*60);

		$data['booking_duration'] = $days;

		// $data['name'] = $data['product_info']['name'];
		// $data['price'] = $data['product_info']['price'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_manual.tpl',$data));	

  		}
  		public function updateBooking(){
	  		$this->load->model('catalog/wk_hotelbooking_hotels');
	  		$ementies = json_encode(array('admin_booking'));
	  		$this->model_catalog_wk_hotelbooking_hotels->updateBooking($this->request->post['product_id'],$this->request->post['order_id'],$this->request->post['from_date'],$this->request->post['to_date'],$this->request->post['quant'],$this->request->post['name'],$this->request->post['email'],$this->request->post['telephone'],$ementies);
	  		$this->cart->clear();
  		}
  		public function getBookedSlots(){
  			$this->load->model('catalog/wk_hotelbooking_hotels');
  			$room_id = $this->request->post['room_id'];
  			$from = $this->request->post['from'];
  			$till = $this->request->post['to'];
  			$json = array();
  			$bookedSlots = $this->model_catalog_wk_hotelbooking_hotels->getBookedSlots($room_id,$from,$till);
  			if(empty($bookedSlots)) {
					
			} else {
			foreach($bookedSlots as $key=>$value){
					$json= $bookedSlots;
			}
		}
  			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
  		}
}