<?php

class ControllerAccountCustomerpartnerhotelWkhotelbookingfacility extends Controller {
	private $error = array();

	public function index() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}
		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));

		$this->load->language('extension/module/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('fix_facility_heading_title'));
		$this->getList();
	}
	public function getList() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'true')
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('fix_facility_heading_title'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', '', 'true')
   		);
   		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}
		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}
		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}
		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}
		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'name'	=> $name,
				'order'	=> $order,
				'status'	=> $status,
				'start'	=> $start,
				'end'	=> $end,
				);
   		$facility = $this->model_catalog_wk_hotelbooking_hotels->getFacilities($filterValues);
   		$facility_total = $this->model_catalog_wk_hotelbooking_hotels->getTotalFacilities($filterValues);

   		$data['facility'] =array();
   		$this->load->model('tool/image');

   		if(!empty($facility)) {
	   		foreach ($facility as $result) {
				if (is_file(DIR_IMAGE .$result['facility_image'])) {
					$image = $this->model_tool_image->resize($result['facility_image'], 40, 40);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 40, 40);
				}
				$data['facility'][] = array(
					'facility_ocid' =>$result['facility_ocid'],
					'facility_id' => $result['facility_id'],
					'image'      => $image,
					'name'       => $result['facility_name'],
					'status'  	 => $result['status'],
					'sort_order' => $result['sort_order'],
					'owner'		 => $result['owner'],
					'edit'       => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility/edit' . '&facility_id=' . $result['facility_id'].'&facility_ocid='.$result['facility_ocid'], true)
				);
			}
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		if (isset($this->session->data['error'])) {
			$data['error_warning'] = $this->session->data['error'];

			unset($this->session->data['error']);
		} else {
			$data['error_warning'] = '';
		}

		$pagination = new Pagination();
		$pagination->total = $facility_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', '&page={page}', true);

		$data['pagination'] = $pagination->render();

	$data['results'] = sprintf($this->language->get('text_pagination'), ($facility_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($facility_total - $this->config->get('config_limit_admin'))) ? $facility_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $facility_total, ceil($facility_total / $this->config->get('config_limit_admin')));

		$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numfxfacility');
		if(!$data['addlimit']  || $data['addlimit'] > $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility1')) {
			$data['addauth'] = true;
		}


		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['add']	=	$this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility/add',true);
		$data['delete']	=	$this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility/delete',true);
		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_facility',$data));
	}

	public function add() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('fix_facility_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numfxfacility');

			if($data['addlimit']  && $data['addlimit'] <= $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility1')) {
				$this->session->data['error'] = 'Can not add more than '.$data['addlimit'].' facility' ;

				$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', true));
			}
			$json = array();
			if(isset($this->request->files) && $this->request->files['image'] && isset($this->request->files['image']['tmp_name'])  && $this->request->files['image']['tmp_name']) {

				$info = getimagesize($this->request->files['image']['tmp_name']);
				if ($info === FALSE) {
				   $json['error'] = "Unable to determine image type of uploaded file";
				}
				if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
				   $json['error'] = "Incorrect File Type";
				}
				is_dir(DIR_IMAGE .'facility') ?  '' : mkdir(DIR_IMAGE .'facility');
				is_dir(DIR_IMAGE .'facility/'.$this->customer->getId()) ?  '' : mkdir(DIR_IMAGE .'facility/'.$this->customer->getId());
				if($this->request->files['image']['tmp_name'] && $this->request->files['image']['name'] ){
					$file = $this->request->files['image']['name'];
					move_uploaded_file($this->request->files['image']['tmp_name'], DIR_IMAGE .'facility/'.$this->customer->getId().'/'.$file);
				}
		    }
			if(!isset($json['error']) || !$json['error']){
				$success_text = $this->language->get('text_success');
				if(!$this->config->get('module_wk_hotelbooking_res_fxapprove')) {
					$success_text = $this->language->get('text_sucess_fxapprove');
					$this->request->post['status'] = 0;
				}
				$this->request->post['facility_ocid'] =  $this->addToOc($this->request->post);
				$this->model_catalog_wk_hotelbooking_hotels->addFacility($this->request->post,1);

				$this->session->data['success'] = $success_text;
				$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility' , true));
			} else {
				$this->error['warning'] = $json['error'];
			}
		}
		$this->getForm();
	}
	public function edit() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('fix_facility_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if(isset($this->request->files) && $this->request->files['image'] && isset($this->request->files['image']['tmp_name'])  && $this->request->files['image']['tmp_name']) {

				$info = getimagesize($this->request->files['image']['tmp_name']);
				if ($info === FALSE) {
				   $json['error'] = "Unable to determine image type of uploaded file";
				}
				if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
				   $json['error'] = "Incorrect File Type";
				}
				is_dir(DIR_IMAGE .'facility') ?  '' : mkdir(DIR_IMAGE .'facility');
				is_dir(DIR_IMAGE .'facility/'.$this->customer->getId()) ?  '' : mkdir(DIR_IMAGE .'facility/'.$this->customer->getId());
				if($this->request->files['image']['tmp_name'] && $this->request->files['image']['name'] ){
					$file = $this->request->files['image']['name'];
					move_uploaded_file($this->request->files['image']['tmp_name'], DIR_IMAGE .'facility/'.$this->customer->getId().'/'.$file);
				}
		    }
			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 2;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = $this->request->post['name'];
			}
			if(!isset($json['error']) || !$json['error']){
				$success_text = $this->language->get('text_success');
				if($this->config->get('module_wk_hotelbooking_res_fxdisapprove')) {
					$success_text = $this->language->get('text_sucess_fxapprove');
					$this->request->post['status'] = 0;
				}
				$this->updateToOc($this->request->get['facility_ocid'],$name,$this->request->post);


				$this->model_catalog_wk_hotelbooking_hotels->editFacility($this->request->get['facility_ocid'], $this->request->post,1);

				$this->session->data['success'] = $success_text;
				$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', true));
			} else {
				$this->error['warning'] = $json['error'];
			}
		}
		$this->getForm();
	}
	public function getForm() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$data['fix_facility_heading_title'] = $this->language->get('fix_facility_heading_title');

		$data['text_form'] = isset($this->request->get['facility_ocid']) ? $this->language->get('text_facility_edit') : $this->language->get('text_facility_add');

		$this->load->model('catalog/wk_hotelbooking_hotels');
		if(isset($this->request->get['facility_ocid'])) {
			$facility_info =  $this->model_catalog_wk_hotelbooking_hotels->getFacility($this->request->get['facility_ocid']);
		}
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['facility_name']){
			$data['name'] = $facility_info['facility_name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['sort_order']){
			$data['sort_order'] = $facility_info['sort_order'];
		} else {
			$data['sort_order'] = '';
		}
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['status']){
			$data['status'] = $facility_info['status'];
		}  else {
			$data['status'] = '';
		}
		if (isset($facility_info) && $facility_info && isset($facility_info['owner'])){
			$data['owner'] = $facility_info['owner'];
		}  else {
			$data['owner'] = $this->customer->getId();
		}

		$this->load->model('tool/image');
		if (isset($this->request->post['image']) && is_file(DIR_IMAGE.$this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
			$data['image'] = $this->request->post['image'];
		} elseif (isset($facility_info) && $facility_info && $facility_info['facility_image'] && is_file(DIR_IMAGE .$facility_info['facility_image'] )){
			$data['thumb'] = $this->model_tool_image->resize($facility_info['facility_image'] , 100, 100);
			$data['image'] = $facility_info['facility_image'];
		}  else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['image'] = '';
		}
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('fix_facility_heading_title'),
			'href' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', true)
		);

		$data['customer_id'] = $this->customer->getId();
		$data['cancel'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility' , true);
		if (!isset($this->request->get['facility_id'])) {
			$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numfxfacility');

			if(!$data['addlimit']  || $data['addlimit'] > $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility1')) {
				$data['addauth'] = true;
			}
			$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility/add','', true);
		} else {
			$data['addauth'] = true;
			$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility/edit'.'&facility_ocid='.$this->request->get['facility_ocid'] ,'', true);
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_facility_form', $data));
	}

	public function delete() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {

			$this->load->adminModel('catalog/attribute',$this->config->get('module_wk_hotelbooking_res_adminPath'));

			foreach ($this->request->post['selected'] as $attribute_id) {

				$this->model_catalog_attribute->deleteAttribute($attribute_id);

				$this->model_catalog_wk_hotelbooking_hotels->deleteFxFacility($attribute_id);
			}

			$this->session->data['success'] = $this->language->get('text_facility_delete_success');

			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility','', true));
		}

		$this->getList();
	}
	protected function validateDelete() {
		$this->load->adminModel('catalog/product',$this->config->get('module_wk_hotelbooking_res_adminPath'));
		foreach ($this->request->post['selected'] as $attribute_id) {
			$product_total = $this->model_catalog_product->getTotalProductsByAttributeId($attribute_id);

			if ($product_total) {
				$this->error['warning'] = sprintf($this->language->get('error_attribute_delete'), $product_total);
			}
		}

		return !$this->error;
	}
	public function validate() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		foreach ($this->request->files as $key => $value) {
  		if (isset($value['name']) && !empty($value['name']) && is_file($value['tmp_name'])) {
				// Check to see if any PHP files are trying to be uploaded
				$content = file_get_contents($value['tmp_name']);

				if (preg_match('/\<\?php/i', $content)) {
					$this->error['warning'] = 'Incorrect File type';
				}
			}
		}
		if(!trim($this->request->post['name'])) {
			$this->error['warning'] = $this->language->get('error_name');
		}

		if($this->error){
			return false;
		} else {
			return true;
		}

	}


	public function deleteFromOc($facility_type,$id,$data) {
			$this->load->model('catalog/attribute');
			$this->model_catalog_attribute->deleteAttribute($id);
	}
	public function updateToOc($id,$name,$data) {
				//Update facilitiy as attribute
				$attribute_info = array(
					'attribute_group_id' => $this->config->get('wk_hotelbookingattr_attrgroupid'),
					'sort_order' => $data['sort_order'],
					'attribute_description' => $name,
					);
				$this->load->adminModel('catalog/attribute',$this->config->get('module_wk_hotelbooking_res_adminPath'));

				 $this->model_catalog_attribute->editAttribute($id,$attribute_info);

	}
	public function addToOc($add_data) {
			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 2;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = $add_data['name'];
				$option_name[$language['language_id']]['name'] = 'Hotel Management';
			}
			$attribute_info = array(
				'attribute_group_id' => $this->config->get('wk_hotelbookingattr_attrgroupid'),
				'sort_order' => $sort_order,
				'attribute_description' => $name,
			);
			$this->load->adminModel('catalog/attribute',$this->config->get('module_wk_hotelbooking_res_adminPath'));

			$facility_ocid = $this->model_catalog_attribute->addAttribute($attribute_info);
			return $facility_ocid;
	}
}
?>
