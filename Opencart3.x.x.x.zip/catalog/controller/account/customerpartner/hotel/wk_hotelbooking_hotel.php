<?php

class ControllerAccountCustomerpartnerhotelWkhotelbookinghotel extends Controller {
	private $error = array();

	public function index() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();
		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));
		$this->load->language('extension/module/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('hotel_heading_title'));
		$this->getList();
	}
	public function getList() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('extension/module/wk_hotelbooking_hotels');
			$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'true')
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
					'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '', 'true')
   		);
   		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}
		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}
		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}
		if(isset($this->request->get['address'])){
			$data['address'] = $address = $this->request->get['address'];
		}else{
			$address = null;
		}
		if(isset($this->request->get['website'])){
			$data['website'] = $website = $this->request->get['website'];
		}else{
			$website = null;
		}
		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}
		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'name'	=> $name,
				'order'	=> $order,
				'status'	=> $status,
				'website'	=> $website,
				'address' => $address,
				'start'	=> $start,
				'end'	=> $end,
				);


   		$hotels = $this->model_catalog_wk_hotelbooking_hotels->getHotels($filterValues);
			$total_hotels = $this->model_catalog_wk_hotelbooking_hotels->getTotalHotels($filterValues);
   		$data['hotels'] =array();
   		$this->load->model('tool/image');
   		if(!empty($hotels)) {
	   		foreach ($hotels as $result) {
				if (is_file(DIR_IMAGE . $result['image'])) {
					$image = $this->model_tool_image->resize($result['image'], 100, 100);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 100, 100);
				}
				$data['hotels'][] = array(
					'hotel_id' => $result['category_id'],
					'image'      => $image,
					'name'       => $result['name'],
					'website'    => $result['website'],
					'address'	 => $result['address'],
					'status'  	 => $result['status'],
					'edit'       => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/edit' . '&hotel_id=' . $result['category_id'], true)
				);
			}
		}

		$data['add'] =  $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/add' , true);
		$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numhotel');

		if(!$data['addlimit']  || $data['addlimit'] > $this->model_catalog_wk_hotelbooking_hotels->countTotal('hotel')) {
			$data['addauth'] = true;
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		if (isset($this->session->data['error'])) {
			$data['error_warning'] = $this->session->data['error'];

			unset($this->session->data['error']);
		}
		$pagination = new Pagination();
		$pagination->total = $total_hotels;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '&page={page}', true);

		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($total_hotels) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($total_hotels - $this->config->get('config_limit_admin'))) ? $total_hotels : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $total_hotels, ceil($total_hotels / $this->config->get('config_limit_admin')));
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['add']	=	$this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/add');
		$data['delete']	=	$this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/delete');
		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_hotel_list',$data));
	}
	public function edit() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('hotel_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			if(isset($this->request->files) && $this->request->files['file'] && isset($this->request->files['file']['tmp_name'])  && $this->request->files['file']['tmp_name']) {

				$info = getimagesize($this->request->files['file']['tmp_name']);
				if ($info === FALSE) {
				   $json['error'] = "Unable to determine file type of uploaded file";
				}
				if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
				   $json['error'] = "Incorrect File Type";
				}
				is_dir(DIR_IMAGE .'facility') ?  '' : mkdir(DIR_IMAGE .'facility');
				is_dir(DIR_IMAGE .'facility/'.$this->customer->getId()) ?  '' : mkdir(DIR_IMAGE .'facility/'.$this->customer->getId());
				if($this->request->files['file']['tmp_name'] && $this->request->files['file']['name'] ){
					$file = $this->request->files['file']['name'];
					move_uploaded_file($this->request->files['file']['tmp_name'], DIR_IMAGE .'facility/'.$this->customer->getId().'/'.$file);
				}
		    }

			$this->load->adminModel('catalog/category',$this->config->get('module_wk_hotelbooking_res_adminPath'));

			$this->request->post['parent_id'] = $this->config->get('wk_hotelbookingcat_categoryid');
			$this->request->post['column']	  = '';
			$this->request->post['sort_order']='';
			$this->request->post['keyword']	= '';
			$this->request->post['category_store'] =array('0'=>0);
			$success_text = $this->language->get('text_success_hotel');
			if(isset($this->request->get['hotel_id'])) {
				if($this->config->get('module_wk_hotelbooking_res_hoteldisapprove')) {
					$success_text = $this->language->get('text_success_apphotel');
					$this->request->post['status'] = 0;
				}
			} else {
				if($this->config->get('module_wk_hotelbooking_res_hotelapprove')) {
					$success_text = $this->language->get('text_success_apphotel');
					$this->request->post['status'] = 0;
				}
			}

			$this->model_catalog_category->editCategory($this->request->get['hotel_id'], $this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->addHotel($this->request->get['hotel_id'], $this->request->post);

			$this->session->data['success'] = $success_text;

			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', true));
		}
		$this->getForm();
	}

	public function add() {

		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('hotel_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
				$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numhotel');
				if($data['addlimit'] && $data['addlimit'] <= $this->model_catalog_wk_hotelbooking_hotels->countTotal('hotel')) {
					$this->session->data['error'] = 'Can not add more than '.$data['addlimit'].' hotel' ;

					$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', true));
				}
			if(isset($this->request->files) && $this->request->files['file'] && isset($this->request->files['file']['tmp_name'])  && $this->request->files['file']['tmp_name']) {

				$info = getimagesize($this->request->files['file']['tmp_name']);
				if ($info === FALSE) {
				   $json['error'] = "Unable to determine file type of uploaded file";
				}
				if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
				   $json['error'] = "Incorrect File Type";
				}
				is_dir(DIR_IMAGE .'facility') ?  '' : mkdir(DIR_IMAGE .'facility');
				is_dir(DIR_IMAGE .'facility/'.$this->customer->getId()) ?  '' : mkdir(DIR_IMAGE .'facility/'.$this->customer->getId());
				if($this->request->files['file']['tmp_name'] && $this->request->files['file']['name'] ){
					$file = $this->request->files['file']['name'];
					move_uploaded_file($this->request->files['file']['tmp_name'], DIR_IMAGE .'facility/'.$this->customer->getId().'/'.$file);
				}
		    }
			$this->load->adminModel('catalog/category',$this->config->get('module_wk_hotelbooking_res_adminPath'));

			$this->request->post['parent_id'] = $this->config->get('wk_hotelbookingcat_categoryid');
			$this->request->post['column']	  = '';
			$this->request->post['sort_order']='';
			$this->request->post['category_store'] =array('0'=>0);

			$success_text = $this->language->get('text_success_hotel');

			if(!$this->config->get('module_wk_hotelbooking_res_hotelapprove')) {
				$success_text = $this->language->get('text_success_apphotel');
				$this->request->post['status'] = 0;
			}

			$category_id = $this->model_catalog_category->addCategory($this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->addHotel($category_id , $this->request->post);

			$this->session->data['success'] = $success_text;

			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', true));
		}
		$this->getForm();
	}
	public function getForm() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$this->load->language('extension/module/wk_hotelbooking_hotels');
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_form'] = isset($this->request->get['hotel_id']) ? $this->language->get('text_edit_hotel') : $this->language->get('text_add_hotel');
		$data['customer_id']	= $this->customer->getId();
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['address_error'])) {
			$data['error_address_error'] = $this->error['address_error'];
		} else {
			$data['error_address_error'] = '';
		}
		if (isset($this->error['email_error'])) {
			$data['error_email_error'] = $this->error['email_error'];
		} else {
			$data['error_email_error'] = '';
		}
		if (isset($this->error['contact_error'])) {
			$data['error_contact_error'] = $this->error['contact_error'];
		} else {
			$data['error_contact_error'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}

		if (isset($this->error['file'])) {
			$data['error_file'] = $this->error['file'];
		} else {
			$data['error_file'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

			$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'true')
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '', 'true')
   		);


		if (!isset($this->request->get['hotel_id'])) {
			$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numhotel');
			 if(!$data['addlimit'] || $data['addlimit'] > $this->model_catalog_wk_hotelbooking_hotels->countTotal('hotel')) {
				$data['addauth'] = true;
			 }
			$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/add' . $url, true);
		} else {
			$data['addauth'] = true;
			$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel/edit' . '&hotel_id=' . $this->request->get['hotel_id'] . $url, true);
		}
		$data['cancel'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel' . $url, true);

		$this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key='.$this->config->get('module_wk_hotelbooking_res_google_key'));

		$this->load->model('catalog/category');

		if (isset($this->request->get['hotel_id'])) {
			$category_info =  $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id) WHERE c.category_id = '" . (int)$this->request->get['hotel_id'] . "' AND cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND c2s.store_id = '" . (int)$this->config->get('config_store_id') . "'")->row;
		}

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['category_description'])) {
			$data['category_description'] = $this->request->post['category_description'];
		} elseif (isset($this->request->get['hotel_id'])) {
			$data['category_description'] = $this->model_catalog_wk_hotelbooking_hotels->getCategoryDescriptions($this->request->get['hotel_id']);
		} else {
			$data['category_description'] = array();
		}

		$data['parent_id'] = 0;

		$this->load->model('setting/store');


		$this->load->model('tool/image');

		$this->document->addScript('admin/view/javascript/summernote/summernote.js');
		$this->document->addStyle('admin/view/javascript/summernote/summernote.css');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment.js');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');
		$this->document->addStyle('catalog/view/theme/default/stylesheet/MP/sell.css');
		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($category_info) && is_file(DIR_IMAGE . $category_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($category_info['image'], 100, 100);
			$data['image'] = $category_info['image'];
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['image'] = '';
		}
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($category_info)) {
			$data['status'] = $category_info['status'];
		} else {
			$data['status'] = true;
		}

		if(isset($this->request->get['hotel_id'])) {
			$hotel_id = $this->request->get['hotel_id'];
		} else {
			$hotel_id = 0;
		}

		$hotel_info = $this->model_catalog_wk_hotelbooking_hotels->getHotelDetails($hotel_id);
	    if (!empty($hotel_info)) {
	      $data['hotel_details'] = array(
	        'bookingstatus'     => (isset($this->request->post) && isset($this->request->post['bookingstatus'])) ? $this->request->post['bookingstatus'] : $hotel_info['status'],
	        'bookingaddress'    => (isset($this->request->post) && isset($this->request->post['bookingaddress'])) ? $this->request->post['bookingaddress'] : $hotel_info['address'],
	        'bookingemail'      => (isset($this->request->post) && isset($this->request->post['bookingemail'])) ? $this->request->post['bookingemail'] : $hotel_info['email'],
	        'bookingwebsite'    => (isset($this->request->post) && isset($this->request->post['bookingwebsite'])) ? $this->request->post['bookingwebsite'] : $hotel_info['website'],
	        'bookingcontact'    => (isset($this->request->post) && isset($this->request->post['bookingcontact'])) ? $this->request->post['bookingcontact'] : $hotel_info['contact'],
	        'bookingfaxno'      => (isset($this->request->post) && isset($this->request->post['bookingfaxno'])) ? $this->request->post['bookingfaxno'] : $hotel_info['faxno'],
	        'bookingcheckin'    => (isset($this->request->post) && isset($this->request->post['bookingcheckin'])) ? $this->request->post['bookingcheckin'] : $hotel_info['checkin'],
	        'bookingcheckout'   => (isset($this->request->post) && isset($this->request->post['bookingcheckout'])) ? $this->request->post['bookingcheckout'] : $hotel_info['checkout'],
	        'bookingcheckoutap' => (isset($this->request->post) && isset($this->request->post['bookingcheckoutap'])) ? $this->request->post['bookingcheckoutap'] : $hotel_info['checkout_ap'],
	        'bookingcheckinap'  => (isset($this->request->post) && isset($this->request->post['bookingcheckinap'])) ? $this->request->post['bookingcheckinap'] : $hotel_info['checkin_ap'],
	        );
	    } else {
				$data['hotel_details'] = array(
					'bookingstatus'  => isset($this->request->post['bookingstatus']) ? $this->request->post['bookingstatus'] : 0,
					'bookingaddress' =>  isset($this->request->post['bookingaddress']) ? $this->request->post['bookingaddress'] : '',
					'bookingemail'   =>  isset($this->request->post['bookingemail']) ? $this->request->post['bookingemail'] : '',
					'bookingwebsite' =>  isset($this->request->post['bookingwebsite']) ? $this->request->post['bookingwebsite'] : '',
					'bookingcontact' =>  isset($this->request->post['bookingcontact']) ? $this->request->post['bookingcontact'] : '',
					'bookingfaxno'   =>  isset($this->request->post['bookingfaxno']) ? $this->request->post['bookingfaxno'] : '',
					'bookingcheckin' =>  isset($this->request->post['bookingcheckin']) ? $this->request->post['bookingcheckin'] : '',
					'bookingcheckout'=>  isset($this->request->post['bookingcheckout']) ? $this->request->post['bookingcheckout'] : '',
					'bookingcheckoutap' => isset($this->request->post['bookingcheckoutap']) ? $this->request->post['bookingcheckoutap'] : 1,
					'bookingcheckinap'  => isset($this->request->post['bookingcheckinap']) ? $this->request->post['bookingcheckinap'] : 1
					);
	    }

		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_hotel_form', $data));
	}
	public function delete() {
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));



		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			$this->load->adminModel('catalog/product',$this->config->get('module_wk_hotelbooking_res_adminPath'));
		$this->load->adminModel('catalog/category',$this->config->get('module_wk_hotelbooking_res_adminPath'));
		$this->load->model('catalog/wk_hotelbooking_hotels');
			foreach ($this->request->post['selected'] as $category_id) {

				$this->model_catalog_product->deleteProduct($category_id);
				$this->model_catalog_category->deleteCategory($category_id);

				$this->model_catalog_wk_hotelbooking_hotels->deleteHotel($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_hotel_delete_success');

			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel' , true));
		}

		$this->getList();

	}

	protected function validateForm() {
		$this->registry->set('Htmlfilter', new Htmlfilter($this->registry));

		foreach ($this->request->files as $key => $value) {
  		if (isset($value['name']) && !empty($value['name']) && is_file($value['tmp_name'])) {
				// Check to see if any PHP files are trying to be uploaded
				$content = file_get_contents($value['tmp_name']);

				if (preg_match('/\<\?php/i', $content)) {
					$this->error['file'] = 'Incorrect File type';
				}
			}
		}

		foreach ($this->request->post['category_description'] as $language_id => $value) {
			$this->request->post['category_description'][$language_id]['description'] = htmlentities($this->Htmlfilter->HTMLFilter(html_entity_decode($value['description']),'',true));

			if ((utf8_strlen(trim($value['name'])) < 2) || (utf8_strlen(trim($value['name'])) > 255)) {
				$this->error['name'][$language_id] = $this->language->get('category_error_name');
			}

			if ((utf8_strlen(trim($value['meta_title'])) < 3) || (utf8_strlen(trim($value['meta_title'])) > 255)) {
				$this->error['meta_title'][$language_id] = $this->language->get('category_error_meta_title');
			}
		}
		if(!trim($this->request->post['bookingaddress'])) {
			$this->error['address_error']	 = $this->language->get('address_error');
		}
		if ($this->request->post['bookingemail'] && !filter_var($this->request->post['bookingemail'], FILTER_VALIDATE_EMAIL)) {
			$this->error['email_error']	 = $this->language->get('email_error');
		}
		if ($this->request->post['bookingcontact'] && !preg_match('/^[0-9\/-]+$/', $this->request->post['bookingcontact'])) {
			$this->error['contact_error']	 = $this->language->get('contact_error');
		}

		if(isset($this->request->files['file']['name']) && $this->request->files['file']['name']) {

			$image_status = $this->validateImage($this->request->files['file']);
			if(isset($image_status['status']) && !$image_status['status']) {
				$this->error['file'] = $image_status['message'];
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('hotel_error_warning');
		}
		return !$this->error;
	}

	/**
* [validateImage description]
* @param  [type] $file [file field array]
* @return [type]       [array with status and message]
*/
public function validateImage($file) {

//array to return with status and message
$checkstatus = array('status' => false, 'message' => '');

$image_ex = 'jpg,jpeg,png,gif';

//allowed extension in marketplace
$allowedExts = explode(",",$image_ex);

//get file extension here
$extension = explode(".", $file["name"]);

//get the last extension of file
$main_extension = end($extension);

//mime type array
$mime_type = array(
 'image/gif',
 'image/png',
 'image/jpg',
 'image/jpeg',
);

//check if php value is in file extension array
if(in_array('php',$extension) || in_array('PHP',$extension)) {

	$checkstatus['status'] = false;
	$checkstatus['message'] = $this->language->get('error_image');

	//check file mime type and extension match in an array
} elseif (!in_array($main_extension, $allowedExts) && !in_array($file['type'],$mime_type)) {

	$checkstatus['status'] = false;
	$checkstatus['message'] = sprintf($this->language->get('error_image_extension'), explode(",",$allowedExts));

	//check file size here
} else {

	$checkstatus['status'] = true;
	$checkstatus['message'] = '';
}

//return $checkstatus array here
return $checkstatus;
}


	protected function validateDelete(){

		$this->load->model('catalog/wk_hotelbooking_hotels');

		foreach ($this->request->post['selected'] as $hotel_id) {

			$room_total = $this->model_catalog_wk_hotelbooking_hotels->getTotalRooms($hotel_id);

			if ($room_total) {
				$this->error['warning'] = sprintf($this->language->get('error_hotel_delete'), $room_total);
			}
		}

		return !$this->error;
	}
}
