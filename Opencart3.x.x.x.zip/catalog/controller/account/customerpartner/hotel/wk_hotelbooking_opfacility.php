<?php
class ControllerAccountCustomerpartnerhotelwkhotelbookingopfacility extends Controller {
	private $error = array();

	public function index() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));

		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('opt_facility_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->getForm();
	}

	public function add() {

		$this->document->setTitle($this->language->get('opt_facility_heading_title'));

		$this->load->adminModel('catalog/option',$this->config->get('module_wk_hotelbooking_res_adminPath'));
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('extension/module/wk_hotelbooking_hotels');


		if (($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm()) ) {

			$json = array();
			$total_options= array();

			if(isset($this->request->files)&&  $this->request->files && $this->request->files['image'] && isset($this->request->files['image']['tmp_name'])  && $this->request->files['image']['tmp_name']) {
				foreach ($this->request->files['image']['name'] as $key => $value) {
					if(!$this->request->files['image']['error'][$key]) {
						$info = getimagesize($this->request->files['image']['tmp_name'][$key]);
						if ($info === FALSE) {
						   $json['error'] = "Unable to determine image type of uploaded file";
						}
						if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
						   $json['error'] = "Incorrect File Type";
						}
						is_dir(DIR_IMAGE .'facility') ?  '' : mkdir(DIR_IMAGE .'facility');
						is_dir(DIR_IMAGE .'facility/'.$this->customer->getId()) ?  '' : mkdir(DIR_IMAGE .'facility/'.$this->customer->getId());
						if($this->request->files['image']['tmp_name'][$key] && $this->request->files['image']['name'][$key] ){
							$file = $this->request->files['image']['name'][$key];
							move_uploaded_file($this->request->files['image']['tmp_name'][$key], DIR_IMAGE .'facility/'.$this->customer->getId().'/'.$file);
						}
					}
				}
		    }

			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 1;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = 'Extra Amenties';
			}
			if($this->request->post) {
				$total_options = $this->request->post['option_value'];
				$mtotal =array();
				foreach ($total_options as $key => $value) {
					if(isset($value['owner']) && $value['owner'] && $value['owner']==$this->customer->getId()) {
						$mtotal [] = $value;
					}
				}
				$total_options = $mtotal;
			}
			$other_options = $this->model_catalog_wk_hotelbooking_hotels->getOtherOptions($this->config->get('wk_hotelbookingopt_optionid'));
			if($other_options)
				$total_options = array_merge($total_options,$other_options);
			$option_data = array(
			'type'=>'checkbox',
			'sort_order'=>1,
			'option_description'=>$name,
			'option_value' => $total_options
			);
			$this->model_catalog_wk_hotelbooking_hotels->deleteOptFacility();
			$this->model_catalog_wk_hotelbooking_hotels->editOption($this->config->get('wk_hotelbookingopt_optionid'),$option_data);

			$this->session->data['success'] = $this->language->get('text_opt_success');
			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility', true));
		}


		$this->getForm();
	}
	protected function getForm() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$this->document->setTitle($this->language->get('opt_facility_heading_title'));
		$this->load->model('catalog/wk_hotelbooking_hotels');
		if (isset($this->request->post['option_value'])) {
			$option_values = $this->request->post['option_value'];
		} elseif ($this->config->get('wk_hotelbookingopt_optionid')) {
			$option_values = $this->model_catalog_wk_hotelbooking_hotels->getOptionValueDescriptions($this->config->get('wk_hotelbookingopt_optionid'));
		} else {
			$option_values = array();
		}

		if (isset($this->error['option_value'])) {
			$data['error_option_value'] = $this->error['option_value'];
		} else {
			$data['error_option_value'] = array();
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'true')
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('opt_facility_heading_title'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility', '', 'true')
   		);
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

	  	$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility/add', true);
		$this->load->model('tool/image');

		$data['option_values'] = array();
		foreach ($option_values as $option_value) {
			if (is_file(DIR_IMAGE . $option_value['image'])) {
				$image = $option_value['image'];
				$thumb =  $this->model_tool_image->resize($option_value['image'],40,40);
			} else {
				$image = '';
				$thumb = $this->model_tool_image->resize('no_image.png', 40, 40);
			}

			$data['option_values'][] = array(
				'option_value_id'          => $option_value['option_value_id'],
				'option_value_description' => $option_value['option_value_description'],
				'image'                    => $image,
				'thumb'                    => $thumb,
				'sort_order'               => $option_value['sort_order'],
				'owner'					   => $option_value['owner'],
				'status'				   => $option_value['status']
			);
		}
		$data['wk_hotelbooking_res_opapprove'] = $this->config->get('module_wk_hotelbooking_res_opapprove');

		$data['customer_id'] = $this->customer->getId();
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 40, 40);

		$data['addlimit'] = $this->config->get('module_wk_hotelbooking_res_numopfacility');

		if(!$data['addlimit']  || $data['addlimit'] > $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility2')) {
			$data['addauth'] = true;

			$data['option_limit'] = $this->config->get('module_wk_hotelbooking_res_numopfacility');
			$data['available'] = $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility2');
		}

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_opfacility', $data));
	}
	protected function validateForm() {
		if (isset($this->request->post['option_value'])) {
			$option_count = 0;
			foreach ($this->request->post['option_value'] as $option_value_id => $option_value) {
					foreach ($option_value['option_value_description'] as $language_id => $option_value_description) {
						if ((utf8_strlen(trim($option_value_description['name'])) < 1) || (utf8_strlen(trim($option_value_description['name'])) > 128)) {
							$this->error['option_value'][$option_value_id][$language_id] = $this->language->get('error_option_value');
							$this->error['warning'] = $this->language->get('option_error_warning');
						}
					}
					if($option_value['owner'] > 0){
						$option_count++;
					}
			}

			$option_limit = $this->config->get('module_wk_hotelbooking_res_numopfacility');
			$available = $option_count - $this->model_catalog_wk_hotelbooking_hotels->countTotal('facility2');

			if($option_limit < $available){
				$this->error['warning'] = "You can add only five optional facility";
			}

			if(isset($this->request->files)&&  $this->request->files && $this->request->files['image'] && isset($this->request->files['image']['tmp_name'])  && $this->request->files['image']['tmp_name']) {
				foreach ($this->request->files['image']['name'] as $key => $value) {
					// Check to see if any PHP files are trying to be uploaded
					if($this->request->files['image']['tmp_name'][$key]){
						$content = file_get_contents($this->request->files['image']['tmp_name'][$key]);
						if (preg_match('/\<\?php/i', $content)) {
							$this->error['warning'] = 'Incorrect file type';
						}
					}
				}
			}

		}
		return !$this->error;
	}
}
