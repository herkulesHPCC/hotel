<?php
class ControllerAccountCustomerpartnerhotelWkhotelbookingresbooking extends Controller {

	private $data = array();

	public function index() {

		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			if(isset($this->request->get['order_id'])){
				$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotel_booking_res_booking&order_id='.$this->request->get['order_id'], '', 'true');
			}
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));

		$data['isMember'] = true;

		$this->language->load('extension/module/wk_hotelbooking_hotels');

		if (isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_id = 0;
		}

		$data['order_id'] = $order_id;

		$this->load->model('account/order');

		$order_info = $this->model_account_customerpartner->getOrder($order_id);
		if($order_info)
			$data['allowed'] = true;
		else
			$data['allowed'] = false;

		$this->document->setTitle($this->language->get('text_order'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),
			'separator' => false
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('account/account', '', 'true'),
			'separator' => $this->language->get('text_separator')
		);

		$url = '';

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title_booking'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', $url, 'true'),
			'separator' => $this->language->get('text_separator')
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_order'),
			'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res_booking', 'order_id=' . $order_id . $url, 'true'),
			'separator' => $this->language->get('text_separator')
		);

		$data['errorPage'] = false;

		if($this->request->server['REQUEST_METHOD']=='POST' && isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
			$this->load->model('catalog/wk_hotelbooking_hotels');
			if($this->config->get('module_wk_hotelbooking_res_cancel')) {
				$this->model_catalog_wk_hotelbooking_hotels->cancelBooking($order_id);
				$this->session->data['success'] = $this->language->get('text_success_cancel');
				$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_res_booking&order_id='.$order_id, '', 'true'));
			}
			else {
				$this->session->data['error'] = $this->language->get('not_authenticated');
				$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', true));

			}
		}
		if(isset($this->session->data['success'])){
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		}else{
			$data['success'] = '';
		}
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$status = $this->model_catalog_wk_hotelbooking_hotels->getStatus($order_id);
		if($status)
			$data['booking_status'] = $status['status'];
		else
			$data['booking_status'] = 1;

		if ($order_info) {

			if ($order_info['invoice_no']) {
				$data['invoice_no'] = $order_info['invoice_prefix'] . $order_info['invoice_no'];
			} else {
				$data['invoice_no'] = '';
			}

			$data['date_added'] = date($this->language->get('date_format_short'), strtotime($order_info['date_added']));

			if ($order_info['payment_address_format']) {
      			$format = $order_info['payment_address_format'];
    		} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

    		$find = array(
	  			'{firstname}',
	  			'{lastname}',
	  			'{company}',
      			'{address_1}',
      			'{address_2}',
     			'{city}',
      			'{postcode}',
      			'{zone}',
				'{zone_code}',
      			'{country}'
			);

			$replace = array(
	  			'firstname' => $order_info['payment_firstname'],
	  			'lastname'  => $order_info['payment_lastname'],
	  			'company'   => $order_info['payment_company'],
      			'address_1' => $order_info['payment_address_1'],
      			'address_2' => $order_info['payment_address_2'],
      			'city'      => $order_info['payment_city'],
      			'postcode'  => $order_info['payment_postcode'],
      			'zone'      => $order_info['payment_zone'],
				'zone_code' => $order_info['payment_zone_code'],
      			'country'   => $order_info['payment_country']
			);

			$data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

      		$data['payment_method'] = $order_info['payment_method'];

			$data['products'] = array();
			$this->load->model('catalog/wk_hotelbooking_hotels');

			$products = $this->model_account_customerpartner->getSellerOrderProductss($order_id);


			// Uploaded files
			$this->load->model('tool/upload');

      		foreach ($products as $product) {
      			$booking_from = '';
      			$booking_till = '';
      			$duration = '';
      			$people = '';
      			$amenties = array();
				$option_data = array();

				$options = $this->model_catalog_wk_hotelbooking_hotels->getOrderOptions($order_id, $product['order_product_id']);
         		 // code changes due to download file error
         		foreach ($options as $key=>$option) {
          			if ($option['type'] != 'file') {
						$option_data[$key] = array(
							'name'  => $option['name'],
							'value' => $option['value'],
							'type'  => $option['type']
						);
					} else {
						$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);
						if ($upload_info) {
							$option_data[$key] = array(
								'name'  => $option['name'],
								'value' => $upload_info['name'],
								'type'  => $option['type'],
								'href'  => $this->url->link('account/customerpartner/hotel/wk_hotel_booking_res_booking/download','&code=' . $upload_info['code'], 'true')
							);
						}
					}
					if($option['option_id'] == $this->config->get('wk_hotelbooking_options2')) {
						$booking_from = $option['value'];
						unset($option_data[$key]);
					}elseif($option['option_id'] == $this->config->get('wk_hotelbooking_options3')){
						$booking_till = $option['value'];
						unset($option_data[$key]);
					} elseif($option['option_id'] == $this->config->get('wk_hotelbooking_options0')){
						$duration = $option['value'];
						unset($option_data[$key]);
					}elseif($option['option_id'] == $this->config->get('wk_hotelbooking_options1')){
						unset($option_data[$key]);
					} elseif($option['option_id']==$this->config->get('wk_hotelbookingopt_optionid')){
						$amenties[] = $option['value'];
						unset($option_data[$key]);
					} elseif($option['option_id']==$this->config->get('wk_hotelbooking_options4')){
						$people .= $option['value'].' Adult ';
						unset($option_data[$key]);
					}elseif($option['option_id']==$this->config->get('wk_hotelbooking_options5')){
						$people .= $option['value'].' Child';
						unset($option_data[$key]);
					}
        		}

        		if($product['paid_status'] == 1) {
        			$paid_status = $this->language->get('text_paid');
        		} else {
        			$paid_status = $this->language->get('text_not_paid');
        		}

        		$data['products'][] = array(
          			'product_id'     => $product['product_id'],
          			'name'     => $product['name'],
          			'model'    => $product['model'],
          			'option'   => $option_data,
          			'quantity' => $product['quantity'],
          			'paid_status' => $paid_status,
          			'booking_from' => $booking_from,
          			'booking_till' => $booking_till,
          			'duration' => $duration,
          			'amenties' => $amenties,
          			'guest'	   => $people,
								'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
								'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']),
					'order_product_status' => $product['order_product_status'],
        		);
      		}

			// Voucher
			$data['vouchers'] = array();

			$vouchers = $this->model_account_order->getOrderVouchers($order_id);

			foreach ($vouchers as $voucher) {
				$data['vouchers'][] = array(
					'description' => $voucher['description'],
					'amount'      => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value'])
				);
			}

      		$data['totals'] = array();

      		$totals = $this->model_account_customerpartner->getOrderTotals($order_id);

    if($totals AND isset($totals[0]['total']))
				$data['totals'][]['total'] = $this->currency->format($totals[0]['total'], $order_info['currency_code'], $order_info['currency_value']);

			$data['comment'] = nl2br($order_info['comment']);

      		$data['order_status_id'] = $order_info['order_status_id'];

      	}else{
      		$data['errorPage'] = true;
      		$data['order_status_id'] = '';
      	}

      	if($data['booking_status'])
  			$data['action'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res_booking&order_id='.$order_id, '', 'true');
  		else
  			$data['action'] = '';
  		$data['continue'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', 'true');
  		$data['order_invoice'] = $this->url->link('account/customerpartner/soldinvoice&order_id='.$order_id, '', 'true');
  		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_res_booking' , $data));

	}
  	// file download code
  	public function download() {
		$this->load->model('tool/upload');

		if (isset($this->request->get['code'])) {
			$code = $this->request->get['code'];
		} else {
			$code = 0;
		}

		$upload_info = $this->model_tool_upload->getUploadByCode($code);

		if ($upload_info) {
			$file = DIR_UPLOAD . $upload_info['filename'];
			$mask = basename($upload_info['name']);

			if (!headers_sent()) {
				if (is_file($file)) {
					header('Content-Type: application/octet-stream');
					header('Content-Description: File Transfer');
					header('Content-Disposition: attachment; filename="' . ($mask ? $mask : basename($file)) . '"');
					header('Content-Transfer-Encoding: binary');
					header('Expires: 0');
					header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
					header('Pragma: public');
					header('Content-Length: ' . filesize($file));

					readfile($file, 'rb');
					exit;
				} else {
					exit('Error: Could not find file ' . $file . '!');
				}
			} else {
				exit('Error: Headers already sent out!');
			}
		} else {
			$this->load->language('error/not_found');

			$this->document->setTitle($this->language->get('heading_title'));

			$data['heading_title'] = $this->language->get('heading_title');

			$data['text_not_found'] = $this->language->get('text_not_found');

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', '', 'true')
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('error/not_found', '', 'true')
			);

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('error/not_found', $data));
		}
	}
}
?>
