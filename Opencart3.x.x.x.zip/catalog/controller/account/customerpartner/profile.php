<?php
class ControllerAccountCustomerpartnerProfile extends Controller {

	private $error = array();

	public function index() {

		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/profile', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));

		$this->language->load('account/customerpartner/profile');
		$this->document->setTitle($this->language->get('heading_title'));

		$this->document->addScript('admin/view/javascript/summernote/summernote.js');
		$this->document->addStyle('admin/view/javascript/summernote/summernote.css');
		$this->document->addStyle('catalog/view/theme/default/stylesheet/MP/sell.css');


		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->load->model('account/customerpartner');
			$this->model_account_customerpartner->updateProfile($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('account/customerpartner/profile', '', 'true'));
		}

		$partner = $this->model_account_customerpartner->getProfile();


		if($partner) {

			$this->load->model('tool/image');

			if ($partner['avatar'] && file_exists(DIR_IMAGE . $partner['avatar'])) {
					$partner['avatar'] = $this->model_tool_image->resize($partner['avatar'], 100, 100);
			} else {
				$partner['avatar'] = $this->model_tool_image->resize('no_image.png',100, 100);;

			}

			if ($partner['companybanner'] && file_exists(DIR_IMAGE . $partner['companybanner'])) {
					$partner['companybanner'] = $this->model_tool_image->resize($partner['companybanner'], 100, 100);
			} else {
				$partner['companybanner'] = $this->model_tool_image->resize('no_image.png', 100, 100);;
			}

			if ($partner['companylogo'] && file_exists(DIR_IMAGE . $partner['companylogo'])){
				$partner['companylogo'] = $this->model_tool_image->resize($partner['companylogo'], 100, 100);
			} else {
				$partner['companylogo'] = $this->model_tool_image->resize('.png', 100, 100);;
			}
			if($partner['country']) {
				$partner['country'] = $partner['country'];
			} else {
				$partner['country'] = "";
			}
			if($partner['countrylogo']) {
				$partner['countrylogo'] = $partner['countrylogo'];
			} else {
				$partner['countrylogo'] = HTTP_SERVER."image/flags/".strtolower($partner['country']).'.png';
			}
			$data['storeurl'] =$this->url->link('customerpartner/profile&id='.$this->customer->getId(),'','true');
		}

		$data['allowed'] = $this->config->get('module_wk_hotelbooking_res_allowedprofilecolumn');

		$post_array = array(
			'twitterId' => 'twitterid',
			'facebookId' => 'facebookid',
			'companyLocality' => 'companylocality',
			'country' => 'country',
			'countryLogo'		=> 'countrylogo',
			'shortProfile' => 'shortprofile',
			'paypalid'		=> 'paypalid',
			'otherpayment' => 'otherpayment',
			'gender' => 'gender',

		);
		if($this->request->post) {
			foreach ($post_array as $key => $value) {
				if(isset($this->request->post[$key])) {
					$partner[$value] = $this->request->post[$key];
				}
			}
		}


		$data['partner'] = $partner;


		$data['countries'] = $this->model_account_customerpartner->getCountry();

      	$data['breadcrumbs'] = array();

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),
        	'separator' => false
      	);

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('account/account'),
        	'separator' => $this->language->get('text_separator')
      	);

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('account/customerpartner/profile', '', 'true'),
        	'separator' => $this->language->get('text_separator')
      	);

		$data['button_continue'] = $this->language->get('button_continue');
		$data['button_back'] = $this->language->get('button_back');

		$data['customer_details'] = array(
									'firstname' => $this->customer->getFirstName(),
									'lastname' => $this->customer->getLastName(),
									'email' => $this->customer->getEmail()
									);


		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		// if (isset($this->error['screenname_error'])) {
		// 	$data['screenname_error'] = $this->error['screenname_error'];
		// } else {
		// 	$data['screenname_error'] = '';
		// }

		if (isset($this->error['companyname_error'])) {
			$data['companyname_error'] = $this->error['companyname_error'];
		} else {
			$data['companyname_error'] = '';
		}

		if (isset($this->error['paypal_error'])) {
			$data['paypal_error'] = $this->error['paypal_error'];
		} else {
			$data['paypal_error'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['action'] = $this->url->link('account/customerpartner/profile', '', 'true');
		$data['back'] = $this->url->link('account/account', '', 'true');
		$data['view_profile'] = $this->url->link('customerpartner/profile&id='.$this->customer->getId(), '', 'true');

		$data['isMember'] = true;

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('account/customerpartner/profile', $data));

	}

	public function validateForm() {
		$this->registry->set('Htmlfilter', new Htmlfilter($this->registry));
		$error = false;
		$this->language->load('account/customerpartner/profile');
		// if(strlen($this->request->post['screenName']) < 1) {
		// 	$this->error['screenname_error'] = $this->language->get('error_seo_keyword');
		// 	$this->error['warning'] = $this->language->get('error_check_form');
		// 	$error = true;
		// }

		$this->request->post['shortProfile'] = htmlentities($this->Htmlfilter->HTMLFilter(html_entity_decode($this->request->post['shortProfile']),'',true));


		if (isset($this->request->post['paypalid']) && $this->request->post['paypalid']) {
			if(!filter_var($this->request->post['paypalid'], FILTER_VALIDATE_EMAIL)) {
				$this->error['paypal_error'] = $this->language->get('error_paypal');
				$this->error['warning'] = $this->language->get('error_check_form');
				$error = true;
			}
		}

		$files = $this->request->files;

		foreach ($files as $key => $value) {
	  		if (isset($value['name']) && !empty($value['name']) && is_file($value['tmp_name'])) {
				// Sanitize the filename
				$filename = basename(html_entity_decode($value['name'], ENT_QUOTES, 'UTF-8'));

				// Validate the filename length
				if ((utf8_strlen($filename) < 3) || (utf8_strlen($filename) > 255)) {
					$this->error['warning'] = $this->language->get('error_filename');
					$error = true;
				}

				// Allowed file extension types
				$allowed = array(
					'jpg',
					'jpeg',
					'gif',
					'png'
				);

				if (!in_array(utf8_strtolower(utf8_substr(strrchr($filename, '.'), 1)), $allowed)) {
					$this->error['warning'] = $this->language->get('error_filetype');
					$error = true;
				}

				// Allowed file mime types
				$allowed = array(
					'image/jpeg',
					'image/pjpeg',
					'image/png',
					'image/x-png',
					'image/gif'
				);

				if (!in_array($value['type'], $allowed)) {
					$this->error['warning'] = $this->language->get('error_filetype');
					$error = true;
				}

				// Check to see if any PHP files are trying to be uploaded
				$content = file_get_contents($value['tmp_name']);

				if (preg_match('/\<\?php/i', $content)) {
					$this->error['warning'] = $this->language->get('error_filetype');
					$error = true;
				}

				// Return any upload error
				if ($value['error'] != UPLOAD_ERR_OK) {
					$this->error['warning'] = $this->language->get('error_upload_' . $value['error']);
					$error = true;
				}

			}
		}

		if($error) {
			return false;
		} else {
			return true;
		}

	}

}
?>
