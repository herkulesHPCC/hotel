<?php
class ControllerAccountCustomerpartnerquery extends Controller
{

    private $error = array();
    private $data = array();

    public function index()
    {
        if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
            $this->session->data['redirect'] = $this->url->link('account/customerpartner/orderlist', '', 'true');
            $this->response->redirect($this->url->link('account/login', '', 'true'));
        }

       $this->load->model('account/customerpartner');

        $data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

        if (!$data['chkIsPartner']) {
            $this->response->redirect($this->url->link('account/account'));
        }
       $this->language->load('account/customerpartner/query');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('account/customerpartner');

        $this->getList();
    }


    protected function getList()
    {
      if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
  			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
  			$this->response->redirect($this->url->link('account/login', '', true));
  		}

  		$this->load->model('account/customerpartner');

  		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

  		if(!$data['chkIsPartner']){
  			$this->response->redirect($this->url->link('account/account'));
  		}
        if (isset($this->request->get['filter_id'])) {
            $filter_id = $this->request->get['filter_id'];
        } else {
            $filter_id = null;
        }

        if (isset($this->request->get['filter_customer'])) {
            $filter_customer = $this->request->get['filter_customer'];
        } else {
            $filter_customer = null;
        }

        if (isset($this->request->get['filter_date'])) {
            $filter_date = $this->request->get['filter_date'];
        } else {
            $filter_date = null;
        }

        if (isset($this->request->get['sort'])) {
            $sort = $this->request->get['sort'];
        } else {
            $sort = 'name';
        }

        if (isset($this->request->get['order'])) {
            $order = $this->request->get['order'];
        } else {
            $order = 'ASC';
        }

        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $filterdata = array(
         'filter_id'                => $filter_id,
         'filter_customer'            => $filter_customer,
         'filter_date'              => $filter_date,
         'sort'                     => $sort,
         'order'                    => $order,
         'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
         'limit'                    => $this->config->get('config_limit_admin'),
        );

        $url = '';

        if (isset($this->request->get['filter_id'])) {
            $url .= '&filter_id=' . $this->request->get['filter_id'];
        }

        if (isset($this->request->get['filter_customer'])) {
            $url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['filter_product'])) {
            $url .= '&filter_product=' . urlencode(html_entity_decode($this->request->get['filter_product'], ENT_QUOTES, 'UTF-8'));
        }


        if (isset($this->request->get['filter_date'])) {
            $url .= '&filter_date=' . urlencode(html_entity_decode($this->request->get['filter_date'], ENT_QUOTES, 'UTF-8'));
        }

        if (isset($this->request->get['page'])) {
            $url .= '&page=' . $this->request->get['page'];
        }

        if ($order == 'ASC') {
            $url .= '&order=DESC';
        } else {
            $url .= '&order=ASC';
        }

        $data['sort_id'] = $this->url->link('account/customerpartner/query');
        $data['sort_customer'] = $this->url->link('account/customerpartner/query');
        $data['sort_status'] = $this->url->link('account/customerpartner/query');
        $data['sort_date'] = $this->url->link('account/customerpartner/query');

        if (isset($this->request->get['sort'])) {
            $url .= '&sort=' . $this->request->get['sort'];
        }

        $this->language->load('account/customerpartner/query');

          $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
               'text'      => $this->language->get('text_home'),
         'href'      => $this->url->link('common/home', $url),
              'separator' => false
        );

        $data['breadcrumbs'][] = array(
               'text'      => $this->language->get('heading_title'),
         'href'      => $this->url->link('account/customerpartner/query', $url),
              'separator' => ' :: '
        );
        //user

        $data['text_confirm'] = $this->language->get('text_r_u_sure');


        $result_total = $this->model_account_customerpartner->viewtotalentry($filterdata);

        $results = $this->model_account_customerpartner->viewtotal($filterdata);
        $data['result_quotelist'] = array();

        foreach ($results as $result) {

            $action = array(
             'text' => $this->language->get('text_edit'),
             'href' => $this->url->link('account/customerpartner/query/getForm', '&id=' . $result['id'])
            );

            $result['status_text'] = $this->language->get('text_status_'.$result['status']);

            $data['result_quotelist'][] = array(
             'selected' => false,
             'id' => $result['id'],
             'customer_name' => $result['customer_name'],
             'email' => $result['email'],
             'message' => substr(utf8_decode($result['message']), 0, 35),
             'date'   => $result['date_added'],
             'action'     => $action,
            );
        }

        $data['action'] = $this->url->link('account/customerpartner/query');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->session->data['success'])) {
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        } else {
            $data['success'] = '';
        }

        $pagination = new Pagination();
        $pagination->total = $result_total;
        $pagination->page = $page;
        $pagination->limit = $this->config->get('config_admin_limit');
        $pagination->text = $this->language->get('text_pagination');
        $pagination->url = $this->url->link('account/customerpartner/query', $url . '&page={page}');

        $data['pagination'] = $pagination->render();

        $data['results'] = sprintf($this->language->get('text_pagination'), ($result_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($result_total - $this->config->get('config_limit_admin'))) ? $result_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $result_total, ceil($result_total / $this->config->get('config_limit_admin')));

        $data['sort'] = $sort;
        $data['order'] = $order;
        $data['filter_id'] = $filter_id;

        $data['filter_customer'] = $filter_customer;
        $data['filter_date'] = $filter_date;
        $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
  			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
  			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
  			$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('account/customerpartner/query', $data));

    }
    public function getForm()
    {
      if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
  			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
  			$this->response->redirect($this->url->link('account/login', '', true));
  		}

  		$this->load->model('account/customerpartner');

  		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

  		if(!$data['chkIsPartner']){
  			$this->response->redirect($this->url->link('account/account'));
  		}
        if (isset($this->request->get['id'])) {
            $id = $this->request->get['id'];
        } else {
            $id = 0;
        }

        if (isset($this->request->get['filter_name'])) {
            $filter_name = $this->request->get['filter_name'];
        } else {
            $filter_name = null;
        }

        $this->language->load('account/customerpartner/query');

        $data['heading_title'] = sprintf($this->language->get('heading_title_view'), $id);

        $this->document->setTitle($data['heading_title']);


        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
               'text'      => $this->language->get('text_home'),
         'href'      => $this->url->link('common/home'),
              'separator' => false
        );

        $data['breadcrumbs'][] = array(
               'text'      => $this->language->get('heading_title'),
         'href'      => $this->url->link('account/customerpartner/query'),
              'separator' => ' :: '
        );

        $data['save'] = $this->url->link('account/customerpartner/query/update');

        $data['back'] = $this->url->link('account/customerpartner/query');

        $this->load->model('account/customerpartner');
        $this->load->model('tool/image');

        $data['admin_name'] = $this->config->get('wk_pro_quote_name');

        $results_message = $this->model_account_customerpartner->viewtotalMessageBy($id);
        $this->load->model('catalog/product');

        if ($results_message) {
            if($results_message['room_id']) {
                $room_info = $this->model_catalog_product->getProduct($results_message['room_id']);
            } else {
                $room_info['product_id'] = 0;
                $room_info['name'] = '';
                $room_info['model'] = '';
            }

            if (isset($room_info) && isset($room_info['image'])) {
                $image = $this->model_tool_image->resize($room_info['image'], 200, 200);
            } else {
                $image = $this->model_tool_image->resize('placeholder.png', 200, 200);
            }
            $data['message'] = array(
             'id' => $results_message['id'],
             //'email' => $results_message['email'],
             'customer_name' => $results_message['customer_name'],
             'product_name' => $room_info['name'],
             'product_id' => $room_info['product_id'],
             'product_href' => $this->url->link('product/product&product_id='.$room_info['product_id']),
             'image' => $image,
             'message' => $results_message['message'],
             'hotel' => $room_info['model'],
             'from' => $results_message['bfrom'],
             'till' => $results_message['bto']
            );
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('account/customerpartner/query_details', $data));
    }
}
?>
