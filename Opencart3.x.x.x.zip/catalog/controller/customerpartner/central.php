<?php
class ControllerCustomerpartnerCentral extends Controller
{
    private $error = array();
    private $data = array();

    public function index()
    {
        // if ($this->request->server['REQUEST_METHOD'] == 'POST') {
        //     $this->language->load('extension/module/wk_hotel_booking');
        //     $this->load->model('account/customerpartner');
        //     if (!isset($this->request->post['agree']) || !$this->request->post['agree']) {
        //         $this->session->data['agree_error'] = $this->language->get('agree_error');
        //     } elseif (!$this->request->post['country_id'] || !$this->customer->isLogged() || $this->model_account_customerpartner->chkIsPartner()) {
        //         $this->session->data['something_error'] = $this->language->get('something_error');
        //     } else {
        //         $this->model_account_customerpartner->becomePartner($this->request->post['country_id'], $this->customer->getId());
        //         if (!$this->config->get('module_wk_hotelbooking_res_partnerapprov')) {
        //             $this->session->data['text_req_success'] = $this->language->get('text_req_success');
        //         }
        //     }
        //     $this->response->redirect($this->url->link('customerpartner/central'));
        // }
        $this->load->model('account/customerpartner');

        if($this->customer->isLogged()) {
          $data['logged'] = true;
          $data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

          if($data['chkIsPartner']) {
            $this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel'));
          } else {
            $data['show_step3'] = true;
          }
        } else {
          $data['logged'] = false;
          $data['show_step3'] = false;
        }
        $data['custom_fields'] = array();

    		$this->load->model('account/custom_field');

        $register_error_array = array (
          'warning',
          'firstname',
          'lastname',
          'email',
          'telephone',
          'custom_field',
          'password',
          'confirm'
        );

        foreach ($register_error_array as $key => $value) {
          $data['error_'.$value] = '';
        }

  			$data['error_custom_field'] = array();

    		if (isset($this->error['confirm'])) {
    			$data['error_confirm'] = $this->error['confirm'];
    		} else {
    			$data['error_confirm'] = '';
    		}
    		$custom_fields = $this->model_account_custom_field->getCustomFields();
    		foreach ($custom_fields as $custom_field) {
    			if ($custom_field['location'] == 'account') {
    				$data['custom_fields'][] = $custom_field;
    			}
    		}

    		if (isset($this->request->post['custom_field']['account'])) {
    			$data['register_custom_field'] = $this->request->post['custom_field']['account'];
    		} else {
    			$data['register_custom_field'] = array();
    		}
        $data['countries'] = $this->model_account_customerpartner->getCountry();
        $this->language->load('extension/module/wk_hotel_booking');
        $this->language->load('account/customerpartner/profile');
        $this->load->language('account/register');

        $server = $this->request->server['HTTPS']  ? $this->config->get('config_ssl') : $this->config->get('config_url');

        $data['background_image'] = $this->config->get('module_wk_hotelbooking_res_central');

        if ($data['background_image']) {
            $data['background_image'] = $server.'image/'.$data['background_image'];
        } else {
            $data['background_image'] = $server.'image/placeholder.png';
        }

        if (is_file(DIR_IMAGE . $this->config->get('config_icon'))) {
            $this->document->addLink($server . 'image/' . $this->config->get('config_icon'), 'icon');
        }
        if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
            $data['logo'] = $server . 'image/' . $this->config->get('config_logo');
        } else {
            $data['logo'] = '';
        }

        $this->document->setTitle($this->language->get('heading_title_sell'));

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
            'href'      => $this->url->link('common/home'),
            'separator' => false
          );
        $buttontitle = $this->config->get('module_wk_hotelbooking_res_sellbuttontitle');
        $sellerHeader = $this->config->get('module_wk_hotelbooking_res_sellheader');

        $data['sell_title'] = $buttontitle[$this->config->get('config_language_id')];
        $data['sell_header'] = $sellerHeader[$this->config->get('config_language_id')];
        $this->document->addStyle('catalog/view/theme/default/stylesheet/MP/sell.css');

        $data['action'] = $this->url->link('customerpartner/central');
        $data['button_continue'] = $this->language->get('button_continue');

        $data['heading_title'] = $this->language->get('heading_title_sell');

        $data['tabs'] = array();

        $data['action1'] = $this->url->link('customerpartner/central/validateLogin','',true);

        $this->load->model('extension/module/wk_hotel_booking');

        $wk_hotel_tab = $this->model_extension_module_wk_hotel_booking->getHoteltab();

        if ($wk_hotel_tab) {
            foreach ($wk_hotel_tab as $key => $value) {
                $text = $value['description'];
                $text = trim(html_entity_decode($text));
                $data['tabs'][] = array(
                    'id' => $value['module'],
                    'hrefValue' => $value['heading'],
                    'description' => trim(html_entity_decode($value['description'])),
                );
            }
        }

        $data['action2'] = $this->url->link('customerpartner/central/validateRegister');
        $data['action3'] = $this->url->link('customerpartner/central/registerSeller');

        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/hotel_header');

        $this->response->setOutput($this->load->view('customerpartner/central', $data));
    }

    public function validateLogin() {
      if ($this->request->server['REQUEST_METHOD'] != 'POST')
        return;
      $json  = array();

      $this->load->language('account/login');

      $this->load->model('account/customer');

      $postData = $this->request->post;
      include_once(DIR_APPLICATION . 'controller/account/login.php');
      $loginclosure = Closure::bind(function (ControllerAccountLogin $loginObject) use($postData){
        $loginObject->validate($postData);
        return $loginObject->error;
      }, null, 'ControllerAccountLogin');
      $loginObject = new ControllerAccountLogin($this->registry);
      $return_array = $loginclosure($loginObject);
      if(isset($return_array['warning'])) {
        $json['warning'] = $return_array['warning'];
      } else {
        $this->load->model('account/customerpartner');

    		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();
    		if(!$data['chkIsPartner']) {
          $this->customer->logout();
          $json['warning'] = " No Seller Found";
        } else {
            $json['redirect'] = $this->url->link('customerpartner/central','',true);
        }
      }
      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }

    public function validateRegister($from_controller = false) {
      if ($this->request->server['REQUEST_METHOD'] != 'POST')
        return;
      $json  = array();

      $this->load->language('account/register');

      $this->load->model('account/customer');
      $this->request->post['agree'] = true;
      $postData = $this->request->post;
      include_once(DIR_APPLICATION . 'controller/account/register.php');
      $registerClouser = Closure::bind(function (ControllerAccountRegister $registerObejct) use($postData) {
        $registerObejct->validate($postData);
        if(!isset($registerObejct->error['telephone'])) {
          if ($postData['telephone'] && !preg_match('/^[0-9\/-]+$/', $postData['telephone'])) {
            $registerObejct->error['telephone']	 = 'Please provide valid contact number';
          }
        }
        return $registerObejct->error;
      }, null, 'ControllerAccountRegister');
      $registerObejct = new ControllerAccountRegister($this->registry);
      $return_array = $registerClouser($registerObejct);
      if($return_array) {
        $json = $return_array;
      } else {
        if($from_controller) {
          return $json;
        }
        $json['toggle'] = true;
      }
      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
    function registerSeller() {
      if ($this->request->server['REQUEST_METHOD'] != 'POST')
        return;

      if(isset($this->request->post['firstname']))  {
        $return_validation = $this->validateRegister(1);
      } else {
        $return_validation = array();
      }
      $this->load->model('account/customer');
      $this->load->model('account/customerpartner');
      $customer_id = $this->customer->getId();
      
      if(!$return_validation && !$customer_id) {
        $customer_id = $this->model_account_customer->addCustomer($this->request->post);
        $this->model_account_customer->deleteLoginAttempts($this->request->post['email']);

  			$this->customer->login($this->request->post['email'], $this->request->post['password']);
        if($customer_id) {
          $this->load->model('account/customerpartner');
          $this->model_account_customerpartner->becomePartner($this->request->post['country_id'],$customer_id);
          $this->model_account_customerpartner->updateProfile($this->request->post);
        }
      } else if($customer_id) {
        $this->load->model('account/customerpartner');
        $this->model_account_customerpartner->becomePartner($this->request->post['country_id'],$customer_id);
        $this->model_account_customerpartner->updateProfile($this->request->post);
      }

      $json['customer_id'] = $customer_id;
      if($customer_id) {
        $json['redirect'] = $this->url->link('account/account','',true);
      }
      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($json));
    }
}
