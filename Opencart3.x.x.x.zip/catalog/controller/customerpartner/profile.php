<?php

/**
* @version 2.2.0.0
* @copyright Webkul Software Pvt Ltd
*/

class ControllerCustomerpartnerProfile extends Controller
{

    /**
     * [$error description] Array to contain all errors
     * @var array
     */
    private $error = array();

    public function index()
    {
        if (!isset($this->request->get['id'])) {
            $this->request->get['id'] = 0;
        }

        $data['id'] = $this->request->get['id'];

        $this->load->model('tool/image');

        $this->load->model('customerpartner/master');

        $this->language->load('customerpartner/profile');

        $this->document->setTitle($this->language->get('heading_title'));
				$this->document->addScript('catalog/view/javascript/hotel/handlebar.js');
				$this->document->addScript('catalog/view/javascript/hotel/customhelper.js');
        $this->language->load('customerpartner/feedback');


        $this->language->load('extension/module/wk_hotel_booking');


        $data['logged'] = $this->customer->isLogged();
        $data['send_mail'] = $this->url->link('account/customerpartner/sendmail', '', 'true');
        $data['mail_for'] = '&contact_seller=true';

        $this->document->addStyle('catalog/view/theme/default/stylesheet/MP/profile.css');

        if (isset($this->request->get['collection'])) {
            $data['showCollection'] = true;
        } else {
            $data['showCollection'] = false;
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text'      => $this->language->get('text_home'),
                    'href'      => $this->url->link('common/home', '', true),
            'separator' => false
          );


        $partner = $this->model_customerpartner_master->getProfile($this->request->get['id']);
        if ($partner) {
            $data['breadcrumbs'][] = array(
                'text'      => $partner['firstname'].' '.$partner['lastname'],
                'href'      => $this->url->link('customerpartner/profile&id='.$this->request->get['id'], '', true),
                'separator' => false
            );
            $data['current'] = $this->url->link('customerpartner/profile&id='.$this->request->get['id'], '', true);
        }
        $this->load->model('extension/module/wk_hotel_booking');
        $data['review_buitton'] = ($this->customer->getId()!=$this->request->get['id']?true:false);
        $data['customer_reviews'] = $this->model_extension_module_wk_hotel_booking->getReviews($this->request->get['id']);
        $this->load->language('extension/module/wk_hotel_booking');
        $data['text_see_more'] = $this->language->get('text_see_more');
        $data['text_book_from'] = $this->language->get('text_book_from');
        $data['text_book_till']     = $this->language->get('text_book_till');

        if (!$partner) {
            $this->response->redirect($this->url->link('error/not_found'));
        }

        if ($partner['companybanner'] && file_exists(DIR_IMAGE . $partner['companybanner'])) {
            $partner['companybanner'] = HTTP_SERVER.'image/'.$partner['companybanner'];
        } else {
            if ($partner['companybanner'] != 'removed') {
                $partner['companybanner'] = HTTP_SERVER.'image/placeholder.png';
            } else {
                $partner['companybanner'] = HTTP_SERVER.'image/placeholder.png';
            }
        }

       if ($partner['shortprofile']) {
          $partner['shortprofile'] = html_entity_decode($partner['shortprofile']);
      } else {
          $partner['shortprofile'] = 0;
      }

        if ($partner['companylogo'] && file_exists(DIR_IMAGE . $partner['companylogo'])) {
            $partner['companylogo'] = $this->model_tool_image->resize($partner['companylogo'], 300, 80);
        } else {
            $partner['companylogo'] = $this->model_tool_image->resize('placeholder.png', 300, 80);
        }

        if ($partner['avatar'] && file_exists(DIR_IMAGE . $partner['avatar'])) {
            $partner['avatar'] = $this->model_tool_image->resize($partner['avatar'], 120, 120);
        } else {
            $partner['avatar'] = $this->model_tool_image->resize('placeholder.png', 120, 120);
        }

        if ($this->config->get('module_wk_hotelbooking_res_profile_email')) {
            $data['email'] = 1;
        } else {
            $data['email'] = 0;
        }

        if ($this->config->get('module_wk_hotelbooking_res_profile_telephone')) {
            $data['telephone'] = 1;
        } else {
            $data['telephone'] = 0;
        }

        if ($this->config->get('module_wk_hotelbooking_res_customercontactseller')) {
            $data['customercontactseller'] = 1;
        } else {
            $data['customercontactseller'] = 0;
        }

        $data['customer_id'] = $this->customer->getId();

        $data['partner'] = $partner;

        $data['feedback_total'] = $this->model_customerpartner_master->getAverageFeedbackTotal($this->request->get['id']);
				$data['text_total_reviews'] = sprintf($this->language->get('text_total_reviews'),  $data['feedback_total']);
        $data['text_avg_reviews'] = sprintf($this->language->get('text_avg_reviews'),  ceil($this->model_customerpartner_master->getAverageFeedback($this->request->get['id'])/5));
        $this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyBl23lK0uCqs5NFyXCOnatkjOyhm2Gt1Do');
        $data['feedback'] = $this->url->link('customerpartner/profile/feedback&id='.$this->request->get['id'], '', 'true');
        $data['writeFeedback'] = $this->url->link('customerpartner/profile/writeFeedback&id='.$this->request->get['id'], '', 'true');

        $data['product_feedback_total'] = $this->model_customerpartner_master->getTotalProductFeedbackList($this->request->get['id']);
        $this->session->data['redirect'] = $this->url->link('customerpartner/profile&id='.$this->request->get['id'], '', 'true');
        $data['login'] = $this->url->link('account/login', '', 'true');
        $data['seller_id'] = $this->request->get['id'];
        $data['isLogged'] = $this->customer->isLogged();

        $data['marketplace_customercontactseller'] = $this->config->get('marketplace_customercontactseller');
        $data['header'] = $this->load->controller('common/header');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('customerpartner/profile', $data));
    }
    /**
     * [writeFeedback to store customers feedbacks]
     * @return [json] [string containing successful/unsuccessful message]
     */
    public function writeFeedback()
    {
        $this->load->language('customerpartner/feedback');

        $json = array();

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 25)) {
                $json['error'] = $this->language->get('error_name');
            }

            if ((utf8_strlen($this->request->post['text']) < 25) || (utf8_strlen($this->request->post['text']) > 1000)) {
                $json['error'] = $this->language->get('error_text');
            }

            if (empty($this->request->post['quality_rating']) || $this->request->post['quality_rating'] < 0 || $this->request->post['quality_rating'] > 5) {
                $json['error'] = $this->language->get('error_quality_rating');
            }

            if (empty($this->request->post['price_rating']) || $this->request->post['price_rating'] < 0 || $this->request->post['price_rating'] > 5) {
                $json['error'] = $this->language->get('error_price_rating');
            }

            if (empty($this->request->post['value_rating']) || $this->request->post['value_rating'] < 0 || $this->request->post['value_rating'] > 5) {
                $json['error'] = $this->language->get('error_value_rating');
            }

            if (!isset($json['error'])) {
                $this->load->model('customerpartner/master');
                $this->model_customerpartner_master->saveFeedback($this->request->post, $this->request->get['id']);
                $json['success'] = $this->language->get('text_success');
            }
        }

        $this->response->addHeader('Content-Type: application/json');

        $this->response->setOutput(json_encode($json));
    }

    public function getHotels()
    {
        if ($this->request->server['REQUEST_METHOD']=="POST") {
            if (isset($this->request->post['id']) && $this->request->post['id']) {
								$this->load->model('extension/module/wk_hotel_booking');
								$data['language'] = $this->load->language('customerpartner/profile');
								$this->load->model('tool/image');
								$page = isset($this->request->get['page']) ? $this->request->get['page'] : 0;
                $data['hotels'] = $this->model_extension_module_wk_hotel_booking->getSellerHotels($this->request->post['id'],$page);
                $totalSellerhotels= $this->model_extension_module_wk_hotel_booking->totalSellerhotels($this->request->post['id'],$page);
                $data['more']  = true;
                if($page*4+4 >= $totalSellerhotels) {
                  $data['more'] = false;
                }
                $data['counthotels'] = count($data['hotels']);
                $data['sellerHotels'] = array();
                if ($data['hotels']) {
                    foreach ($data['hotels'] as $key => $hotel) {
                        if (file_exists(DIR_IMAGE . $hotel['image'])) {
                          $image =HTTP_SERVER.'image/'.$hotel['image'];
                        } else {
                          $image = $this->model_tool_image->resize('placeholder.png', 100, 100);
                        }
                        $data['sellerHotels'][]=array(
                                    'name' => $hotel['name'],
                                    'description'=> utf8_substr(strip_tags(html_entity_decode($hotel['description'], ENT_QUOTES, 'UTF-8')), 0,200),
                                    'checkin' => $hotel['checkin'].':00 '.($hotel['checkin_ap']?"AM":"PM"),
                                    'checkout' => $hotel['checkout'].':00 '.($hotel['checkout_ap']?"AM":"PM"),
                                    'image' =>$image,
                                    'email' => $hotel['email'],
                                    'website' => $hotel['website'],
                                    'contact' => $hotel['contact'],
                                    'faxno' => $hotel['faxno'],
                                    'address' => $hotel['address'],
                                    'latitude' => $hotel['latitude'],
                                    'longitude' => $hotel['longitude'],
                                    'href'  => $this->url->link('extension/module/wk_hotel&hotel_id='.$hotel['category_id'], '', true),

                                    );
                    }
                }
            }
						$this->response->addHeader('Content-Type:application/json');
						$this->response->setOutput(json_encode($data));
        }
    }
}
