<?php
class ControllerExtensionModulewkhotelPopular extends Controller {
		public function index() {
      $data = array();
      if(!$this->config->get('module_wk_hotelbooking_res_status'))
        return;

      $this->load->language('extension/module/wk_hotel_booking');

      $this->document->addStyle('catalog/view/theme/default/stylesheet/hotel/Mp_hotel.css');
      $this->document->addScript('catalog/view/javascript/hotel/handlebar.js');
      return $this->load->view('extension/module/wk_hotel_popular',$data);
    }

    public function loadHotels() {

			if ($this->request->server['HTTPS']) {
					$server = $this->config->get('config_ssl');
			} else {
			  	$server = $this->config->get('config_url');
			}
      $popular_hotels = $this->config->get('module_wk_hotel_popular_hotel_name');
			$page = isset($this->request->get['page'])?$this->request->get['page']:0;
			$start = 4*$page;
			if($popular_hotels) {
				$popular_hotels = array_slice($popular_hotels,$start,4);
			}
      $data = array();
      $this->load->model('catalog/category');
			$this->load->model('extension/module/wk_hotel_booking');
      $this->load->model('tool/image');
      if($popular_hotels) {
        foreach ($popular_hotels as $key => $value) {

          $category_info = $this->model_catalog_category->getCategory($value);
					if(!$category_info) {
						continue;
					}
          if ($category_info['image']) {
            $thumb = $server.'image/'.$category_info['image'];
          } else {
            $thumb = $this->model_tool_image->resize('placeholder.png', $this->config->get('theme_' . $this->config->get('config_theme') . '_image_thumb_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_thumb_height'));
          }
					$review_info_total =0 ;
					$review_info = $this->model_extension_module_wk_hotel_booking->getReview($category_info['category_id']);
					if($review_info && isset($review_info[0]) && isset($review_info[0]['rating'])) {
						$review_info_total = $review_info[0]['rating'];
					}
          $data[] = array(
                'hotel_id' => $category_info['category_id'],
                'image'    => $thumb,
                'name'     => strip_tags(html_entity_decode($category_info['name'],ENT_QUOTES, 'UTF-8')),
                'description' => utf8_substr(trim(strip_tags(html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8'))), 0, 250) . '..',
								'href' => $this->url->link('extension/module/wk_hotel&hotel_id='.$category_info['category_id'],'',true),
								'review' => $review_info_total
            );
        }
      }
      $this->response->addHeader('Content-Type: application/json');
      $this->response->setOutput(json_encode($data));
    }
}
