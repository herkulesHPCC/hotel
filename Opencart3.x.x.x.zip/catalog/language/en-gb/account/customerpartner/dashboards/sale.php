<?php
// Heading
$_['heading_title'] = 'Total Amount';

// Text
$_['text_view']     = 'View more...';
