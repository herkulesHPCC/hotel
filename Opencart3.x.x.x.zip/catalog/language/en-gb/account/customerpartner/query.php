<?php
// Heading Goes here:
$_['heading_title']      	  = 'Queries List';
$_['qheading_title']      	  = 'Queries List';
$_['heading_title']      	  = 'Queries List';
$_['heading_title_view']	  = 'Query Id %d';
$_['review_heading_title']  = 'Query Details';
// Text
$_['text_module']     	 	  = 'Modules';
$_['text_success']    	 	  = 'Success: You have modified and updated Queries List!';
$_['text_success_update']     = 'Success: You have updated This Queries List !';

$_['tab_quote']      	  	  = 'Queries Details';
$_['text_message']      	  = 'Conversations';
$_['text_edit']    	          = 'Edit';
//user
$_['text_base_price']      	  = 'Actual Price';
$_['text_quotes_price']       = 'Queries Price';
$_['text_list']       		  = 'Queries List';
$_['text_date']   			  = 'Date Added';
$_['text_id']       		  = 'Query Id';
$_['text_action']     		  = 'Action';
$_['text_status'] 		      = 'Status ';
$_['text_product_name']    	  = 'Room';
$_['text_option']    		  = 'Option(s)';
$_['text_option_name']    	  = 'Name';
$_['text_option_price']    	  = 'Price';
$_['text_option_value']    	  = 'Value';
$_['text_view'] 		      = 'View ';
$_['text_delete'] 		      = 'Delete ';
$_['text_quantity']		      = 'Quantity ';
$_['text_no_recored'] 		  = 'No Data Found !! ';
$_['text_r_u_sure'] 		  = 'Are You Sure !! ';
$_['text_customer_name'] 	  = 'Customer';
$_['text_ask'] 	  			  = 'Message';
$_['text_send_message'] 	  = 'Send Message';


// buttons
$_['button_clrfilter']   	  = 'Clear Filter';
$_['button_filter']   		  = 'Filter';
$_['button_back']    	      = 'Back';
$_['button_save']    	      = 'Save';
$_['button_cancel']    	      = 'Cancel';
$_['button_delete']    	      = 'Delete';
$_['button_alert']    	      = 'Alert View';
$_['button_table']    	      = 'Table View';

// Error
$_['error_permission']  	  = 'Warning: You do not have permission to modify Queries List';
$_['error_warning']  	 	  = 'Warning: Sorry Queries Already has been approved';

$_['text_hotel']			 = 'Hotel';
$_['text_from']				 = 'From';
$_['text_till']				 = 'Till';

$_['text_addproduct'] 		  = 'Add product for quote';
$_['text_addquantity']		  = 'Add minimum quantity for quote';
$_['manage_heading_title']      	  = 'Manage Product For Queries';
?>
