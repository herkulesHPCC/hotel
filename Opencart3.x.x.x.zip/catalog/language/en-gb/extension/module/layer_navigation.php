<?php
// Heading
$_['heading_title']     	         = 'Hotels';

//Text
$_['text_product_filter'] 	       =	'Room Filter';
$_['text_sortby'] 			           =	'Sort By:';
$_['text_limit'] 			             =	'Show:';
$_['text_clearAll'] 		           =	'Reset';
$_['text_price'] 			             =	'Price';

$_['text_refine_hotels']	         =  'All Hotels';

$_['text_imgadd']			             =	'Larger This Image';
$_['text_img']				             =	'Go to Room';
$_['text_clrslection']		         =	'Clear selection';
$_['text_price_range']		         =	'Price Range:';
$_['text_min']				             =	'Min:';
$_['text_max']				             =	'Max:';
$_['textasc']					             =	'ASC';
$_['textdesc']					           =	'DESC';
$_['text_noproduct']			         =	'There are no rooms to list on your selection.';

$_['text_book_now']				         =  'Book Now';
$_['text_room_empty']			         = 'There are no rooms to list in this hotel.';

$_['text_filterheading_title']	   = 'Filter Hotels';
$_['text_read_more']               = 'Read More';
$_['text_address']                 = 'Address';
$_['text_view_details']            = 'View Details';
$_['text_missed']                  = 'You missed it, no more rooms';
$_['text_hurry']                   = 'Hurry up %s type of room(s) left';
$_['text_km']                      = ' Km.';
$_['text_interested']              = 'You might also be interested in';
$_['text_map']                     = 'Map';
$_['text_empty']                   = 'There are no hotel to list in this search.';
$_['text_distances']               = 'Distance(Low->High)';
$_['text_distance_rev']            = 'Distance(High->low)';
$_['text_fixed']                   = 'Fixed Amenities';
$_['text_optionals']               = 'Optionals Amenities';
$_['text_reset_all']               = 'Reset All';
?>
