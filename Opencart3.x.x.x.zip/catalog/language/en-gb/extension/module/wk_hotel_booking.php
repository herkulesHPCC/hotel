<?php
//search page
$_['text_main_description'] 			       = 	'SEARCH HOTELS AND ROOMS';
$_['text_secondary_description'] 		     = 	'Echo Park actually pour-over,art party Banksy Thundercats cred Echo Park actually pour-over,art party Banksy Thundercats cred Echo Park actually pour-over,art party Banksy Thundercats cred ';
$_['text_search_city'] 					         = 	'Enter City Name/Hotel Name';
$_['text_check_in'] 					           = 	'Check in Date';
$_['text_choose_check_in'] 				       = 	'Choose Check in Date';
$_['text_check_out'] 				             = 	'Check out Date';
$_['text_choose_check_out'] 			       = 	'Choose Check out Date';
$_['text_people']						             =   'Choose Guests';
$_['text_people_detial'] 				         = 	'1 people 1 room';
$_['text_adult'] 						             = 	'Adult';
$_['text_children'] 					           = 	'Children';
$_['text_done'] 						             = 	'Done';
$_['text_search_room']  		             =   'Search Rooms';
$_['text_room']							             =   'Room';
$_['text_guest']					               =   'Guests';
$_['text_adult']						             =   'Adult';
$_['text_child']						             =   'Child';
$_['text_select_hotel']					         =   'Select Hotel';
$_['text_all']							             =   'All';
$_['text_hotel']						             =   'Hotel';
$_['text_map_search']					           =   'Map Search';
$_['text_alreadyrequest']                =   'Pending Become Host Request';
//search result page
$_['text_nearest']						           =   'Nearest Hotels';
$_['text_search_heading_title']			     =   'Hotels';
$_['text_distance']						           =   'Distance';
$_['text_contact']						           =   'Contact';
$_['text_hotels']						             =   'Hotels';
$_['text_reviews']            		       =   '%s reviews';
$_['text_find']                          =   'Search';

//hotel details page
$_['text_rooms']						             =   'Rooms';
$_['text_room_ementies']				         =   'Room Amenities';
$_['text_available_ementies']			       =   'Available Amenities';
$_['text_book_now']						           =   'Book Now';
$_['text_leave_response']				         =   'Leave Response';
$_['text_your_name']					           =   'Your Name';
$_['text_your_email']					           =   'Your Email Address';
$_['text_your_response']				         =   'Your Resopnse';
$_['text_your_rating']					         =   'Your Ratings';
$_['button_post']						             =   'Post Comment';
$_['text_imgprofile']					           =   'Your Image';
$_['text_hotel_reviews']				         = 	'Reviews';
$_['text_see_more']						           =   'See More';

$_['text_book_from']				             =   'Book From';
$_['text_book_till']					           =   'Book Till';

//product page
$_['text_book_heading_tile']			       =   'Book Room';
$_['text_room_name']					           =   'Room';
$_['text_hotel_name']					           =   'Hotel';
$_['text_price']						             =   'Price';
$_['text_available_quantity']			       =   'Available Quantity';
$_['text_booking']						           =   'Booking';
$_['text_from']							             =   'Booking From';
$_['text_till']							             =   'Booking Till';
$_['text_ementites']				             =   'Room Amenties';
$_['text_avail_ementites']				       =   'Available Amenities';
$_['text_close']						             =   'Close';
$_['text_extra']						             =   'Extra Amenities';
$_['text_details']						           =   'Details';
$_['text_address']						           =   'Address';
$_['text_email']						             =   'Email';
$_['text_contact']						           =   'Contact';
$_['text_fax']							             =   'Fax';
$_['text_checkin']						           =   'Check in time';
$_['text_checkout']						           =   'Check out time';
$_['text_am']							               =   'am';
$_['text_pm']							               =   'pm';
$_['text_website']						           =   'Website';
$_['text_pernight']						           =   'Per Night';

$_['text_search_nearest']				         =   'Nearest Hotels';

$_['text_loading']						           =  'Loading';


//Cart Page
$_['column_room']   					           = 'Room Image';
$_['column_room_description']			       = 'Room description';
$_['column_room_guest']					         = 'Total People';
$_['column_room_price']					         = 'Unit Price';
$_['column_room_qunat']					         = 'Room(s)';
$_['column_room_checkin']				         = 'Check in Date';
$_['column_room_checkout']				       = 'Check out Date';
$_['text_error']               			     = 'Hotel not found!';
$_['text_error1'] 						           = "Room is not available for this slot";
$_['text_error2'] 					             = "Only %d unit(s) of Rooms %s are available for slot (%s to %s)";
$_['text_error_product_booked']			     = 'All Rooms are already booked for this slot';

$_['text_amenties_help']				         = 'The following amenities are not included in room price. They are optional amenities with extra charges.';
$_['tab_info']							             = 'Details';



//Mp
$_['text_profile']			                 = 'Profile';
$_['text_dashboard']		                 = 'Dashboard';
$_['text_orderhistory']		               = 'Orders';
$_['text_transaction']		               = 'Transaction';
$_['text_addhotel']		                   = 'Hotels';
$_['text_addroom']		                   = 'Rooms';
$_['text_addfxfacility']	               = 'Fixed Facility';
$_['text_addopfacility']	               = 'Optional Facility';
$_['text_hotelreview']	                 = 'Hotel Review';
$_['text_allbookings']		               = 'All Bookings';
$_['text_asktoadmin']		                 = 'Ask to Admin';

$_['text_query']			                   = 'Queries';

$_['text_subject']			                 = 'Subject ';
$_['text_ask']				                   = 'Ask ';
$_['text_close']			                   = 'Close';
$_['text_send']				                   = 'Send ';
$_['text_sell_header']		               = 'Sell';
//Become Partner;

$_['text_register_douwant']		           = 'Become a Host?';
$_['text_register_becomePartner']        = 'Become Host';

$_['text_becomePartner']		             = 'Become Host';
$_['heading_title_sell']		             = 'Sell';

$_['text_allready_member']		           = 'Congrats !! You are already host';
$_['something_error']	    	             = 'Something went wrong. Please try after some time';
$_['agree_error']				                 = 'Please agree the booking hostship rules';
$_['text_agree']                         = 'I have read and agree to the booking hostship rules';
$_['text_req_success']			             = 'Your request to become a host has been submitted. Please wait for admin approval';

$_['text_allready_sent']                 = 'Your request of host is already sent. It may take some time';
$_['text_ask_question']			             = 'Query';
$_['text_error_mail']		                 = 'Fill all the fields.';
$_['text_success_mail']		               = 'Your Mail has been sent successfully. We will reply you soon.';
$_['text_posted']				                 = 'Posted At : ';
$_['text_value']				                 = 'Value : ';
$_['text_quality']				               = 'Quality : ';
$_['text_from']     	                   = 'Booking From ';
$_['text_seller']     	                 = 'Host';
$_['text_total_products']                = 'Total Products ';
$_['text_latest_product']                = 'More Products From Host';
$_['text_ask_seller']		                 = 'Contact Host';

$_['text_query_related']	               = 'Query For';

$_['text_select']                        = '--- Please Select ---';
$_['text_none']                          ='--- None ---';
$_['text_adult_above']                   = 'Adult (Above 12 years)';
$_['text_children_above']                = 'Children (Below 12 years)';

$_['text_popular']                       = "Popular Hotels";
$_['text_list_hotel']                    = "List Your Hotel";
$_['text_register']                      = 'Register And Login';
$_['text_step_1']                        = 'Step-1';
$_['text_step_2']                        = 'Step-2';
$_['text_home_search']                   = 'Search';
$_['text_average_review']                = 'Average Review';
$_['text_hotel_reviews']                 = 'Hotel Reviews';
$_['text_room_type']                     = 'Room Type';
$_['text_room_review']                   = 'Reviews';
$_['text_map']                           = 'Map';
$_['text_hotel_policy']                  = 'Hotel Policy';
$_['text_choose_amenties']               = 'Choose Amenities';
$_['text_more']                          = 'More Details';
$_['tab_description']                    = 'Description';
$_['tab_reviews']                        = 'Reviews';
$_['tab_specification']                  = 'Includes';
$_['text_login_review']                  = 'Login And Write Review';
$_['text_review']                        = 'Write Review';
$_['tab_images']                         = 'Images';
$_['text_no_review']                     = 'There are no reviews for this Hotel';
$_['error_empty_value']                  = 'Please fill the value';
$_['error_invalid_email']                = 'Enter the valid email id';
$_['text_review_submitted']              = 'Your Review is submitted';
$_['text_review_info']                   = 'by %s on %s';
$_['text_not_found']                     = 'There are no rooms for this search';
$_['column_per_room_price']              = 'Price(per room)';
$_['column_num_room']                    = 'Number of Room';
$_['column_room_name']                   = 'Room';
$_['column_hotel_name']                  = 'Hotel';
$_['text_no_hotel']                      = 'No hotels are added as popular hotel by admin';
$_['text_no_photel']                     = 'No more hotels are added by host';
$_['text_enter_city']                    = 'Enter your city name';
$_['text_fill_checkin']                  = 'Fill the check in time';
$_['text_fill_checkout']                 = 'Fill the check out time';
?>
