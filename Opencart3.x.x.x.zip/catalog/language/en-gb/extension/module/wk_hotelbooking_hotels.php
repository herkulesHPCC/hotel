<?php
//heading title
$_['fix_facility_heading_title']		  		= 'Fixed Facilities';
$_['opt_facility_heading_title']		  		= 'Optional Facilities';
$_['column_facility']   					= 'Facility';
$_['column_icon']							= 'Facility Icon';
$_['column_action']							= 'Action';
$_['button_add']							= 'Add';
$_['text_no_result']						= 'No result found';
$_['text_list']								= 'facility List';
$_['button_edit']							= 'Edit';
$_['button_cancel']							= 'Cancel';
$_['button_save']							= 'Save';
$_['text_add']								= 'Add Facility';
$_['text_edit']								= 'Edit Facility';
$_['text_name']								= 'Facility Name';
$_['text_icon']								= 'Facility Icon';
$_['text_success']							= 'Modified facilities successfully.';
$_['text_enabled']							= 'Enable';
$_['text_disabled']							= 'Disable';
$_['entry_sort_order']						= "Sort order";
$_['column_status']							= 'Status';
$_['text_facility_type']					= 'Facility Type';
$_['text_fixed']							= 'Fixed';
$_['text_optional']							= 'Optional';
$_['text_facility_list']					= 'Facility List';
$_['text_facility_add']						= 'Add Facility';
$_['text_facility_edit']					= 'Edit Facility';
//Room
$_['tab_general']							= 'General';
$_['tab_fixed_facility']				    = 'Fixed Facilities';
$_['tab_optional_facility']					= 'Optional Facilities';
$_['tab_image']							    = 'Image';
$_['tab_data']							    = 'Data';

$_['column_hotel']							= 'Hotel Name';

$_['tab_hotel']							    = 'Hotel';

$_['text_facility_name']					= 'Facility Name';
$_['text_confirm']							= 'Are you sure ?';
$_['text_facility_price']					= 'Facility Price';

$_['text_add_hotel']						= 'Add Hotel';
$_['text_edit_hotel']						= 'Edit Hotel';

$_['heading_title_booking']					= 'All Bookings';
$_['room_heading_title']		  		    = 'Rooms';
$_['column_room']   					    = 'Room';
$_['column_room_image']						= 'Room Image';
$_['text_room_list']						= 'Room List';
$_['text_room_add']							= 'Add Room';
$_['text_room_edit']						= 'Edit Room';
$_['text_room_name']						= 'Room Name';
$_['text_room_image']						= 'Room Image';
$_['text_description']						= 'Room Description';
$_['text_room_success']				     	= 'The room has modified successfully.';
$_['entry_meta_title'] 	    			    = 'Meta Tag Title';
$_['entry_assign_hotel']					= 'Assign Hotel';
$_['entry_fixed_facility']					= 'Fixed Facility (AutoComplete)';
$_['entry_text']							= 'About';

$_['button_filter']							= 'Filter';
$_['button_clearfilter']					= 'Clear Filter';
$_['button_add_facility']					= 'Add Facility';
$_['button_image_add']						= 'Add Image';
$_['button_remove']							= 'Remove';

$_['button_product_add']					= 'Add Room';
$_['text_room_delete_success']				= 'The room has deleted successfully.';

//Hotels
$_['tab_details']							= 'Hotel Details';
$_['hotel_heading_title']		  		    = 'Hotels';
$_['column_image']							= 'Hotel Image';
$_['column_name']							= 'Hotel Name';
$_['column_website']					    = 'Website';
$_['column_address']						= 'Hotel Address';
$_['text_hotel_list']						= 'Hotel List';
$_['hotel_configure']						= 'Hotel Configure';
$_['button_add_rooms']						= 'Save and Add Rooms';
$_['entry_room_type']						= 'Room Type';
$_['entry_facility']						= 'Facilities(AutoComplete)';
$_['entry_price']							= 'Price(per night)';
$_['entry_quantity']						= 'Quantity';
$_['entry_max_adult']						= 'Max Adult';
$_['entry_max_child']						= 'Max Child';
$_['entry_facility']						= 'facility';
$_['entry_status']           				= 'Status';
$_['entry_additional_image']				= 'More Images';
$_['filter_name']							= 'Hotel Name';
$_['filter_status']							= 'Status';
$_['filter_website']						= 'Website';
$_['filter_address']						= 'Address';
$_['text_fname']							= 'Facility Name';



$_['hotel_rooms_title']						= 'Hotel Rooms';
$_['column_room_type']						= 'Room';
$_['column_facility']						= 'Facilities';
$_['column_price']							= 'Price(per night)';
$_['column_quantity']						= 'Quantity';
$_['column_adult']						    = 'Max Adult';
$_['column_child']						    = 'Max Child';
$_['entry_start']							= 'Booking From';
$_['entry_end']								= 'Booking till';
$_['column_action']						    = 'Action';
$_['text_hotel_delete_success']				= 'The hotel has deleted successfully.';

$_['text_no_facility']						= 'No facility to show';
$_['text_room_success']						= 'The room has modified successfully.';


$_['error_permission']       				= 'Warning: You do not have permission to modify Facility!';
$_['error_name']       				        = 'Facility name is empty';
$_['error_room_name']       				= 'Room name is empty';
$_['error_hotel_delete']         			= 'Warning: This Hotel cannot be deleted as it is currently assigned to %s Room(s)';


// Heading
$_['heading_title']          				= 'Hotels';

// Text
$_['text_success_hotel']           			= 'Success: You have modified hotels!';
$_['text_success_apphotel']           		= 'Success: Details are successfully added for admin approval!';

$_['text_list']              				= 'Hotels List';
$_['text_add']               				= 'Add Hotel';
$_['text_edit']              				= 'Edit Hotels';

// Column
$_['column_name']            				= 'Hotel Name';
$_['column_sort_order']      				= 'Sort Order';
$_['column_action']          				= 'Action';

$_['entry_address']							= 'Address';
$_['entry_email']							= 'Email';
$_['entry_website']							= 'Website';
$_['entry_contact']							= 'Contact';
$_['entry_faxno']							= 'Fax No.';
$_['entry_checkin']							= 'Check-In';
$_['entry_checkout']						= 'Check-Out';
// Entry
$_['entry_name']             				= 'Hotel Name';
$_['entry_description']      				= 'Hotel Description';
$_['entry_meta_title'] 	     				= 'Meta Tag Title';
$_['entry_meta_keyword']     				= 'Meta Tag Keywords';
$_['entry_meta_description'] 				= 'Meta Tag Description';

$_['entry_image']            				= 'Hotel Image';

$_['text_facility_add_success']				= 'The room facility has added successfully.';
$_['text_facility_edit_success']			= 'The room facility has modified successfully.';
$_['text_facility_delete_success']			= 'The room facility has deleted successfully.';
$_['error_attribute_delete']         		= 'Warning: This Facility cannot be deleted as it is currently assigned to %s Room(s)';


//validation error for hotels
$_['category_error_permission']				= 'Warning: You do not have permission to modify Hotels ';
$_['category_error_name']					= 'Hotel Name must be greater than 3 and less than 255 characters!';
$_['category_error_meta_title']				= 'Meta Title must be greater than 3 and less than 255 characters!';
$_['hotel_error_warning']					= 'Warning: Please check the Hotel form carefully for errors! ';
$_['address_error']							= 'Please provide hotel address';
$_['email_error']               = 'Please provide valid email';
$_['contact_error']             = 'Please provide valid contact number';
$_['error_image']      = "Please Upload valid Image!";
$_['error_image_extension']      = "Please Upload valid Image extension file, only %s extension files are allowed!";
$_['error_file_size']  = "File size is too large!";

//Validation errors for options
$_['option_error_permission']				= 'Warning: You do not have permission to modify facilities ';
$_['error_option_value']					= 'Facility Name is empty';
$_['option_error_warning']					= 'Warning: Please check the Facility form carefully for errors! ';

$_['text_opt_success']						= 'The room facility has modified successfully.';

// Validation error for room
$_['room_error_permission']					= 'Warning: You do not have permission to modify Rooms';
$_['room_error_name']						= 'Room Name must be greater than 3 and less than 255 characters!';
$_['room_error_meta_title']				    = 'Meta Title must be greater than 3 and less than 255 characters!';
$_['error_model']							= 'Assign any hotel to the room';
$_['room_error_warning']					= 'Warning: Please check the Room form carefully for errors! ';
$_['room_price_error']						= 'Provide the valid price per night charge';
$_['room_quantity_error']						= 'Enter room quantity in valid formate';
$_['room_from_error']						= 'Set the start time of booking';
$_['room_till_error']						= 'Set the end time of booking';


//Reviews
// Heading
$_['review_heading_title']     				= 'Reviews';

// Text
$_['text_sreview_uccess']      				= 'Success: You have modified reviews!';
$_['text_review_list']         				= 'Hotel Review List';

$_['text_review_edit']         				= 'Edit Hotel Review';

// Column
$_['column_review_product']    				= 'Hotel';
$_['column_review_author']     				= 'Author';
$_['column_review_rating']     				= 'Rating';
$_['column_review_status']     				= 'Status';
$_['column_date_added'] 	   				= 'Date Added';
$_['column_action']     	   				= 'Action';

// Entry
$_['entry_review_product']     				= 'Hotel';
$_['entry_review_author']      				= 'Author';
$_['entry_rating']      	   				= 'Rating';
$_['entry_review_status']     				= 'Status';
$_['entry_review_text']        				= 'Text';
$_['entry_date_added']  	   				= 'Date Added';
$_['entry_author']			   				= 'Customer';

// Help
$_['help_product']      	   				= '(Autocomplete)';

$_['text_review_delete_success']			= 'Review has deleted successfully.';
// Error
$_['error_review_permission']  				= 'Warning: You do not have permission to modify reviews!';
$_['error_review_rating']      				= 'Review rating required!';
$_['error_author']			   				= 'Author name can not be empty';
$_['error_text']			   				= 'Response can not be empty';
$_['review_heading_title']	   				= 'Hotel Reviews';

$_['text_review_success']					= 'Review has modified successfully.';

//Back end Booking
$_['booking_heading_title']	   				= 'Hotel Reservation System / Book Now';
$_['booking_information']	   				= 'Booking Information' ;
$_['booking_select_from']	   				= 'Select From Date' ;
$_['booking_select_till']	   				= 'Select To Date' ;
$_['booking_select_hotel']	   				= 'Select Hotel' ;
$_['booking_select_room']	   				= 'Select Room' ;
$_['booking_number_rooms']	   				= 'No. of Rooms' ;
$_['booking_check_avail']      				= 'Check Availability';
$_['booking_total']	   		   				= 'Total Rooms' ;
$_['booking_avail']	   		   				= 'Available Rooms' ;
$_['booking_booked']	   	   				= 'Booked Rooms' ;
$_['booking_partially']		   				= 'Partially Available';
$_['booking_unavailable']      				= 'Unavailable Rooms';
$_['booking_adult']			   				= 'No. of Adult';
$_['booking_child']			   				= 'No. of Child';


// Entry
$_['entry_store']                = 'Store';
$_['entry_customer']             = 'Customer';
$_['entry_customer_group']       = 'Customer Group';
$_['entry_firstname']            = 'First Name';
$_['entry_lastname']             = 'Last Name';
$_['entry_email']                = 'E-Mail';
$_['entry_telephone']            = 'Telephone';
$_['entry_fax']                  = 'Fax';
$_['entry_address']              = 'Choose Address';
$_['entry_company']              = 'Company';
$_['entry_address_1']            = 'Address 1';
$_['entry_address_2']            = 'Address 2';
$_['entry_city']                 = 'City';
$_['entry_postcode']             = 'Postcode';
$_['entry_country']              = 'Country';
$_['entry_zone']                 = 'Region / State';
$_['entry_zone_code']            = 'Region / State Code';
$_['entry_product']              = 'Room';
$_['entry_option']               = 'Choose Option(s)';
$_['entry_quantity']             = 'Quantity';
$_['entry_to_name']              = 'Recipient\'s Name';
$_['entry_to_email']             = 'Recipient\'s E-mail';
$_['entry_from_name']            = 'Sender\'s Name';
$_['entry_from_email']           = 'Sender\'s E-mail';
$_['entry_theme']                = 'Gift Certificate Theme';
$_['entry_message']              = 'Message';
$_['entry_amount']               = 'Amount';
$_['entry_affiliate']            = 'Affiliate';
$_['entry_order_status']         = 'Order Status';
$_['entry_notify']               = 'Notify Customer';
$_['entry_override']             = 'Override';
$_['entry_comment']              = 'Comment';
$_['entry_currency']             = 'Currency';
$_['entry_shipping_method']      = 'Shipping Method';
$_['entry_payment_method']       = 'Payment Method';
$_['entry_coupon']               = 'Coupon';
$_['entry_voucher']              = 'Voucher';
$_['entry_reward']               = 'Reward';
$_['entry_order_id']             = 'Order ID';
$_['entry_total']                = 'Total';
$_['entry_date_added']           = 'Date Added';
$_['entry_date_modified']        = 'Date Modified';
$_['text_no_booking_option']	 = 'There is no booking option for this day!';

$_['text_hotel_name']			 =   'Hotel';
$_['text_address']				 =   'Address';
$_['text_email']				 =   'Email';
$_['text_contact']				 =   'Contact';
$_['text_fax']					 =   'Fax';
$_['text_checkin']				 =   'Check-in time';
$_['text_checkout']				 =   'Check-out time';
$_['text_am']					 =   'am';
$_['text_pm']					 =   'pm';
$_['text_website']				 =   'Website';
$_['text_pernight']				 =   'Per Night';
$_['text_from']					 =   'Booking start From';
$_['text_till']					 =   'Booking Till';
$_['text_price']				 =   'Price';
$_['text_customer_detail']		 =   'Customer Details';
$_['text_customer_required_detail'] = 'Customer Required Details';
$_['text_address_details']		 =  'Address Details';
$_['text_address_required']		 = 'Other Address Required Field';
$_['text_payment_detail']		 = 'Payment Details';
$_['text_cart_details']			 = 'Cart Details & Extra Amenities';
$_['text_room']					 = 'Room';

//Booking results
$_['book_product_name'] 	 	 = 'Room Name';
$_['book_date_start']    	  	 = 'Booking Start';
$_['book_date_to']    	  	  	 = 'Booking Till';
$_['book_status']    		  	 = 'Status';
$_['book_act']    			  	 = 'Booking';
$_['heading_title_products']	 = 'Bookings';
$_['error_no_record']			 = 'No record found';
$_['button_export'] 			 = 'Export';
$_['export_title'] 				 = 'Export History';
$_['export_from']  				 = 'Export From';
$_['export_to'] 				 = 'Export To';
$_['export_format'] 			 = 'Export Format';
$_['text_name']				     = 'Customer Name';
$_['text_email']				 = 'Customer Email';
$_['text_telephone']			 = 'Customer Telephone';
$_['date_start']				 = 'Check in';
$_['date_to']					 = 'Check out';
$_['book_fname']    	  	  	 = 'Name';
$_['book_phone']   		  		 = 'Telephone';
$_['book_email']    		  	 = 'Email';
$_['book_to']    			  	 = 'Check out';
$_['book_from']    			  	 = 'Check in';
$_['button_filter']    			 = 'Filter';
$_['error_no_slot']			     = 'No Booking to export for this date';
$_['error_warning']				 = 'Warning: You do not have permission to modify the bookings';


$_['text_total_room']  			 = 'Total Rooms';
$_['text_fully_avail']			 = 'Available Rooms';
$_['text_partially_avial']		 = 'Partially available rooms';
$_['text_booked_rooms']			 = 'Booked Rooms';

$_['cancel_booking']			 = 'Cancel Booking';
$_['text_success_cancel']	     = 'The Booking is cancel Now';
$_['not_authenticated']			 = 'Not authorized to cancel booking';
$_['column_quantity']            = 'Quantity';

$_['text_success_rmhotel']       = "successfully Modified Rooms and details are added for admin approval";
$_['text_sucess_fxapprove']		 = " successfully Modified Facility and details are added for approval";

$_['text_admin']				 = 'admin';
$_['text_max']					 = 'You have reached your maximum limit';

$_['text_account']				 = 'Account';

$_['column_customer_name']		 = 'Customer';
$_['column_hotel_name']			 = 'Hotel Name';
$_['column_order_id']       = 'Order Id';
$_['text_order']            = 'Booking Information';
$_['text_order_detail']     = 'Booking Details';
$_['text_invoice_no']       = 'Invoice No.:';
$_['text_order_id']         = 'Booking ID:';
$_['text_status']           = 'Status:';
$_['text_date_added']       = 'Date Added:';
$_['text_customer']         = 'Customer:';
$_['text_payment_address']  = 'Payment Address';
$_['text_payment_method']   = 'Payment Method:';
$_['text_products']         = 'Products:';
$_['text_total']            = 'Total:';
$_['text_comment']          = 'Order Comments';
$_['text_history']          = 'Order History';
$_['text_paid']          	= 'Paid';
$_['text_not_paid']          = 'Not Paid';
$_['text_success']          = 'You have successfully added facility';
$_['text_empty']            = 'You have not made any previous orders!';
$_['text_success_history']  = 'Success: Order History has been added succesfully !';

$_['text_error']            = 'The order you requested could not be found!';

$_['text_wait']             = 'Please Wait!';
// Column
$_['column_model']          = 'Hotel Name';
$_['column_quantity']       = 'Quantity';
$_['column_price']          = 'Price';
$_['column_total']          = 'Total';
$_['column_transaction_status']       = 'Transaction Status';
$_['column_action']         = 'Action';
$_['column_date_added']     = 'Date Added';
$_['column_status']         = 'Status';
// $_['column_cancel_order']   = 'Cancel Order';
$_['column_comment']        = 'Comment';

$_['button_invoice']        = 'Print Invoice';
$_['button_back']       	= 'Back';
$_['button_submit']         = 'Submit';
$_['error_page_order']      = 'You are not authorized to view this order !! ';
$_['column_booking_from']	= 'Booking From';
$_['column_booking_till']	= 'Booking Till';

// Text Mail
$_['m_text_subject']      = '%s - Order Update %s';
$_['m_text_order']        = 'Order ID:';
$_['m_text_date_added']   = 'Date Ordered:';
$_['m_text_order_status'] = '%s has been updated to the following status:';
$_['m_text_order_status_admin'] = '%s has been updated order to the following status:';
$_['m_text_comment']      = 'The comments for your order are:';
$_['m_text_link']         = 'To view your order click on the link below:';
$_['m_date_format_short'] = 'y/m/d';
$_['m_text_footer']       = 'Please reply to this email if you have any questions.';

$_['filter_rname']							= 'Room Name';
$_['filter_price']							= 'Price';
$_['filter_status']							= 'Status';
$_['text_enabled']							= 'Enable';
$_['text_disabled']							= 'Disable';
$_['error_product_select'] = 'You have to select atleast one product';
$_['column_room_name']		= 'Room';
$_['column_duration']	    = 'Duration';
$_['column_amenties']       = 'Amenities';
$_['column_people']			= 'Guest';

$_['error_review_delete']	 = 'You can not delete the hotel reviews';
$_['error_review_edit']	     = 'You can not edit the hotel reviews';
$_['error_check_in']       = "Check in date must be current or future";
$_['error_check_out']       = "Check out date must be greater than Checkin date";
$_['guest_error']          = 'There must be only %s maximum adult and %s maximum child';
?>
