<?php
const MPIMAGEFOLDER = 'catalog/';

class ModelAccountCustomerpartner extends Model {

		/*Membership functions*/

	/**
	 * [checkIsMember to check that logged in seller is a member or not and if a member then membership expiry date and other details]
	 * @param  [integer] $seller_id [customer id of seller]
	 * @return [array|boolean]            [details about membership|false]
	 */
	public function checkIsMember($seller_id) {
		$membershipDetails = $this->db->query("SELECT * FROM ".DB_PREFIX."seller_group_customer sgc LEFT JOIN ".DB_PREFIX."seller_group_name sgn ON (sgc.gid = sgn.id) WHERE sgc.customer_id = '".(int)$seller_id."' AND sgn.language_id = '".(int)$this->config->get('config_language_id')."' ")->row;
		if($membershipDetails && isset($membershipDetails['membership_expiry'])) {
			return $membershipDetails;
		} else {
			return false;
		}
	}

	/**
	 * [getProductCategory to get category of any product]
	 * @param  [integer] $product_id [id of product]
	 * @return [integer|boolean]             [category id or false]
	 */
	public function getProductCategory($product_id) {
		$result = $this->db->query("SELECT category_id FROM ".DB_PREFIX."product_to_category p2c WHERE product_id = '".(int)$product_id."' ")->rows;
		if($result) {
			return $result;
		} else {
			return false;
		}
	}

	/**
	 * [getMostViewedProducts to get top 5 viewed products]
	 * @param  [integer] $seller_id [seller is of logged in seller]
	 * @return [array]            [list of top 5 viewed products]
	 */
	public function getMostViewedProducts($seller_id) {
		$products = $this->db->query("SELECT p.model,pd.name,p.viewed FROM ".DB_PREFIX."customerpartner_to_product cp2p LEFT JOIN ".DB_PREFIX."product p ON (p.product_id=cp2p.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON (p.product_id=pd.product_id) WHERE cp2p.customer_id = '".(int)$seller_id."' AND p.viewed >= 5 AND pd.language_id = '".(int)$this->config->get('config_language_id')."' ORDER BY p.viewed DESC LIMIT 0,5 ")->rows;
		if($products) {
			return $products;
		} else {
			return false;
		}
	}
	/**
	 * [getProduct to get detail of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [detail of particular product]
	 */
	public function getProduct($product_id) {

		$query = $this->db->query("SELECT DISTINCT *, pd.name AS name, p.image, m.name AS manufacturer, (SELECT price FROM " . DB_PREFIX . "product_discount pd2 WHERE pd2.product_id = p.product_id AND pd2.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND pd2.quantity = '1' AND ((pd2.date_start = '0000-00-00' OR pd2.date_start < NOW()) AND (pd2.date_end = '0000-00-00' OR pd2.date_end > NOW())) ORDER BY pd2.priority ASC, pd2.price ASC LIMIT 1) AS discount, (SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special, (SELECT points FROM " . DB_PREFIX . "product_reward pr WHERE pr.product_id = p.product_id AND customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "') AS reward, (SELECT ss.name FROM " . DB_PREFIX . "stock_status ss WHERE ss.stock_status_id = p.stock_status_id AND ss.language_id = '" . (int)$this->config->get('config_language_id') . "') AS stock_status, (SELECT wcd.unit FROM " . DB_PREFIX . "weight_class_description wcd WHERE p.weight_class_id = wcd.weight_class_id AND wcd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS weight_class, (SELECT lcd.unit FROM " . DB_PREFIX . "length_class_description lcd WHERE p.length_class_id = lcd.length_class_id AND lcd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS length_class, (SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = p.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating, (SELECT COUNT(*) AS total FROM " . DB_PREFIX . "review r2 WHERE r2.product_id = p.product_id AND r2.status = '1' GROUP BY r2.product_id) AS reviews, p.sort_order FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) LEFT JOIN " . DB_PREFIX . "manufacturer m ON (p.manufacturer_id = m.manufacturer_id) WHERE p.product_id = '" . (int)$product_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		$result = $this->db->query("SELECT * FROM ".DB_PREFIX."customerpartner_to_product WHERE product_id = '".(int)$product_id."' ")->row;


			if(!isset($result['expiry_date'])) {
				$result['expiry_date'] = '';
			}
			if(!isset($result['relist_duration'])) {
				$result['relist_duration'] = '';
			}
			if(!isset($result['auto_relist'])) {
				$result['auto_relist'] = '';
			}
			if(!isset($result['current_status'])) {
				$result['current_status'] = '';
			}


		if ($query->num_rows) {
			return array(
				'product_id'       => $query->row['product_id'],
				'name'             => $query->row['name'],
				'description'      => $query->row['description'],
				'meta_title'       => $query->row['meta_title'],
				'meta_description' => $query->row['meta_description'],
				'meta_keyword'     => $query->row['meta_keyword'],
				'tag'              => $query->row['tag'],
				'model'            => $query->row['model'],
				'sku'              => $query->row['sku'],
				'upc'              => $query->row['upc'],
				'ean'              => $query->row['ean'],
				'jan'              => $query->row['jan'],
				'isbn'             => $query->row['isbn'],
				'mpn'              => $query->row['mpn'],
				'location'         => $query->row['location'],
				'quantity'         => $query->row['quantity'],
				'stock_status'     => $query->row['stock_status'],
				'image'            => $query->row['image'],
				'manufacturer_id'  => $query->row['manufacturer_id'],
				'manufacturer'     => $query->row['manufacturer'],
				'price'            => ($query->row['discount'] ? $query->row['discount'] : $query->row['price']),
				'special'          => $query->row['special'],
				'reward'           => $query->row['reward'],
				'points'           => $query->row['points'],
				'tax_class_id'     => $query->row['tax_class_id'],
				'date_available'   => $query->row['date_available'],
				'weight'           => $query->row['weight'],
				'weight_class_id'  => $query->row['weight_class_id'],
				'length'           => $query->row['length'],
				'width'            => $query->row['width'],
				'height'           => $query->row['height'],
				'length_class_id'  => $query->row['length_class_id'],
				'subtract'         => $query->row['subtract'],
				'rating'           => round($query->row['rating']),
				'reviews'          => $query->row['reviews'] ? $query->row['reviews'] : 0,
				'minimum'          => $query->row['minimum'],
				'sort_order'       => $query->row['sort_order'],
				'status'           => $query->row['status'],
				'date_added'       => $query->row['date_added'],
				'date_modified'    => $query->row['date_modified'],
				'viewed'           => $query->row['viewed'],
			);
		} else {
			return false;
		}
	}
	/**
	 * [getProductsSeller to get seller's product]
	 * @param  [array]  $data [filter keywords]
	 * @return [array]       [product's details]
	 */
	public function getMostBookedProduct($data = array()) {

		$sql = "SELECT p.product_id, (SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = p.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating, (SELECT COUNT(*) FROM ".DB_PREFIX."wk_booking_slots ws WHERE ws.product_id = p.product_id) AS sell, (SELECT price FROM " . DB_PREFIX . "product_discount pd2 WHERE pd2.product_id = p.product_id AND pd2.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND pd2.quantity = '1' AND ((pd2.date_start = '0000-00-00' OR pd2.date_start < NOW()) AND (pd2.date_end = '0000-00-00' OR pd2.date_end > NOW())) ORDER BY pd2.priority ASC, pd2.price ASC LIMIT 1) AS discount, (SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "customerpartner_to_product c2p ON (c2p.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id)";

		if (isset($data['filter_category_id']) AND $data['filter_category_id']) {
			$sql .= " LEFT JOIN " . DB_PREFIX ."product_to_category p2c ON (p.product_id = p2c.product_id)";
		}

		$sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND p.date_available <= NOW() ";

		if (isset($data['filter_store']) && !is_null($data['filter_store'])) {
			$sql .= " AND p2s.store_id = '" . (int)$data['filter_store'] . "'";
		}

		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND p.status = '" . (int)$data['filter_status'] . "'";
		}


		if(!isset($data['customer_id']) || !$data['customer_id'])
			$sql .= " AND c2p.customer_id = ". (int)$this->customer->getId() ;
		else
			$sql .= " AND c2p.customer_id = ". (int)$data['customer_id'] ;

		$sql .= " GROUP BY p.product_id ";

		$sql .= " ORDER BY sell DESC";
		$sort_data = array(
			'p.price',
			'p.status',
			'p.sort_order'
		);
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$product_data = array();

		$result = $this->db->query($sql)->rows;

		foreach ($result as $key => $result) {
			$sell = $result['sell'];
			$product_data[$result['product_id']] = $this->getProduct($result['product_id']);
			$product_data[$result['product_id']]['sell'] = $sell;

		}

		return $product_data;
	}


	/**
	 * [getProductsSeller to get seller's product]
	 * @param  [array]  $data [filter keywords]
	 * @return [array]       [product's details]
	 */
	public function getProductsSeller($data = array()) {

		$sql = "SELECT p.product_id, (SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = p.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating, (SELECT price FROM " . DB_PREFIX . "product_discount pd2 WHERE pd2.product_id = p.product_id AND pd2.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND pd2.quantity = '1' AND ((pd2.date_start = '0000-00-00' OR pd2.date_start < NOW()) AND (pd2.date_end = '0000-00-00' OR pd2.date_end > NOW())) ORDER BY pd2.priority ASC, pd2.price ASC LIMIT 1) AS discount, (SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "customerpartner_to_product c2p ON (c2p.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id)";

		if (isset($data['filter_category_id']) AND $data['filter_category_id']) {
			$sql .= " LEFT JOIN " . DB_PREFIX ."product_to_category p2c ON (p.product_id = p2c.product_id)";
		}

		$sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND p.date_available <= NOW() ";

		if (isset($data['filter_category_id']) AND $data['filter_category_id']) {
			$sql .= " AND p2c.category_id = '" . (int)$data['filter_category_id'] . "'";
		}

		if (isset($data['filter_name']) AND !empty($data['filter_name'])) {
			$sql .= " AND pd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		if (isset($data['filter_model']) AND !empty($data['filter_model'])) {
			$sql .= " AND p.model LIKE '" . $this->db->escape($data['filter_model']) . "%'";
		}

		if (isset($data['filter_price']) AND !empty($data['filter_price'])) {
			$sql .= " AND p.price LIKE '" . $this->db->escape($data['filter_price']) . "%'";
		}

		if (isset($data['filter_quantity']) && !is_null($data['filter_quantity'])) {
			$sql .= " AND p.quantity = '" . $this->db->escape($data['filter_quantity']) . "'";
		}

		if (isset($data['filter_store']) && !is_null($data['filter_store'])) {
			$sql .= " AND p2s.store_id = '" . (int)$data['filter_store'] . "'";
		}

		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND p.status = '" . (int)$data['filter_status'] . "'";
		}

		if(!isset($data['customer_id']) || !$data['customer_id'])
			$sql .= " AND c2p.customer_id = ". (int)$this->customer->getId() ;
		else
			$sql .= " AND c2p.customer_id = ". (int)$data['customer_id'] ;

		$sql .= " GROUP BY p.product_id";

		$sort_data = array(
			'pd.name',
			'p.model',
			'p.price',
			'p.quantity',
			'p.status',
			'p.sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY pd.name";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$product_data = array();

		$query = $this->db->query($sql);

		foreach ($query->rows as $result) {
			$product_data[$result['product_id']] = $this->getProduct($result['product_id']);
		}

		return $product_data;
	}

	/**
	 * [getTotalProductsSeller total count seller's products]
	 * @param  [array]  $data [filter keywords]
	 * @return [integer]       [number of products]
	 */
	public function getTotalProductsSeller($data = array()) {

		$sql = "SELECT * FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "customerpartner_to_product c2p ON (c2p.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id)";

		if (isset($data['filter_category_id']) AND $data['filter_category_id']) {
			$sql .= " LEFT JOIN " . DB_PREFIX ."product_to_category p2c ON (p.product_id = p2c.product_id)";
		}

		$sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND p.date_available <= NOW() ";

		if (isset($data['filter_category_id']) AND $data['filter_category_id']) {
			$sql .= " AND p2c.category_id = '" . (int)$data['filter_category_id'] . "'";
		}

		if (isset($data['filter_name']) AND !empty($data['filter_name'])) {
			$sql .= " AND pd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		if (isset($data['filter_model']) AND !empty($data['filter_model'])) {
			$sql .= " AND p.model LIKE '" . $this->db->escape($data['filter_model']) . "%'";
		}

		if (isset($data['filter_store']) && !is_null($data['filter_store'])) {
			$sql .= " AND p2s.store_id = '" . (int)$data['filter_store'] . "'";
		}

		if (isset($data['filter_price']) AND !empty($data['filter_price'])) {
			$sql .= " AND p.price LIKE '" . $this->db->escape($data['filter_price']) . "%'";
		}

		if (isset($data['filter_quantity']) && !is_null($data['filter_quantity'])) {
			$sql .= " AND p.quantity = '" . $this->db->escape($data['filter_quantity']) . "'";
		}

		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND p.status = '" . (int)$data['filter_status'] . "'";
		}

		if(!isset($data['customer_id']) || !$data['customer_id'])
			$sql .= " AND c2p.customer_id = ". $this->customer->getId() ;
		else
			$sql .= " AND c2p.customer_id = ". (int)$data['customer_id'] ;

		$query = $this->db->query($sql);

		return count($query->rows);
	}
	/**
	 * [productQuery sub function to create query that will be executed in calling function]
	 * @param  [string] $sql  [base sql query]
	 * @param  [array] $data [filter keyword]
	 * @return [string]       [sql query string]
	 */
	public function productQuery($sql,$data){

		$implode = array();

		if (isset($data['model'])) {
			$implode[] = "model = '" . $this->db->escape($data['model']) . "'";
		}

		if (isset($data['sku'])) {
			$implode[] = "sku = '" . $this->db->escape($data['sku']) . "'";
		}

		if (isset($data['upc'])) {
			$implode[] = "upc = '" . $this->db->escape($data['upc']) . "'";
		}

		if (isset($data['ean'])) {
			$implode[] = "ean = '" . $this->db->escape($data['ean']) . "'";
		}

		if (isset($data['jan'])) {
			$implode[] = "jan = '" . $this->db->escape($data['jan']) . "'";
		}

		if (isset($data['isbn'])) {
			$implode[] = "isbn = '" . $this->db->escape($data['isbn']) . "'";
		}

		if (isset($data['mpn'])) {
			$implode[] = "mpn = '" . $this->db->escape($data['mpn']) . "'";
		}

		if (isset($data['location'])) {
			$implode[] = "location = '" . $this->db->escape($data['location']) . "'";
		}

		if (isset($data['quantity'])) {
			$implode[] = "quantity = '" . $this->db->escape($data['quantity']) . "'";
		}

		if (isset($data['minimum'])) {
			$implode[] = "minimum = '" . $this->db->escape($data['minimum']) . "'";
		}

		if (isset($data['subtract'])) {
			$implode[] = "subtract = '" . $this->db->escape($data['subtract']) . "'";
		}

		if (isset($data['stock_status_id'])) {
			$implode[] = "stock_status_id = '" . $this->db->escape($data['stock_status_id']) . "'";
		}

		if (isset($data['date_available'])) {
			$implode[] = "date_available = '" . $this->db->escape($data['date_available']) . "'";
		}

		if (isset($data['manufacturer_id'])) {
			$implode[] = "manufacturer_id = '" . $this->db->escape($data['manufacturer_id']) . "'";
		}

		if (isset($data['shipping'])) {
			$implode[] = "shipping = '" . $this->db->escape($data['shipping']) . "'";
		}

		if (isset($data['price'])) {
			$implode[] = "price = '" . $this->db->escape($this->currency->convert($data['price'],$this->session->data['currency'], $this->config->get('config_currency'))) . "'";
		}

		if (isset($data['points'])) {
			$implode[] = "points = '" . $this->db->escape($data['points']) . "'";
		}

		if (isset($data['weight'])) {
			$implode[] = "weight = '" . $this->db->escape($data['weight']) . "'";
		}

		if (isset($data['weight_class_id'])) {
			$implode[] = "weight_class_id = '" . $this->db->escape($data['weight_class_id']) . "'";
		}

		if (isset($data['length'])) {
			$implode[] = "length = '" . $this->db->escape($data['length']) . "'";
		}

		if (isset($data['width'])) {
			$implode[] = "width = '" . $this->db->escape($data['width']) . "'";
		}

		if (isset($data['height'])) {
			$implode[] = "height = '" . $this->db->escape($data['height']) . "'";
		}

		if (isset($data['length_class_id'])) {
			$implode[] = "length_class_id = '" . $this->db->escape($data['length_class_id']) . "'";
		}

		if (isset($data['status'])) {
			$implode[] = "status = '" . $this->db->escape($data['status']) . "'";
		}

		if (isset($data['tax_class_id'])) {
			$implode[] = "tax_class_id = '" . $this->db->escape($data['tax_class_id']) . "'";
		}

		if (isset($data['sort_order'])) {
			$implode[] = "sort_order = '" . $this->db->escape($data['sort_order']) . "'";
		}

		if ($implode) {
			$sql .=  implode(" , ", $implode)." , " ;
		}

		return $sql;
	}

	/**
	 * [getProductDescriptions to get description of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [description of particular product]
	 */
	public function getProductDescriptions($product_id) {
		$product_description_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$product_id . "'");

		foreach ($query->rows as $result) {
			$product_description_data[$result['language_id']] = array(
				'name'             => $result['name'],
				'description'      => $result['description'],
				'meta_keyword'     => $result['meta_keyword'],
				'meta_title'       => $result['meta_title'],
				'meta_description' => $result['meta_description'],
				'tag'              => $result['tag']
			);
		}

		return $product_description_data;
	}

	/**
	 * [getProductCategories to get categories of product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [categories of particular product]
	 */
	public function getProductCategories($product_id) {
		$product_category_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "'");

		foreach ($query->rows as $result) {
			$product_category_data[] = $result['category_id'];
		}

		return $product_category_data;
	}

	/**
	 * [getProductFilters to get filters of any product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [filters of particular product]
	 */
	public function getProductFilters($product_id) {
		$product_filter_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX ."product_filter WHERE product_id = '" . (int)$product_id . "'");

		foreach ($query->rows as $result) {
			$product_filter_data[] = $result['filter_id'];
		}

		return $product_filter_data;
	}

	/**
	 * [getProductAttributes to get attributes of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [attributes of particular product]
	 */
	public function getProductAttributes($product_id) {

	    $product_attribute_data = array();

	    $product_attribute_query = $this->db->query("SELECT DISTINCT a.attribute_id, ad.name FROM " . DB_PREFIX . "product_attribute pa LEFT JOIN " . DB_PREFIX . "attribute a ON (pa.attribute_id = a.attribute_id) LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) WHERE pa.product_id = '" . (int)$product_id . "' AND ad.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY a.sort_order, ad.name");

	    foreach ($product_attribute_query->rows as $product_attribute) {

	        $product_attribute_description_data = array();

	        $product_attribute_description_query = $this->db->query("SELECT pa.language_id, ad.name, pa.text FROM " . DB_PREFIX . "product_attribute pa LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (pa.attribute_id = ad.attribute_id) WHERE pa.product_id = '" . (int)$product_id . "' AND pa.attribute_id = '" . (int)$product_attribute['attribute_id'] . "' AND ad.language_id = '" . (int)$this->config->get('config_language_id') . "'");

	        foreach ($product_attribute_description_query->rows as $product_attribute_description) {

	            $product_attribute_description_data[$product_attribute_description['language_id']] = array(
	                                                            'name' => $product_attribute_description['name'],
	                                                            'text' => $product_attribute_description['text']
	                                                            );
	        }

	        $product_attribute_data[] = array(
	            'attribute_id'                  => $product_attribute['attribute_id'],
	            'name'                          => $product_attribute['name'],
	            'product_attribute_description' => $product_attribute_description_data
	        );
	    }

	    return $product_attribute_data;
	}

	/**
	 * [getProductOptions to get options of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @param  [string] $tabletype  [to define marketplace's tables or opencart's tables]
	 * @return [array]             [options of particular product]
	 */
	public function getProductOptions($product_id,$tabletype = '') {
		$product_option_data = array();

		$product_option_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . $tabletype."product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON (po.option_id = o.option_id) LEFT JOIN `" . DB_PREFIX . "option_description` od ON (o.option_id = od.option_id) WHERE po.product_id = '" . (int)$product_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		foreach ($product_option_query->rows as $product_option) {
			$product_option_value_data = array();

			$product_option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . $tabletype."product_option_value WHERE product_option_id = '" . (int)$product_option['product_option_id'] . "'");

			foreach ($product_option_value_query->rows as $product_option_value) {
				$product_option_value_data[] = array(
					'product_option_value_id' => $product_option_value['product_option_value_id'],
					'option_value_id'         => $product_option_value['option_value_id'],
					'quantity'                => $product_option_value['quantity'],
					'subtract'                => $product_option_value['subtract'],
					'price'                   => $product_option_value['price'],
					'price_prefix'            => $product_option_value['price_prefix'],
					'points'                  => $product_option_value['points'],
					'points_prefix'           => $product_option_value['points_prefix'],
					'weight'                  => $product_option_value['weight'],
					'weight_prefix'           => $product_option_value['weight_prefix']
				);
			}

			$product_option_data[] = array(
				'product_option_id'    => $product_option['product_option_id'],
				'option_id'            => $product_option['option_id'],
				'name'                 => $product_option['name'],
				'type'                 => $product_option['type'],
				'product_option_value' => $product_option_value_data,
				'option_value'         => $product_option['value'],
				'required'             => $product_option['required']
			);
		}

		return $product_option_data;
	}

	/**
	 * [getProductDiscounts to get discount of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [discounts of particular product]
	 */
	public function getProductDiscounts($product_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX ."product_discount WHERE product_id = '" . (int)$product_id . "' ORDER BY quantity, priority, price");

		return $query->rows;
	}

	/**
	 * [getProductSpecials to get specials of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [specials of particular product]
	 */
	public function getProductSpecials($product_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "' ORDER BY priority, price");

		return $query->rows;
	}

	/**
	 * [getProductDownloads to get downloads of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [downloads of particular product]
	 */
	public function getProductDownloads($product_id) {
		$product_download_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_download WHERE product_id = '" . (int)$product_id . "'");

		foreach ($query->rows as $result) {
			$product_download_data[] = $result['download_id'];
		}

		return $product_download_data;
	}

	/**
	 * [getProductRelated to get rewards of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @param  [string] $tabletype  [to define marketplace's tables or opencart's tables]
	 * @return [array]             [rewards of particular product]
	 */
	public function getProductRelated($product_id,$tabletype = '') {
		$product_related_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . $tabletype."product_related WHERE product_id = '" . (int)$product_id . "'");

		foreach ($query->rows as $result) {
			$product_related_data[] = $result['related_id'];
		}

		return $product_related_data;
	}

	/**
	 * [getProductRelatedInfo to get related products of particular product]
	 * @param  [integer] $product_id [product id of product]
	 * @return [array]             [related products of particular product]
	 */
	public function getProductRelatedInfo($product_id) {
		$query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'product_id=" . (int)$product_id . "') AS keyword FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) WHERE p.product_id = '" . (int)$product_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}

	/**
	 * [IsApplyForSellership to check that a customer is already applied for sellership/partnership or not]
	 */
	public function IsApplyForSellership(){
		$query = $this->db->query("SELECT customer_id FROM ".DB_PREFIX ."customerpartner_to_customer WHERE customer_id = '".(int)$this->customer->getId()."'")->row;

		if($query){
			return true;
		}else{
			return false;
		}

	}

	/**
	 * [chkIsPartner to check customer is partner or not]
	 * @return [boolean] [true or false]
	 */
	public function chkIsPartner(){

		$sql = $this->db->query("SELECT * FROM ".DB_PREFIX ."customerpartner_to_customer WHERE customer_id = '" . (int)$this->customer->getId() . "'");
		if(count($sql->row) && isset($sql->row['is_partner'])){

			return $sql->row['is_partner'];
		}else{
			return false;
		}
	}
    /**
     * [CustomerCountry_Id fetch current customer's country id]
     * @param [type] $customer_id [current customer's customer_id]
     */
	public function CustomerCountry_Id($customer_id){

		$countryid = $this->db->query("SELECT country_id FROM ".DB_PREFIX."address WHERE customer_id = '".(int)$customer_id."' ")->row;

		return $countryid;

	}
	/**
	 * [becomePartner to register as a seller/partner]
	 * @param  [integer] $country_id [country id of registered customer]
	 * @param  [string] $message    [just a meesage while registering]
	 */
	public function becomePartner($country_id, $customer_id, $message = ''){

		$country = $this->db->query("SELECT iso_code_2 FROM ".DB_PREFIX."country WHERE country_id = '".(int)$country_id."' ")->row;

		$countryCode = '';
		$countryCodeFlag = '';
		if($country && isset($country['iso_code_2'])) {
			$countryCode = $country['iso_code_2'];
			$countryCodeFlag = 'image/flags/'.strtolower($countryCode).'.png';
		}

        $commission = $this->config->get('module_wk_hotelbooking_res_commission') ? $this->config->get('module_wk_hotelbooking_res_commission') : 0;

        if($this->config->get('module_wk_hotelbooking_res_partnerapprov')) {
        	$this->db->query("INSERT INTO ".DB_PREFIX."customerpartner_to_customer set customer_id = '" .(int)$customer_id."', is_partner='1', country = '".$this->db->escape($countryCode)."', commission = '".(float)$commission."',countrylogo = '".$this->db->escape($countryCodeFlag)."' ");

        } else {
        	$this->db->query("INSERT INTO ".DB_PREFIX."customerpartner_to_customer set customer_id = '" .(int)$customer_id."', is_partner='0', country = '".$this->db->escape($countryCode)."', countrylogo = '".$this->db->escape($countryCodeFlag)."'");
        }
        $data = array(
        	'message' => $message,
        	'commission' => $commission,
        	'seller_id' => $customer_id,
        	'customer_id' => $customer_id,
        	'mail_id' => $this->config->get('module_wk_hotelbooking_res_mail_partner_request'),
        	'mail_from' => $this->config->get('config_email'),
        	'mail_to' => $this->customer->getEmail(),
        );

        $values = array(
        	'message' => $data['message'],
					'commission' => $data['commission']."%",
        );
        /**
         * send mail to Admin / Customer after request for Partnership
         */
        $this->load->model('customerpartner/mail');
       	/**
       	 * customer applied for sellership to customer
       	 */
       	if(isset($data['message'])) {

	        $this->model_customerpartner_mail->mail($data,$values);
	        /**
	         * customer applied for sellership to admin
	         */
	        $data['mail_id'] = $this->config->get('module_wk_hotelbooking_res_mail_partner_admin');
	        $data['mail_from'] = $this->customer->getEmail();
	        $data['mail_to'] = $this->config->get('config_email');

	        $this->model_customerpartner_mail->mail($data,$values);
				}
	}

	/**
		 * [getSellerCommission to get seller's commission]
		 * @param  [integer] $seller_id [particular seller id]
		 * @return [integer, boolean]            [seller's commission or false value]
		 */
		public function getSellerCommission($seller_id){
			$result = $this->db->query("SELECT commission FROM ".DB_PREFIX."customerpartner_to_customer WHERE customer_id = '".(int)$seller_id."' AND is_partner = 1 ")->row;
			if(isset($result['commission'])) {
				return $result['commission'];
			} else {
				return false;
			}
		}

	/**
	 * [updateProfile to update the existing seller's profile]
	 * @param  [array] $data [details about the seller's profile]
	 */
	public function updateProfile($data){



		$this->load->model('customerpartner/htmlfilter');
		$htmlfilter = $this->model_customerpartner_htmlfilter;

		$impolde = array();

		if(isset($data['screenName']))
			$impolde[] = 'screenname = "'.$this->db->escape($data['screenName']).'"';

		if(isset($data['gender']))
			$impolde[] = 'gender = "'.$this->db->escape($data['gender']).'"';

		if(isset($data['shortProfile']))
			$impolde[] = 'shortprofile = "'.$this->db->escape(htmlentities($htmlfilter->HTMLFilter(html_entity_decode($data['shortProfile']),'',true))).'"';

		if(isset($data['twitterId']))
			$impolde[] = 'twitterid = "'.$this->db->escape($data['twitterId']).'"';

		if(isset($data['facebookId']))
			$impolde[] = 'facebookid = "'.$this->db->escape($data['facebookId']).'"';

		if(isset($data['backgroundcolor']))
			$impolde[] = 'backgroundcolor = "'.$this->db->escape($data['backgroundcolor']).'"';

		if(isset($data['companyLocality']))
			$impolde[] = 'companylocality = "'.$this->db->escape($data['companyLocality']).'"';

		if(isset($data['otherpayment']))
			$impolde[] = 'otherpayment = "'.$this->db->escape(htmlentities($htmlfilter->HTMLFilter(html_entity_decode($data['otherpayment']),'',true))).'"';

		if(isset($data['country']))
			$impolde[] = 'country = "'.$this->db->escape($data['country']).'"';

		if(isset($data['countryLogo']))
			$impolde[] = 'countrylogo = "'.$this->db->escape($data['countryLogo']).'"';

		if(isset($data['paypalid']))
			$impolde[] = 'paypalid = "'.$this->db->escape($data['paypalid']).'"';

		if($impolde){

			$sql = "UPDATE ".DB_PREFIX ."customerpartner_to_customer SET ";
			$sql .= implode(", ",$impolde);
			$sql .= " WHERE customer_id = '".$this->customer->getId()."'";
			$this->db->query($sql);
		}

		$files = $this->request->files;

		if(isset($files['companyBanner']['name']) AND $files['companyBanner']['name']){
			$files['companyBanner']['name'] = rand(100000,999999) . $files['companyBanner']["name"];
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set companybanner='catalog/".$this->db->escape($files['companyBanner']['name'])."' where customer_id='".$this->customer->getId()."'");
			move_uploaded_file($files['companyBanner']["tmp_name"], DIR_IMAGE . "catalog/" . $files['companyBanner']["name"]);
		} else if(isset($data['companybannerremove']) && $data['companybannerremove']) {
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set companybanner='removed' where customer_id='".$this->customer->getId()."'");
		}

		if(isset($files['companyLogo']['name']) AND $files['companyLogo']['name']){
			$files['companyLogo']['name'] = rand(100000,999999) . $files['companyLogo']["name"];
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set companylogo='catalog/".$this->db->escape($files['companyLogo']['name'])."' where customer_id='".$this->customer->getId()."'");
			move_uploaded_file($files['companyLogo']["tmp_name"], DIR_IMAGE . "catalog/" . $files['companyLogo']["name"]);
		} else if(isset($data['companylogoremove']) && $data['companylogoremove']) {
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set companylogo='removed' where customer_id='".$this->customer->getId()."'");
		}

		if(isset($files['avatar']['name']) AND $files['avatar']['name']){
			$files['avatar']['name'] = rand(100000,999999) . $files['avatar']["name"];
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set avatar='catalog/".$this->db->escape($files['avatar']['name'])."' where customer_id='".$this->customer->getId()."'");
			move_uploaded_file($files['avatar']["tmp_name"], DIR_IMAGE . "catalog/" . $files['avatar']["name"]);
		} else if(isset($data['avatarremove']) && $data['avatarremove']) {
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_customer set avatar='removed' where customer_id='".$this->customer->getId()."'");
		}
	}
	/**
	 * [getProfile to get seller's profile]
	 * @return [array] [details of seller]
	 */
	public function getProfile(){
		return $this->db->query("SELECT * FROM ".DB_PREFIX ."customerpartner_to_customer c2c LEFT JOIN ".DB_PREFIX."customer c ON (c2c.customer_id = c.customer_id) where c2c.customer_id = '".$this->customer->getId()."'")->row;
	}

	/**
	 * [getsellerEmail to get the seller's email id]
	 * @param  [integer] $seller_id [customer id of particuler seller]
	 * @return [string|boolean]            [email of false value]
	 */
	public function getsellerEmail($seller_id){
		$result = $this->db->query("SELECT email FROM ".DB_PREFIX ."customerpartner_to_customer c2c LEFT JOIN ".DB_PREFIX."customer c ON (c2c.customer_id = c.customer_id) where c2c.customer_id = '".$seller_id."'")->row;
		if(isset($result['email'])) {
			return $result['email'];
		} else {
			return false;
		}
	}
	/**
	 * [getCountry to get seller's country]
	 * @return [string] [country of seller]
	 */
	public function getCountry(){
		return $this->db->query("SELECT * FROM ".DB_PREFIX ."country")->rows;
	}
	/**
	 * [getSellerOrdersByProduct to get all orders by particular product]
	 * @param  [type] $product_id [product id of particular product]
	 * @param  [integer] $page       [fetched data limit start and end]
	 * @return [array]             [order details]
	 */
	public function getSellerOrdersByProduct($product_id,$page){
		$limit = 12;
		$start = ($page-1)*$limit;

		$sql = $this->db->query("SELECT o.order_id ,o.date_added, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus, c2o.price, c2o.quantity, c2o.paid_status  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."' AND c2o.product_id = '".(int)$product_id."' ORDER BY o.order_id DESC LIMIT $start,$limit ");
		return($sql->rows);
	}

	/**
	 * [getSellerOrdersTotalByProduct total count of orders as per the particular product]
	 * @param  [integer] $product_id [product id of particular product]
	 * @return [integer]             [total number of products]
	 */
	public function getSellerOrdersTotalByProduct($product_id){
		$sql = $this->db->query("SELECT o.order_id ,o.date_added, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."' AND c2o.product_id = '".(int)$product_id."' ORDER BY o.order_id ");

		return(count($sql->rows));
	}

	/**
	 * [getSellerOrders to get orders according to sellers]
	 * @param  [array]  $data [filter keywords]
	 * @return [array]       [order details]
	 */
	public function getSellerOrders($data = array()){

		$sql = "SELECT DISTINCT o.order_id ,o.date_added,c2o.currency_code,c2o.currency_value, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."'";

		if (isset($data['filter_order']) && !is_null($data['filter_order'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND ((o.firstname LIKE '%" . $this->db->escape($data['filter_name']) . "%') OR (o.lastname LIKE '%" . $this->db->escape($data['filter_name']) . "%') OR CONCAT(o.firstname,' ',o.lastname) like '%" . $this->db->escape($data['filter_name']) . "%') ";
		}

		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND os.name LIKE '%" . $data['filter_status'] . "%'";
		}

		if (!empty($data['filter_date'])) {
			$sql .= " AND o.date_added LIKE '%" . $this->db->escape($data['filter_date']) . "%'";
		}

		$sort_data = array(
			'o.order_id',
			'o.firstname',
			'os.name',
			'o.date_added'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.order_id";
		}

		if (isset($data['order']) && ($data['order'] == ' ASC')) {
			$sql .= " ASC";
		} else {
			$sql .= " DESC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getSellerOrdersTotal total count of orders of particular seller]
	 * @param  [array]  $data [filter keywords]
	 * @return [integer]       [total number of orders]
	 */
	public function getSellerOrdersTotal($data = array()){

		$sql = "SELECT DISTINCT o.order_id ,o.date_added,c2o.currency_code,c2o.currency_value, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."'";

		if (isset($data['filter_order']) && !is_null($data['filter_order'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order'] . "'";
		}

		if (!empty($data['filter_name'])) {
			$sql .= " AND ((o.firstname LIKE '%" . $this->db->escape($data['filter_name']) . "%') OR (o.lastname LIKE '%" . $this->db->escape($data['filter_name']) . "%') OR CONCAT(o.firstname,' ',o.lastname) like '%" . $this->db->escape($data['filter_name']) . "%') ";
		}

		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND os.name LIKE '%" . $data['filter_status'] . "%'";
		}

		if (!empty($data['filter_date'])) {
			$sql .= " AND o.date_added LIKE '%" . $this->db->escape($data['filter_date']) . "%'";
		}

		$query = $this->db->query($sql);

		return count($query->rows);
	}

	/**
	 * [getSellerOrderProducts to get products by order]
	 * @param  [integer] $order_id [order id of particular order]
	 * @return [array]           [details of products]
	 */
	public function getSellerOrderProducts($order_id,$filterValue=array()){


		$sql = "SELECT DISTINCT ws.start_day,ws.id,ws.end_day,ws.customer_name,op.name,op.model,op.product_id,op.order_id, c2o.order_product_status FROM " . DB_PREFIX ."customerpartner_to_order c2o LEFT JOIN " . DB_PREFIX . "order_product op  ON (c2o.order_product_id = op.order_product_id AND c2o.order_id = op.order_id) LEFT JOIN ".DB_PREFIX."wk_booking_slots ws ON (ws.product_id=op.product_id AND ws.order_id=op.order_id) WHERE c2o.order_id = '".(int)$order_id."'  AND c2o.customer_id = '".$this->customer->getId()."'";
		 if(isset($filterValue['customer_name']) && !is_null($filterValue['customer_name'])) {
	     	 $sql .= " AND ws.customer_name LIKE '%".$filterValue['customer_name']."%'";
	     }
	     if(isset($filterValue['from']) && !is_null($filterValue['from'])) {
	     	 $sql .= " AND ws.start_day = '".$filterValue['from']."'";
	     }
	     if(isset($filterValue['to']) && !is_null($filterValue['to'])) {
	     	 $sql .= " AND ws.end_day = '".$filterValue['to']."'";
	     }
	     if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
	     	 $sql .= " AND op.name LIKE '%".$filterValue['name']."%'";
	     }
	     if(isset($filterValue['hotel_name']) && !is_null($filterValue['hotel_name'])) {
	     	 $sql .= " AND op.model LIKE '%".$filterValue['hotel_name']."%'";
	     }
	     $sql .= ' ORDER BY op.product_id ';
	     $result = $this->db->query($sql);

		return($result->rows);
	}
	/**
	 * [getSellerOrderProducts to get products by order]
	 * @param  [integer] $order_id [order id of particular order]
	 * @return [array]           [details of products]
	 */
	public function getSellerOrderProductss($order_id){

		$sql = $this->db->query("SELECT op.*,c2o.price c2oprice, c2o.paid_status,c2o.order_product_status FROM " . DB_PREFIX ."customerpartner_to_order c2o LEFT JOIN " . DB_PREFIX . "order_product op ON (c2o.order_product_id = op.order_product_id AND c2o.order_id = op.order_id) WHERE c2o.order_id = '".(int)$order_id."'  AND c2o.customer_id = '".(int)$this->customer->getId()."' ORDER BY op.product_id ");

		return($sql->rows);
	}


	/**
	 * [getOrder to get details of a particular order]
	 * @param  [integer] $order_id [order id of particular order]
	 * @return [array|boolean]           [details of particular order|false]
	 */
	public function getOrder($order_id) {

		$order_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order` o LEFT JOIN " . DB_PREFIX . "customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE o.order_id = '" . (int)$order_id . "' AND o.order_status_id > '0' AND c2o.customer_id = '".$this->customer->getId()."'");

		if ($order_query->num_rows) {
			$country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

			if ($country_query->num_rows) {
				$payment_iso_code_2 = $country_query->row['iso_code_2'];
				$payment_iso_code_3 = $country_query->row['iso_code_3'];
			} else {
				$payment_iso_code_2 = '';
				$payment_iso_code_3 = '';
			}

			$zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

			if ($zone_query->num_rows) {
				$payment_zone_code = $zone_query->row['code'];
			} else {
				$payment_zone_code = '';
			}

			$country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

			if ($country_query->num_rows) {
				$shipping_iso_code_2 = $country_query->row['iso_code_2'];
				$shipping_iso_code_3 = $country_query->row['iso_code_3'];
			} else {
				$shipping_iso_code_2 = '';
				$shipping_iso_code_3 = '';
			}

			$zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

			if ($zone_query->num_rows) {
				$shipping_zone_code = $zone_query->row['code'];
			} else {
				$shipping_zone_code = '';
			}

			return array(
				'order_id'                => $order_query->row['order_id'],
				'invoice_no'              => $order_query->row['invoice_no'],
				'invoice_prefix'          => $order_query->row['invoice_prefix'],
				'store_id'                => $order_query->row['store_id'],
				'store_name'              => $order_query->row['store_name'],

				'store_url'               => $order_query->row['store_url'],
				'customer_id'             => $order_query->row['customer_id'],


				'firstname'               => $order_query->row['firstname'],
				'lastname'                => $order_query->row['lastname'],
				'telephone'               => $order_query->row['telephone'],
				'fax'                     => $order_query->row['fax'],
				'email'                   => $order_query->row['email'],
				'payment_firstname'       => $order_query->row['payment_firstname'],
				'payment_lastname'        => $order_query->row['payment_lastname'],
				'payment_company'         => $order_query->row['payment_company'],
				'payment_address_1'       => $order_query->row['payment_address_1'],
				'payment_address_2'       => $order_query->row['payment_address_2'],
				'payment_postcode'        => $order_query->row['payment_postcode'],
				'payment_city'            => $order_query->row['payment_city'],
				'payment_zone_id'         => $order_query->row['payment_zone_id'],
				'payment_zone'            => $order_query->row['payment_zone'],
				'payment_zone_code'       => $payment_zone_code,
				'payment_country_id'      => $order_query->row['payment_country_id'],
				'payment_country'         => $order_query->row['payment_country'],
				'payment_iso_code_2'      => $payment_iso_code_2,
				'payment_iso_code_3'      => $payment_iso_code_3,
				'payment_address_format'  => $order_query->row['payment_address_format'],
				'payment_method'          => $order_query->row['payment_method'],
				'comment'                 => $order_query->row['comment'],
				'total'                   => $order_query->row['total'],
				'order_status_id'         => $order_query->row['order_status_id'],
				'language_id'             => $order_query->row['language_id'],
				'currency_id'             => $order_query->row['currency_id'],
				'currency_code'           => $order_query->row['currency_code'],
				'currency_value'          => $order_query->row['currency_value'],
				'date_modified'           => $order_query->row['date_modified'],
				'date_added'              => $order_query->row['date_added'],
				'ip'                      => $order_query->row['ip']
			);
		} else {
			return false;
		}
	}

	/**
	 * [getOrderTotals to get particular order's total]
	 * @param  [integer] $order_id [order id of particular order]
	 * @return [integer]           [sum of order]
	 */
	public function getOrderTotals($order_id) {
		$query = $this->db->query("SELECT SUM(price) total FROM " . DB_PREFIX . "customerpartner_to_order WHERE order_id = '" . (int)$order_id . "' AND customer_id = '".$this->customer->getId()."'");

		return $query->rows;
	}

	/**
	 * [getManufacturers to get manufacturers]
	 * @param  [array]  $data [filter keywords]
	 * @return [array]       [details about manufacturer]
	 */
	public function getManufacturers($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "manufacturer";

		if (!empty($data['filter_name'])) {
			$sql .= " WHERE name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sort_data = array(
			'name',
			'sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY name";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getManufacturer to get particular manufacturer]
	 * @param  [integer] $manufacturer_id [id of manufacturer]
	 * @return [array]                  [details of manufacturer]
	 */
	public function getManufacturer($manufacturer_id) {
		$query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'manufacturer_id=" . (int)$manufacturer_id . "') AS keyword FROM " . DB_PREFIX . "manufacturer WHERE manufacturer_id = '" . (int)$manufacturer_id . "'");

		return $query->row;
	}

	/**
	 * [getCategories to get categories]
	 * @param  [array] $data [filter keywords]
	 * @return [array]       [details of categories]
	 */
	public function getCategories($data) {
		$sql = "SELECT cp.category_id AS category_id, GROUP_CONCAT(cd1.name ORDER BY cp.level SEPARATOR ' &gt; ') AS name, c.parent_id, c.sort_order FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category c ON (cp.path_id = c.category_id) LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (c.category_id = cd1.category_id) LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cp.category_id = cd2.category_id) WHERE cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' AND cd2.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (!empty($data['filter_name'])) {
			$sql .= " AND cd2.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY cp.category_id ORDER BY name";

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getCategory to get particular category details]
	 * @param  [integer] $category_id [category id of particular category]
	 * @return [array]              [category details]
	 */
	public function getCategory($category_id) {
		$query = $this->db->query("SELECT DISTINCT *, (SELECT GROUP_CONCAT(cd1.name ORDER BY level SEPARATOR ' &gt; ') FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (cp.path_id = cd1.category_id AND cp.category_id != cp.path_id) WHERE cp.category_id = c.category_id AND cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY cp.category_id) AS path, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'category_id=" . (int)$category_id . "') AS keyword FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (c.category_id = cd2.category_id) WHERE c.category_id = '" . (int)$category_id . "' AND cd2.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}

	/**
	 * [getFilters to get filters]
	 * @param  [array] $data [filter keywords]
	 * @return [array]       [detail about filters]
	 */
	public function getFilters($data) {
		$sql = "SELECT *, (SELECT name FROM " . DB_PREFIX . "filter_group_description fgd WHERE f.filter_group_id = fgd.filter_group_id AND fgd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS `group` FROM " . DB_PREFIX . "filter f LEFT JOIN " . DB_PREFIX . "filter_description fd ON (f.filter_id = fd.filter_id) WHERE fd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (!empty($data['filter_name'])) {
			$sql .= " AND fd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " ORDER BY f.sort_order ASC";

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getFilter to get detail about particular filter]
	 * @param  [integer] $filter_id [id of particular filter]
	 * @return [array]            [detail of particular filter]
	 */
	public function getFilter($filter_id) {
		$query = $this->db->query("SELECT *, (SELECT name FROM " . DB_PREFIX . "filter_group_description fgd WHERE f.filter_group_id = fgd.filter_group_id AND fgd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS `group` FROM " . DB_PREFIX . "filter f LEFT JOIN " . DB_PREFIX . "filter_description fd ON (f.filter_id = fd.filter_id) WHERE f.filter_id = '" . (int)$filter_id . "' AND fd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}


	/**
	 * [getAttributes to get attributes]
	 * @param  [array]  $data [filter keyowrds]
	 * @return [array]       [details of attributes]
	 */
	public function getAttributes($data = array()) {
		$sql = "SELECT *, (SELECT agd.name FROM " . DB_PREFIX . "attribute_group_description agd WHERE agd.attribute_group_id = a.attribute_group_id AND agd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS attribute_group FROM " . DB_PREFIX . "attribute a LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) WHERE ad.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (!empty($data['filter_name'])) {
			$sql .= " AND ad.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		if (!empty($data['filter_attribute_group_id'])) {
			$sql .= " AND a.attribute_group_id = '" . $this->db->escape($data['filter_attribute_group_id']) . "'";
		}

		$sort_data = array(
			'ad.name',
			'attribute_group',
			'a.sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY attribute_group, ad.name";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getAttribute to get detail for particular attribute]
	 * @param  [integer] $attribute_id [id of an attribute]
	 * @return [array]               [details of attribute]
	 */
	public function getAttribute($attribute_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "attribute a LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) WHERE a.attribute_id = '" . (int)$attribute_id . "' AND ad.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}

	/**
	 * [getOptions to get options]
	 * @param  [array]  $data [filter keywords]
	 * @return [array]       [details of options]
	 */
	public function getOptions($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "option` o LEFT JOIN " . DB_PREFIX . "option_description od ON (o.option_id = od.option_id) WHERE od.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (isset($data['filter_name']) && !is_null($data['filter_name'])) {
			$sql .= " AND od.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sort_data = array(
			'od.name',
			'o.type',
			'o.sort_order'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY od.name";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	/**
	 * [getOption to get detail of particular option]
	 * @param  [integer] $option_id [id of an option]
	 * @return [array]            [detail of particular option]
	 */
	public function getOption($option_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "option` o LEFT JOIN " . DB_PREFIX . "option_description od ON (o.option_id = od.option_id) WHERE o.option_id = '" . (int)$option_id . "' AND od.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}

	/**
	 * [getOptionValue to get value of an option]
	 * @param  [integer] $option_value_id [id of option's value]
	 * @return [array]                  [detail about the option value]
	 */
	public function getOptionValue($option_value_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_value_id = '" . (int)$option_value_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}

	/**
	 * [getOptionValues to get option's values]
	 * @param  [integer] $option_id [id of an option]
	 * @return [array]            [detail of option values]
	 */
	public function getOptionValues($option_id) {
		$option_value_data = array();

		$option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) WHERE ov.option_id = '" . (int)$option_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY ov.sort_order ASC");

		foreach ($option_value_query->rows as $option_value) {
			$option_value_data[] = array(
				'option_value_id' => $option_value['option_value_id'],
				'name'            => $option_value['name'],
				'image'           => $option_value['image'],
				'sort_order'      => $option_value['sort_order']
			);
		}

		return $option_value_data;
	}

	public function saveQuery($data){
		if(isset($data['hotel_id'])) {
		$this->db->query("INSERT INTO ".DB_PREFIX."customerpartner_hotel_query SET customer_id ='".(int)$this->customer->getId()."',seller_id = '".(int)$data['seller']."',hotel_id ='".(int)$data['hotel_id']."',room_id = '".(int)$data['product_id']."',bfrom = '".$this->db->escape($data['book_from'])."',bto = '".$this->db->escape($data['book_till'])."',subject ='".$this->db->escape($data['subject'])."',message = '".$this->db->escape($data['message'])."', status = 0 ,date_added = NOW()");
	 }
	}


	//Queries
	public function viewtotalentry($data)
    {

        $sql = "SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,chq.* FROM " . DB_PREFIX . "customerpartner_hotel_query chq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = chq.customer_id) WHERE chq.seller_id='".$this->customer->getID()."' AND chq.status=1";

        $implode = array();

        if (!empty($data['filter_id'])) {
            $implode[] = "chq.id = '" . (int)$data['filter_id'] . "'";
        }

        if (!empty($data['filter_customer'])) {
            $implode[] = " CONCAT(c.firstname, ' ', c.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
        }

        if (isset($data['filter_product']) && !is_null($data['filter_product'])) {
            $implode[] = "LCASE(pd.name) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_product'])) . "%'";
        }
        if (!empty($data['filter_date'])) {
            $implode[] = "LCASE(chq.date_added) LIKE '%" . $this->db->escape(utf8_strtolower($data['filter_date'])) . "%'";
        }

        if ($implode) {
            $sql .= " AND " . implode(" AND ", $implode);
        }

        $result = $this->db->query($sql);

        return count($result->rows);
    }
    public function viewtotal($data)
    {
        $sql = "SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,chq.* FROM " . DB_PREFIX . "customerpartner_hotel_query chq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = chq.customer_id) WHERE chq.seller_id='".$this->customer->getID()."' AND chq.status =1";
        $implode = array();

        if (!empty($data['filter_id'])) {
            $implode[] = "chq.id = '" . (int)$data['filter_id'] . "'";
        }

        if (!empty($data['filter_customer'])) {
            $implode[] = " CONCAT(c.firstname, ' ', c.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
        }
        if (!empty($data['filter_date'])) {
            $implode[] = "LCASE(chq.date_added) LIKE '%" . $this->db->escape(utf8_strtolower($data['filter_date'])) . "%'";
        }

        if ($implode) {
            $sql .= " AND " . implode(" AND ", $implode);
        }

        $sort_data = array(
         'chq.id',
         'c.firstname',
         'chq.room_id',
         'chq.status',
         'chq.date_added',
        );

        if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
            $sql .= " ORDER BY " . $data['sort'];
        } else {
            $sql .= " ORDER BY chq.id";
        }

        if (isset($data['order']) && ($data['order'] == 'DESC')) {
            $sql .= " ASC";
        } else {
            $sql .= " DESC";
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $result = $this->db->query($sql);

        return $result->rows;
    }
    public function viewtotalMessageBy($id){
    	// CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,pd.name,pd.product_id,pq.*,p.price as baseprice FROM " . DB_PREFIX . "product_quote pq LEFT JOIN " . DB_PREFIX . "customer c ON (c.customer_id = pq.customer_id)
    	return $this->db->query("SELECT CONCAT(c.firstname,' ',c.lastname) customer_name,c.email,ch.* FROM ".DB_PREFIX."customerpartner_hotel_query ch LEFT JOIN ".DB_PREFIX."customer c ON (c.customer_id = ch.customer_id) WHERE id= '".(int)$id."' AND ch.status=1")->row;
    }
}
?>
