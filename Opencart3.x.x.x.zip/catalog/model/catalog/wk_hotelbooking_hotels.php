<?php

class ModelCatalogWkhotelbookinghotels extends Model {
	//Facilities
  /**
   * [getFacilities description]
   * @param  [array] $filterValue [array of filters value]
   * @return [array]              [facilities arrray according to filter]
   */
    public function getFacilities($filterValue) {
      $sql = "SELECT * FROM ".DB_PREFIX."wk_hotel_facility wkh WHERE wkh.facility_type=1 ";
      if(!empty($filterValue['name'])) {
          $sql .= " AND wkh.facility_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND wkh.status = '".(int)$filterValue['status']."' ";
        }

        if($this->config->get('module_wk_hotelbooking_res_accfx')) {
          $sql .= " AND (wkh.owner = '".(int) $this->customer->getId()."' OR wkh.owner = 0)";
        } else{
           $sql .= "AND wkh.owner = '".(int) $this->customer->getId()."'";
        }
        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY wkh.facility_name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            else
              $sql .= " ORDER BY wkh.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }else{
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $result = $this->db->query($sql)->rows;
      return $result;
    }


/**
 * [getTotalFacilities description]
 * @param  [array] $filterValue [array of filters value]
 * @return [int]              [number of results of facilitites]
 */
    public function getTotalFacilities($filterValue) {
      $sql = "SELECT * FROM ".DB_PREFIX."wk_hotel_facility wkh WHERE wkh.facility_type=1 ";
      if(!empty($filterValue['name'])) {
          $sql .= " AND wkh.facility_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND wkh.status = '".(int)$filterValue['status']."' ";
        }

        if($this->config->get('module_wk_hotelbooking_res_accfx')) {
          $sql .= " AND (wkh.owner = '".(int) $this->customer->getId()."' OR wkh.owner = 0)";
        } else{
           $sql .= "AND wkh.owner = '".(int) $this->customer->getId()."'";
        }

      $result = $this->db->query($sql)->rows;
      return count($result) ;
    }



    /**
     * [addFacility description]
     * @param array  $data [array of facility value]
     * @param [type] $type [fixed/optional]
     */
    public function addFacility($data = array(),$type) {
      $this->db->query("INSERT INTO ".DB_PREFIX."wk_hotel_facility SET facility_name='".$this->db->escape($data['name'])."',facility_image = '".$this->db->escape($data['image'])."',status = '".(int)$data['status']."',sort_order = '".(int)$data['sort_order']."',facility_type = '".(int)$type."',facility_ocid = '".(int)$data['facility_ocid']."',owner='".(int)
        $this->customer->getId()."'");
    }
/**
 * [deleteOptFacility optional facility]
  */
    public function deleteOptFacility() {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_type = 2");
    }


/**
 * [deleteFxFacility fixed facility]
 * @param  [int] $attribute_id [facility_ocid of facility]
 */
    public function deleteFxFacility($attribute_id) {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid = '".(int)$attribute_id."'");
    }


/**
 * [getFacility for particular facility]
 * @param  [int] $facility_id [facility_ocid]
 * @return [array]              [details of particular facility]
 */
    public function getFacility($facility_id) {
    	$sql = "SELECT * FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid = '".(int)$facility_id."' ";
      if($this->config->get('module_wk_hotelbooking_res_accfx'))
        $sql .= " AND (owner = '".(int) $this->customer->getId()."' OR owner = 0)";
      else
        $sql .= "AND owner = '".(int) $this->customer->getId()."'";
      $result = $this->db->query($sql)->row;
    	return $result;
    }

/**
 * Edit the facility by getting it's ocid and type(fixed/optional)
 */

    public function editFacility($facility_id,$data=array(),$type) {
    	 $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_facility SET facility_name = '" . $this->db->escape($data['name']) . "',facility_image = '".$this->db->escape($data['image'])."', status = '".(int)$data['status']."', sort_order= '".$this->db->escape($data['sort_order'])."', facility_type ='".(int)$type."' WHERE facility_ocid = '" . (int)$facility_id . "' AND owner = '".(int)$this->customer->getId()."'");
    }
/**
 * [getEnableFacilities for getting ponly enable facilites in autocomplete at time of adding room]
 * @return [array] [enable  facilities]
 */
    public function getEnableFacilities() {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_facility WHERE status=1 AND owner = '".(int)$this->customer->getId()."'")->rows;
      return $result;
    }

/**
 * [geTotalRoomFacilities all rooms of a hotel with hotel_id]
 * @param  [int] $hotel_id [hotel id of hotel]
 * @return [array]           [array of rooms with thier details]
 */
    public function geTotalRoomFacilities($hotel_id) {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_room_detail WHERE hotel_id = '".(int)$hotel_id."'")->rows;
      return $result;
    }
/**
 * [geRoomFacilities for facilities of particular room]
 * @param  [int] $hotel_id [id of hotel]
 * @param  [int] $room_id  [id of room]
 * @return [type]           [array of room details]
 */
    public function geRoomFacilities($hotel_id,$room_id) {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_room_detail WHERE hotel_id = '".(int)$hotel_id."' AND room_id='".(int)$room_id."'")->row;
      return $result;
    }

/**
 * [getFixedFacility return all fixed facilities]
 * @return [array] [array of all attribute with details]
 */
    public function getFixedFacility($filterData = array()) {
     $sql = "SELECT DISTINCT *, (SELECT agd.name FROM " . DB_PREFIX . "attribute_group_description agd WHERE agd.attribute_group_id = a.attribute_group_id AND agd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS attribute_group FROM " . DB_PREFIX . "attribute a LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) LEFT JOIN ".DB_PREFIX."wk_hotel_facility wh ON (a.attribute_id = wh.facility_ocid) WHERE ad.language_id = '" . (int)$this->config->get('config_language_id') . "' AND wh.status = 1 AND wh.facility_type = 1 ";
     if($this->config->get('module_wk_hotelbooking_res_accfx')) {
      $sql .=" AND (wh.owner = '".$this->customer->getId()."' OR wh.owner=0)";
     } else {
      $sql .= " AND wh.owner = '".$this->customer->getId()."'";
     }
     if(isset($filterData['filter_name']) && $filterData['filter_name'] ){
       $sql .= "AND ad.name LIKE '%".$this->db->escape($filterData['filter_name'])."%'";
     }
     $query = $this->db->query($sql);

    return $query->rows;
    }
    //Rooms
    /**
     * [getRooms return all rooms]
     * @return [array] [arrray of all rooms]
     */
     public function getRooms($filterValue = array()) {
      $sql = "SELECT DISTINCT p.*,pd.name,cd.name as hotel_name FROM ".DB_PREFIX."product p RIGHT JOIN ".DB_PREFIX."wk_hotel_room wr ON (p.product_id=wr.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON(p.product_id=pd.product_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=wr.hotel_id) WHERE wr.owner = '".(int)$this->customer->getId()."' AND pd.language_id = '".$this->config->get('config_language_id')."'";
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND p.status = ".(int)$filterValue['status']."";
        }
        if(isset($filterValue['rname']) && !is_null($filterValue['rname'])) {
          $sql .= " AND pd.name like '%".$this->db->escape($filterValue['rname'])."%' ";
        }
        if(isset($filterValue['price']) && !is_null($filterValue['price'])) {
          $sql .= " AND p.price = ".(float)$filterValue['price']." ";
        }
        if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%'";
        }
        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY cd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            elseif($filterValue['order'] == 'price')
              $sql .= " ORDER BY p.price ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            elseif($filterValue['order'] == 'rname')
              $sql .= " ORDER BY pd.name ".$filterValue['sort']." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            else
              $sql .= " ORDER BY whd.".$filterValue['order']." ".$filterValue['sort']." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        } else if(isset($filterValue['start'])) {
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $results = $this->db->query($sql)->rows;


      $return_result = array();
      if($results) {
         foreach ($results as $result) {
           $return_result[] = array(
            'name' => $result['name'],
            'image' =>$result['image'],
            'status'=>$result['status'],
            'price'=>$result['price'],
            'room_id'=>$result['product_id'],
            'hotel_name' => $result['hotel_name']
            );
         }
       }
      return $return_result;
    }
    public function getAllRooms($filterValue = array()) {
     $sql = "SELECT DISTINCT p.*,pd.name,cd.name as hotel_name FROM ".DB_PREFIX."product p RIGHT JOIN ".DB_PREFIX."wk_hotel_room wr ON (p.product_id=wr.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON(p.product_id=pd.product_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=wr.hotel_id) WHERE wr.owner = '".(int)$this->customer->getId()."' AND pd.language_id = '".$this->config->get('config_language_id')."'";
       if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
         $sql .= " AND p.status = ".(int)$filterValue['status']."";
       }
       if(isset($filterValue['rname']) && !is_null($filterValue['rname'])) {
         $sql .= " AND pd.name like '%".$this->db->escape($filterValue['rname'])."%' ";
       }
       if(isset($filterValue['price']) && !is_null($filterValue['price'])) {
         $sql .= " AND p.price = ".(float)$filterValue['price']." ";
       }
       if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
         $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%'";
       }

     $results = $this->db->query($sql)->rows;
     return count($results);
   }
    /**
     * [addRoom insert the room details in wk_hotel_room table and add the required options to the room]
     * @param [int] $product_id [product_id of room]
     * @param array  $data       [details about room(product)]
     */
    public function addRoom($product_id , $data = array()) {
        if(!(int)$data['max_adult']) {
          $data['max_adult'] = 1;
        }
        $this->db->query("INSERT " . DB_PREFIX . "wk_hotel_room VALUES('".(int)$product_id."','".(int)$data['quantity']."', '".$this->db->escape($data['image'])."','".(int)$data['status']."','".(float)$data['price']."','".(int)$data['max_adult']."','".(int)$data['max_child']."','".(int)$data['hotel_id']."','".$this->db->escape($data['from'])."','".$this->db->escape($data['till'])."','".(int)$this->customer->getId()."', '".(int)$data['approve']."')");
            //Get the status of hotel
        $hotel_status = $this->db->query("SELECT status FROM ".DB_PREFIX."wk_hotel_details WHERE category_id = '".(int)$data['hotel_id']."'")->row;
        if($hotel_status && isset($hotel_status['status']) && $hotel_status['status'] == 0 && $data['status']) {
          $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$product_id."'");
          $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$product_id."'");
        }
          $duration=$this->config->get('wk_hotelbooking_options0');
          $rate=$this->config->get('wk_hotelbooking_options1');
          $from=$this->config->get('wk_hotelbooking_options2');
          $till=$this->config->get('wk_hotelbooking_options3');
          $adult=$this->config->get('wk_hotelbooking_options4');
          $child=$this->config->get('wk_hotelbooking_options5');
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$duration."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$rate."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$from."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$till."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$adult."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$child."','',0) ");

         $this->db->query("INSERT INTO `" . DB_PREFIX . "customerpartner_to_product` SET `product_id` = " . (int)$product_id . ",customer_id = '".$this->customer->getId()."',price = '".(float)$data['price']."',seller_price ='".(float)$data['price']."', currency_code = '".$this->session->data['currency']."',quantity = '".(int)$data['quantity']."'");

          $mailData = array(
         'name' => isset($data['product_description'][$this->config->get('config_language_id')]['name']) ? $data['product_description'][$this->config->get('config_language_id')]['name'] : '',
          'seller_id' => $this->customer->getId(),
          'customer_id' => false,
          'mail_id' => $this->config->get('module_wk_hotelbooking_res_mail_product_request'),
          'mail_from' => $this->config->get('config_email'),
          'mail_to' => $this->customer->getEmail(),
        );


    // $commission = $this->getSellerCommission($this->customer->getId());

        $values = array(
          'product_name' => $mailData['name'],
          'commission' => $this->config->get('module_wk_hotelbooking_res_commission')."%",
        );

        $this->load->model('customerpartner/mail');

        $this->model_customerpartner_mail->mail($mailData,$values);
        $mailData['mail_id'] = $this->config->get('module_wk_hotelbooking_res_mail_product_admin');
        $mailData['mail_from'] = $this->customer->getEmail();
        $mailData['mail_to'] = $this->config->get('config_email');


        if($this->config->get('module_wk_hotelbooking_res_mail_product_admin'))
          $this->model_customerpartner_mail->mail($mailData,$values);


    }
    /**
     * [getRoom for information about particular room]
     * @param  [int] $room_id [product id of room]
     * @return [array]          [details about particular room in array]
     */
    public function getRoom($room_id) {
        $query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN ".DB_PREFIX."wk_hotel_room wr ON (wr.product_id = p.product_id) WHERE p.product_id = '" . (int)$room_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND owner = '".(int)
          $this->customer->getId()."'");
        return $query->row;
    }
    /**
     * [editRoom for update the room value after edit]
     * @param  [int] $room_id [product_id of room]
     * @param  array  $data    [updated values during edit]
     */
    public function editRoom($room_id,$data=array()) {
         if($this->config->get('module_wk_hotelbooking_res_roomdisapprove')) {
           $data['approve'] = 0;
           $data['status'] =0;
           $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$room_id."'");
         }
         //Prev Status
         $is_avail = $this->db->query("SELECT approve FROM ".DB_PREFIX."wk_hotel_room WHERE product_id = '".(int)$room_id."'")->row;
         if($is_avail && isset($is_avail['approve']) && !$is_avail['approve']) {
           $data['approve'] = 0;
           $data['status'] =0;
           $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$room_id."'");
         }
         if(!(int)$data['max_adult']) {
           $data['max_adult'] = 1;
         }
         $sql ="UPDATE ".DB_PREFIX."wk_hotel_room SET quantity = '" . (int)$data['quantity'] . "',image = '".$this->db->escape($data['image'])."', status = '".(int)$data['status']."', price= '".(float)$data['price']."' , max_adult ='".(int)$data['max_adult']."' , max_child ='".(int)$data['max_child']."' , hotel_id = '".(int)$data['hotel_id']."' , start_from = '".$this->db->escape($data['from'])."', till = '".$this->db->escape($data['till'])."' ";
         if(isset($data['approve'])) {
          $sql.=", approve = '".(int)$data['approve']."'" ;
         }
         $sql.= " WHERE product_id = '" . (int)$room_id . "' AND owner = '".(int)$this->customer->getId()."'";

         $this->db->query($sql);
             //Get the status of hotel
        $hotel_status = $this->db->query("SELECT status FROM ".DB_PREFIX."wk_hotel_details WHERE category_id = '".(int)$data['hotel_id']."'")->row;
        if($hotel_status && isset($hotel_status['status']) && $hotel_status['status'] == 0 && $data['status']) {
          $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$room_id."'");
          $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$room_id."'");
        }
          $options= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id='".(int)$room_id."' AND option_id= '".(int)$this->config->get('wk_hotelbooking_options0')."'")->row;
          if(!$options){
            $duration=$this->config->get('wk_hotelbooking_options0');
            $rate=$this->config->get('wk_hotelbooking_options1');
            $from=$this->config->get('wk_hotelbooking_options2');
            $till=$this->config->get('wk_hotelbooking_options3');
            $adult=$this->config->get('wk_hotelbooking_options4');
            $child=$this->config->get('wk_hotelbooking_options5');
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$duration."','',1) ");
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$rate."','',1) ");
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$from."','',1) ");
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$till."','',1) ");
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$adult."','',1) ");
            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$child."','',0) ");
          }
           $this->db->query("UPDATE `" . DB_PREFIX . "customerpartner_to_product` SET price = '".(float)$data['price']."',seller_price ='".(float)$data['price']."', currency_code = '".$this->session->data['currency']."',quantity = '".(int)$data['quantity']."'");

		if(isset($data['status']) && !$data['status'] && $this->config->get('module_wk_hotelbooking_res_roomdisapprove')) {
			$this->load->model('customerpartner/mail');

			$mailData = array (
				'name' => isset($data['product_description'][$this->config->get('config_language_id')]['name']) ? $data['product_description'][$this->config->get('config_language_id')]['name'] : '',
				'seller_id' => $this->customer->getId(),
	        	'customer_id' => false,
	        	'mail_id' => $this->config->get('module_wk_hotelbooking_res_mail_seller_on_edit'),
	        	'mail_from' => $this->config->get('config_email'),
	        	'mail_to' => $this->customer->getEmail(),
			);
	        $values = array(
	        	'product_name' =>  isset($data['product_description'][$this->config->get('config_language_id')]['name']) ? $data['product_description'][$this->config->get('config_language_id')]['name'] : '',
				'commission' => $this->config->get('module_wk_hotelbooking_res_commission')."%",
	        );
			$this->model_customerpartner_mail->mail($mailData, $values);
			$mailData['mail_id'] = $this->config->get('module_wk_hotelbooking_res_mail_admin_on_edit');
			$mailData['mail_from'] = $this->customer->getEmail();
			$mailData['mail_to'] = $this->config->get('config_email');
			$this->model_customerpartner_mail->mail($mailData, $values);
		}

    }
    /**
     * [getRoomOfHotel rooms of particular hotel]
     * @param  [int] $hotel_id [id of hotel]
     * @return [array]           [room details of hotel in array]
     */
    public function getRoomOfHotel($hotel_id){
      $results = $this->db->query("SELECT wr.*,p.name FROM ".DB_PREFIX."wk_hotel_room wr LEFT JOIN ".DB_PREFIX."product_description p ON (wr.product_id=p.product_id) WHERE hotel_id ='".(int)$hotel_id."' AND owner = '".(int)
        $this->customer->getId()."'")->rows;
      return $results;
     }
/**
 * [deleteRoom description]
 * @param  [int] $product_id [product_id of room]
 */
    public function deleteRoom($product_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "customerpartner_to_product WHERE product_id = '" . (int)$product_id . "'");
         $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_room WHERE product_id='".(int)$product_id."' AND owner = '".(int)
          $this->customer->getId()."'");
    }

    //Hotels
    /**
     * [getHotels return all hotels]
     * @param  array  $filterValue
     * @return [array]              [all hotels details according to the filtervalue]
     */
     public function getHotels($filterValue = array()) {

      $sql = "SELECT whd.*,c.image,cd.name FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND whd.owner = '".(int)
      $this->customer->getId()."'";
      if(!empty($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND whd.status = ".$this->db->escape($filterValue['status'])."";
        }
        if(!empty($filterValue['website'])) {
          $sql .= " AND whd.website like '%".$this->db->escape($filterValue['website'])."%' ";
        }
        if(!empty($filterValue['address'])) {
          $sql .= " AND whd.address like '%".$this->db->escape($filterValue['address'])."%' ";
        }

        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY cd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            else
              $sql .= " ORDER BY whd.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }else if(isset($filterValue['start'])){
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $result = $this->db->query($sql)->rows;
      return $result;
    }
    public function getTotalHotels($filterValue = array()) {

     $sql = "SELECT whd.*,c.image,cd.name FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND whd.owner = '".(int)
     $this->customer->getId()."'";
     if(!empty($filterValue['name'])) {
         $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
       }
       if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
         $sql .= " AND whd.status = ".$this->db->escape($filterValue['status'])."";
       }
       if(!empty($filterValue['website'])) {
         $sql .= " AND whd.website like '%".$this->db->escape($filterValue['website'])."%' ";
       }
       if(!empty($filterValue['address'])) {
         $sql .= " AND whd.address like '%".$this->db->escape($filterValue['address'])."%' ";
       }
     $result = $this->db->query($sql)->rows;
     return count($result);
   }
/**
 * [addHotel adding the new hotel ]
 * @param [int] $category_id [category id which is from opencart after adding to the category]
 * @param [array] $postData    [other hotel details saved on our tables]
 */
    public function addHotel($category_id,$postData) {
            $lat=0;
            $long=0;
            $address = str_replace(" ", "+", $postData['bookingaddress']);
            $url = "https://maps.google.com/maps/api/geocode/json?address=$address";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
            // curl_setopt($ch, CURLOPT_true_VERIFYHOST, 0);
            // curl_setopt($ch, CURLOPT_true_VERIFYPEER, 0);
            $response = curl_exec($ch);
            curl_close($ch);
            $response_a = json_decode($response);
            if(isset($response_a->results) && isset($response_a->results[0]->geometry->location->lat))
            $lat = $response_a->results[0]->geometry->location->lat;
            if(isset($response_a->results) && isset($response_a->results[0]->geometry->location->lng))
            $long = $response_a->results[0]->geometry->location->lng;
            $is_avail = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id = '".(int)$category_id."' AND owner = '".(int)$this->customer->getId()."'")->row;
            if($is_avail) {
                $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_details WHERE category_id='".(int)$category_id."'");
                if($this->config->get('module_wk_hotelbooking_res_hoteldisapprove')) {
                  $postData['status'] = 0;
                  $postData['approve'] = 0;
                } else {
                  $postData['approve'] = $is_avail['approve'];
                }
            } else {
              $postData['approve'] = $this->config->get('module_wk_hotelbooking_res_hotelapprove');
            }

            if($postData['approve']==0) {
              $postData['status'] = 0;
              $this->db->query("UPDATE ".DB_PREFIX."category SET status = 0 WHERE category_id='".(int)$category_id."'");
            }
        $this->db->query("INSERT INTO " . DB_PREFIX . "wk_hotel_details SET category_id = ".(int)$category_id.",status = '".(int)$postData['status']."', address = '".$this->db->escape($postData['bookingaddress'])."',email = '".$this->db->escape($postData['bookingemail'])."',website = '".$this->db->escape($postData['bookingwebsite'])."', contact = '".$this->db->escape($postData['bookingcontact'])."',faxno = '". $this->db->escape($postData['bookingfaxno'])."',checkin = '".(int)$postData['bookingcheckin']."',checkin_ap='".$this->db->escape($postData['bookingcheckinap'])."',checkout = '".(int)$postData['bookingcheckout']."',checkout_ap = '".$this->db->escape($postData['bookingcheckoutap'])."',latitude = '".(float)$lat."',longitude = '".(float)$long."',owner = '".(int)$this->customer->getId()."', approve = '".(int)$postData['approve']."'");
        if($postData['status']==0) {
            $rooms = $this->db->query("SELECT p.product_id FROM ".DB_PREFIX."product p LEFT JOIN ".DB_PREFIX."product_to_category pc ON(pc.product_id=p.product_id)WHERE pc.category_id = '".(int)$category_id."'");
            if($rooms) {
              foreach ($rooms as $key => $value) {
                if(isset($value['product_id'])) {
                  $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$value['product_id']."'");
                  $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$value['product_id']."'");
                }
              }
            }

        }
    }
    /**
     * [getHotelDetails return details of particular hotel]
     * @param  [int] $category_id [category id of hotel]
     * @return [array]              [information about particular hotel]
     */
    public function getHotelDetails($category_id) {
       $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id ='".(int)$category_id."' AND owner = '".(int)
        $this->customer->getId()."'")->row;
       return $result;
    }
    /**
     * [deleteHotel delete particular hotel]
     * @param  [int] $category_id [category id of hotel(category)]
     */
    public function deleteHotel($category_id) {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_details WHERE category_id ='".(int)$category_id."' AND owner = '".(int)
        $this->customer->getId()."'");
    }
    /**
     * [getTotalRooms all rooms of hotel with id = hotel_id]
     * @param  [int] $hotel_id [hotel id of hotel]
     * @return [int]           [number of total room in particular hotel]
     */
    public function getTotalRooms($hotel_id) {
      $total = $this->db->query("SELECT COUNT(*) AS total FROM ".DB_PREFIX."wk_hotel_room WHERE hotel_id='".(int)$hotel_id."' and owner = '".(int)
        $this->customer->getId()."'")->row;
      return $total['total'];
    }

//Reviews
/**
 * [editReview update the existing review]
 * @param  [int] $review_id [review id ]
 * @param  [array] $data      [details of review]
 */
  public function editReview($review_id, $data) {
    $this->db->query("UPDATE " . DB_PREFIX . "wk_hotel_reviews SET customer_name = '" . $this->db->escape($data['author']) . "', response = '" . $this->db->escape(strip_tags($data['text'])) . "', rating = '" . (int)$data['rating'] . "', status = '" . (int)$data['status'] . "', date = NOW() WHERE id = '" . (int)$review_id . "'");
  }
/**
 * [deleteReview delete particular review by review id]
 * @param  [int] $review_id [review id which is to be delete]
 */
  public function deleteReview($review_id) {
    $this->db->query("DELETE FROM " . DB_PREFIX . "wk_hotel_reviews WHERE id = '" . (int)$review_id . "'");

  }
/**
 * [getReview information about particular review]
 * @param  [int] $review_id [review id of review]
 * @return [array]            [details of review in array]
 */
  public function getReview($review_id) {
    $query = $this->db->query("SELECT * FROM ".DB_PREFIX. "wk_hotel_reviews r WHERE r.id = '" . (int)$review_id . "'");

    return $query->row;
  }
/**
 * [getReviews array of all reviews]
 * @param  array  $data [filter values]
 * @return [array]       [details of all reviews]
 */
  public function getReviews($data = array()) {

    $sql = "SELECT r.*,cd.name FROM ".DB_PREFIX."wk_hotel_details wd LEFT JOIN ". DB_PREFIX . "wk_hotel_reviews r ON (wd.category_id = r.hotel_id)  LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=r.hotel_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND wd.owner = '".$this->customer->getId()."'";

    if (!empty($data['filter_product'])) {
      $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    }

    if (!empty($data['filter_author'])) {
      $sql .= " AND r.customer_name LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
    }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND r.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(r.date) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $sort_data = array(
      'cd.name',
      'r.customer_name',
      'r.rating',
      'r.status',
      'r.date'
    );

    if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
      $sql .= " ORDER BY " . $data['sort'];
    } else {
      $sql .= " ORDER BY r.date";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " ASC";
    } else {
      $sql .= " DESC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
    }

    $query = $this->db->query($sql);
    return $query->rows;
  }
/**
 * [getTotalReviews number of allreview]
 * @param  array  $data [filter values]
 * @return [int]       [number of all reviewws according to the filter value]
 */
  public function getTotalReviews($data = array()) {

        $sql = "SELECT r.*,cd.name FROM ".DB_PREFIX."wk_hotel_details wd LEFT JOIN ". DB_PREFIX . "wk_hotel_reviews r ON (wd.category_id = r.hotel_id)  LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=r.hotel_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND wd.owner = '".$this->customer->getId()."'";

        if (!empty($data['filter_product'])) {
          $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
        }

        if (!empty($data['filter_author'])) {
          $sql .= " AND r.customer_name LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
        }

        if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
          $sql .= " AND r.status = '" . (int)$data['filter_status'] . "'";
        }

        if (!empty($data['filter_date_added'])) {
          $sql .= " AND DATE(r.date) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
        }

        $query = $this->db->query($sql);
        return count($query->rows);
  }
  /**
   * [updateBooking update slots when booking from back end]
   * @param  [int] $pid      [product_id of room]
   * @param  [int] $order_id [order_id]
   * @param  [date] $from     [booking from date]
   * @param  [date] $till     [booking till date]
   * @param  [int] $quantity [quantity of room]
   * @param  [array] $ementies [extra ementies]
   */
  public function updateBooking($pid,$order_id,$from,$till,$quantity,$name='',$email='',$telephone='',$ementies){
    if ($this->customer->isLogged()) {
      if(!$name)
      $name=$this->customer->getFirstName().' '.$this->customer->getLastName();
      if(!$email)
      $email=$this->customer->getEmail();
    if(!$telephone)
      $telephone=$this->customer->getTelephone();
    } else {
      if(!$name)
      $name = $this->session->data['guest']['firstname'].' '.$this->session->data['guest']['lastname'];
      if(!$email)
      $email = $this->session->data['guest']['email'];
    if(!$telephone)
      $telephone = $this->session->data['guest']['telephone'];
    }
    $this->db->query("INSERT INTO " . DB_PREFIX . "wk_booking_slots VALUES('',".(int)$pid.",'".(int)$order_id."','".$this->db->escape($from)."','".$this->db->escape($till)."',".(int)$quantity.",'".$this->db->escape($name)."','".$this->db->escape($email)."','".$this->db->escape($telephone)."','".$ementies."',1)");
}
/**
 * [getBookedSlots return booked slots of particular room on the basis from start and last date]
 * @param  [int] $product_id [product_id of room]
 * @param  [date] $start_date [booking from date]
 * @param  [date] $last_Date  [booking till date by customer/admin]
 * @return [array]             [all slots between from and till date]
 */
public function getBookedSlots($product_id,$start_date,$last_Date){
$bookedSlots= $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id= ".(int)$product_id." AND NOT(( DATE(start_day) < '".$last_Date."' AND DATE(end_day) < '".$start_date."') OR (DATE(start_day) > '".$last_Date."'AND DATE(end_day) > '".$start_date."'))")->rows;
return $bookedSlots;
}
/**
 * [viewtotalentry return number of  all bookable poroduct(room)]
 * @param  [array] $filterValue [filter parameters]
 * @return [array]              [number of all rooms]
 */
public function viewtotalbookingentry($filterValue){

  $sql = "SELECT DISTINCT o.order_id ,o.date_added,c2o.currency_code,c2o.currency_value, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."'";
  if(isset($filterValue['date_added']) && !is_null($filterValue['date_added'])) {
    $sql .= " AND o.date_added >= '".$this->db->escape($filterValue['date_added'])."'";
  }
  if(isset($filterValue['order_id']) && !is_null($filterValue['order_id'])) {
    $sql .= " AND o.order_id = '".(int)$filterValue['order_id']."'";
  }
  if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
    $sql .= " AND CONCAT(o.firstname ,' ',o.lastname) LIKE '%".$this->db->escape($filterValue['name'])."%'";
  }
  $sort_data = array(
    'order_id',
    'name',
    'date_added'
  );
  if (isset($filterValue['sort']) && $filterValue['sort']) {
    $filterValue['sort'] = $filterValue['sort'];
  } else {
    $filterValue['sort'] = " DESC";
  }
  if (isset($filterValue['order']) && in_array($filterValue['order'], $sort_data)) {
    if($filterValue['order']=='name') {
        $sql .= " ORDER BY  CONCAT(o.firstname ,' ',o.lastname) ".$filterValue['sort'];
    } else {
        $sql .= " ORDER BY  o.".$filterValue['order']." ".$filterValue['sort'];
    }
  } else {
    $sql .= " ORDER BY o.date_added DESC";
  }

    $results = $this->db->query($sql);
    return count($results->rows);
  }
   /**
   * [viewtotalbookings return all bookings of a particular room]
   * @param  [type] $id          [room_id of room]
   * @param  array  $filterValue [filter parameters]
   * @return [array]              [array of booking slots]
   */
  public function viewtotalbookings($filterValue=array()){
  $sql = "SELECT DISTINCT o.order_id ,o.date_added,c2o.currency_code,c2o.currency_value, CONCAT(o.firstname ,' ',o.lastname) name ,os.name orderstatus  FROM " . DB_PREFIX ."order_status os LEFT JOIN `".DB_PREFIX ."order` o ON (os.order_status_id = o.order_status_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_order c2o ON (o.order_id = c2o.order_id) WHERE c2o.customer_id = '".$this->customer->getId()."'  AND os.language_id = '".$this->config->get('config_language_id')."'";
    if(isset($filterValue['date_added']) && !is_null($filterValue['date_added'])) {
      $sql .= " AND o.date_added >= '".$this->db->escape($filterValue['date_added'])."'";
    }
    if(isset($filterValue['order_id']) && !is_null($filterValue['order_id'])) {
      $sql .= " AND o.order_id = '".(int)$filterValue['order_id']."'";
    }
    if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
      $sql .= " AND CONCAT(o.firstname ,' ',o.lastname) LIKE '%".$this->db->escape($filterValue['name'])."%'";
    }
    $sort_data = array(
      'order_id',
      'name',
      'date_added'
    );
    if (isset($filterValue['sort']) && $filterValue['sort']) {
      $filterValue['sort'] = $filterValue['sort'];
    } else {
      $filterValue['sort'] = " DESC";
    }
    if (isset($filterValue['order']) && in_array($filterValue['order'], $sort_data)) {
      if($filterValue['order']=='name') {
          $sql .= " ORDER BY  CONCAT(o.firstname ,' ',o.lastname) ".$filterValue['sort'];
      } else {
          $sql .= " ORDER BY  o.".$filterValue['order']." ".$filterValue['sort'];
      }
    } else {
      $sql .= " ORDER BY o.date_added DESC";
    }

    if (isset($filterValue['start']) || isset($filterValue['limit'])) {
      if ($filterValue['start'] < 0) {
        $filterValue['start'] = 0;
      }

      if ($filterValue['limit'] < 1) {
        $filterValue['limit'] = 20;
      }

      $sql .= " LIMIT " . (int)$filterValue['start'] . "," . (int)$filterValue['limit'];
    }

    $results = $this->db->query($sql);
    return $results->rows;
  }
  /**
 * [viewtotalentry return   all bookable poroduct(room)]
 * @param  [array] $filterValue [filter parameters]
 * @return [array]              [ all rooms]
 */
    public function viewtotal($filterValue){

    $sql ="SELECT br.product_id,pd.name,br.start_from,br.till,br.status  FROM " . DB_PREFIX . "wk_hotel_room br LEFT JOIN " . DB_PREFIX . "product_description pd ON(pd.product_id = br.product_id) WHERE pd.language_id = '" . $this->config->get('config_language_id') . "' AND br.owner =  '".(int)
    $this->customer->getId()."'";

    if(!empty($filterValue['name'])) {
      $sql .= " AND pd.name like '%".$this->db->escape($filterValue['name'])."%' ";
    }

    if(!empty($filterValue['from'])) {
      $sql .= " AND br.start_from = '".$this->db->escape($filterValue['from'])."' ";
    }

    if(!empty($filterValue['to'])) {
      $sql .= " AND br.till = '".$this->db->escape($filterValue['to'])."' ";
    }

    if(!empty($filterValue['status']) || (isset($filterValue['status']) && $filterValue['status']==0)) {
      $sql .= " AND br.status = '".(int)$filterValue['status']."' ";
    }
    if(!empty($filterValue['order'])) {
      if($filterValue['order'] == 'name')
        $sql .= " ORDER BY pd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
      else
        $sql .= " ORDER BY br.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
    }else{
      $sql .= " ORDER BY br.start_from DESC LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
    }

    $result=$this->db->query($sql);

    return $result->rows;
  }

  /**
   * [exportHistory description]
   * @param  [int] $product_id [product_id of room]
   * @param  [date] $from       [booking from date]
   * @param  [date] $to         [booking till date]
   * @return [type]             [array of slots during export between from and till date]
   */
  public function exportHistory($product_id,$from,$to){

    $results=$this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id = ".(int)$product_id." AND start_day >= '".$this->db->escape($from)."'  AND end_day <= '".$this->db->escape($to)."'")->rows;
    return $results;
  }
    public function cancelBooking($order_id) {

    $seller_products = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots ws LEFT JOIN ".DB_PREFIX."wk_hotel_room wr ON (ws.product_id=wr.product_id) WHERE ws.order_id = '".(int)$order_id."' AND wr.owner = '".(int)$this->customer->getId()."'")->rows;
    foreach ($seller_products as $key => $value) {
    $this->db->query("UPDATE ".DB_PREFIX."wk_booking_slots SET status = 0 WHERE order_id = '".(int)$order_id."' AND id='".(int)$value['id']."'");
    }
  }

  public function getSellerOptionValues($option_id) {
    $option_value_data = array();
    if($this->config->get('module_wk_hotelbooking_res_accop')) {
        $option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) LEFT JOIN ".DB_PREFIX."wk_hotel_facility wf ON (wf.facility_ocid = ov.option_value_id) WHERE ov.option_id = '" . (int)$option_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND (wf.owner = '".(int)$this->customer->getId()."' OR wf.owner = 0) AND wf.status = 1 ORDER BY ov.sort_order, ovd.name");

    } else {
      $option_value_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value ov LEFT JOIN " . DB_PREFIX . "option_value_description ovd ON (ov.option_value_id = ovd.option_value_id) LEFT JOIN ".DB_PREFIX."wk_hotel_facility wf ON (wf.facility_ocid = ov.option_value_id) WHERE ov.option_id = '" . (int)$option_id . "' AND ovd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND wf.owner = '".(int)$this->customer->getId()."' AND wf.status = 1 ORDER BY ov.sort_order, ovd.name");
    }

    foreach ($option_value_query->rows as $option_value) {
      $option_value_data[] = array(
        'option_value_id' => $option_value['option_value_id'],
        'name'            => $option_value['name'],
        'image'           => $option_value['image'],
        'sort_order'      => $option_value['sort_order']
      );
    }

    return $option_value_data;
  }

  public function getOptionValueDescriptions($option_id) {
    $option_value_data = array();
    if($this->config->get('module_wk_hotelbooking_res_accop')) {
      $option_value_query = $this->db->query("SELECT o.*,wf.facility_image as image,wf.status,wf.owner  FROM " . DB_PREFIX . "option_value o LEFT JOIN ".DB_PREFIX."wk_hotel_facility wf ON (wf.facility_ocid = o.option_value_id) WHERE o.option_id = '" . (int)$option_id . "' AND (wf.owner = '".(int)$this->customer->getId()."' OR wf.owner = 0 ) ORDER BY o.sort_order");
    } else {
      $option_value_query = $this->db->query("SELECT o.*,wf.facility_image as image,wf.status,wf.owner  FROM " . DB_PREFIX . "option_value o LEFT JOIN ".DB_PREFIX."wk_hotel_facility wf ON (wf.facility_ocid = o.option_value_id) WHERE o.option_id = '" . (int)$option_id . "' AND wf.owner = '".(int)$this->customer->getId()."' ORDER BY o.sort_order");
    }

    foreach ($option_value_query->rows as $option_value) {
      $option_value_description_data = array();

      $option_value_description_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value_description WHERE option_value_id = '" . (int)$option_value['option_value_id'] . "'");

      foreach ($option_value_description_query->rows as $option_value_description) {
        $option_value_description_data[$option_value_description['language_id']] = array('name' => $option_value_description['name']);
      }

      $option_value_data[] = array(
        'option_value_id'          => $option_value['option_value_id'],
        'option_value_description' => $option_value_description_data,
        'image'                    => $option_value['image'],
        'sort_order'               => $option_value['sort_order'],
        'status'                   => $option_value['status'],
        'owner'                    => $option_value['owner']
      );
    }

    return $option_value_data;
  }
 public function getOtherOptions($option_id){
  $option_value_data = array();

    $option_value_query = $this->db->query("SELECT o.*,wf.owner,wf.status FROM " . DB_PREFIX . "option_value o LEFT JOIN ".DB_PREFIX."wk_hotel_facility wf ON (wf.facility_ocid = o.option_value_id) WHERE o.option_id = '" . (int)$option_id . "' AND wf.owner != '".(int)$this->customer->getId()."' ORDER BY o.sort_order");

    foreach ($option_value_query->rows as $option_value) {
      $option_value_description_data = array();

      $option_value_description_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "option_value_description WHERE option_value_id = '" . (int)$option_value['option_value_id'] . "'");

      foreach ($option_value_description_query->rows as $option_value_description) {
        $option_value_description_data[$option_value_description['language_id']] = array('name' => $option_value_description['name']);
      }

      $option_value_data[] = array(
        'option_value_id'          => $option_value['option_value_id'],
        'option_value_description' => $option_value_description_data,
        'image'                    => $option_value['image'],
        'sort_order'               => $option_value['sort_order'],
        'owner'                    => $option_value['owner'],
        'status'                   => $option_value['status']
      );
    }

    return $option_value_data;
 }
 public function getCategoryDescriptions($category_id) {
    $category_description_data = array();

    $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_description WHERE category_id = '" . (int)$category_id . "'");

    foreach ($query->rows as $result) {
      $category_description_data[$result['language_id']] = array(
        'name'             => $result['name'],
        'meta_title'       => $result['meta_title'],
        'meta_description' => $result['meta_description'],
        'meta_keyword'     => $result['meta_keyword'],
        'description'      => $result['description']
      );
    }

    return $category_description_data;
  }
public function getProductAttributes($product_id) {
    $product_attribute_data = array();

    $product_attribute_query = $this->db->query("SELECT attribute_id FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' GROUP BY attribute_id");

    foreach ($product_attribute_query->rows as $product_attribute) {
      $product_attribute_description_data = array();

      $product_attribute_description_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$product_attribute['attribute_id'] . "'");

      foreach ($product_attribute_description_query->rows as $product_attribute_description) {
        $product_attribute_description_data[$product_attribute_description['language_id']] = array('text' => $product_attribute_description['text']);
      }

      $product_attribute_data[] = array(
        'attribute_id'                  => $product_attribute['attribute_id'],
        'product_attribute_description' => $product_attribute_description_data
      );
    }

    return $product_attribute_data;
  }

  public function getProductDescriptions($product_id) {
    $product_description_data = array();

    $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$product_id . "'");

    foreach ($query->rows as $result) {
      $product_description_data[$result['language_id']] = array(
        'name'             => $result['name'],
        'description'      => $result['description'],
        'meta_title'       => $result['meta_title'],
        'meta_description' => $result['meta_description'],
        'meta_keyword'     => $result['meta_keyword'],
        'tag'              => $result['tag']
      );
    }

    return $product_description_data;
  }

public function getProductCategories($product_id) {
    $product_category_data = array();

    $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "'");

    foreach ($query->rows as $result) {
      $product_category_data[] = $result['category_id'];
    }

    return $product_category_data;
  }
  public function countTotal($args='') {
    switch ($args) {
      case 'hotel':
        return count($this->db->query('SELECT * FROM '.DB_PREFIX."wk_hotel_details WHERE owner = '".(int)$this->customer->getId()."'")->rows);
        break;
      case 'room' :
        return count($this->db->query('SELECT * FROM '.DB_PREFIX."wk_hotel_room WHERE owner = '".(int)$this->customer->getId()."'")->rows);
      break;
      case 'facility1' :
        return count($this->db->query('SELECT * FROM '.DB_PREFIX."wk_hotel_facility WHERE owner = '".(int)$this->customer->getId()."' AND facility_type = 1")->rows);
      break;
      case 'facility2' :
        return count($this->db->query('SELECT * FROM '.DB_PREFIX."wk_hotel_facility WHERE owner = '".(int)$this->customer->getId()."' AND facility_type = 2")->rows);
      break;
      default:
        return false;
        break;
    }
  }
  public function editOption($option_id, $data) {

    $this->db->query("UPDATE `" . DB_PREFIX . "option` SET type = '" . $this->db->escape($data['type']) . "', sort_order = '" . (int)$data['sort_order'] . "' WHERE option_id = '" . (int)$option_id . "'");

    $this->db->query("DELETE FROM " . DB_PREFIX . "option_description WHERE option_id = '" . (int)$option_id . "'");

    foreach ($data['option_description'] as $language_id => $value) {
      $this->db->query("INSERT INTO " . DB_PREFIX . "option_description SET option_id = '" . (int)$option_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");
    }

    $this->db->query("DELETE FROM " . DB_PREFIX . "option_value WHERE option_id = '" . (int)$option_id . "'");
    $this->db->query("DELETE FROM " . DB_PREFIX . "option_value_description WHERE option_id = '" . (int)$option_id . "'");

    if (isset($data['option_value'])) {
      foreach ($data['option_value'] as $option_value) {
        if ($option_value['option_value_id']) {
          $this->db->query("INSERT INTO " . DB_PREFIX . "option_value SET option_value_id = '" . (int)$option_value['option_value_id'] . "', option_id = '" . (int)$option_id . "', image = '" . $this->db->escape(html_entity_decode($option_value['image'], ENT_QUOTES, 'UTF-8')) . "', sort_order = '" . (int)$option_value['sort_order'] . "'");
        } else {
          $this->db->query("INSERT INTO " . DB_PREFIX . "option_value SET option_id = '" . (int)$option_id . "', image = '" . $this->db->escape(html_entity_decode($option_value['image'], ENT_QUOTES, 'UTF-8')) . "', sort_order = '" . (int)$option_value['sort_order'] . "'");
        }

        $option_value_id = $this->db->getLastId();

        foreach ($option_value['option_value_description'] as $language_id => $option_value_description) {
          $this->db->query("INSERT INTO " . DB_PREFIX . "option_value_description SET option_value_id = '" . (int)$option_value_id . "', language_id = '" . (int)$language_id . "', option_id = '" . (int)$option_id . "', name = '" . $this->db->escape($option_value_description['name']) . "'");
        }

     //Hotel Custom
      if($option_id == $this->config->get('wk_hotelbookingopt_optionid')){
        $this->db->query("INSERT " . DB_PREFIX . "wk_hotel_facility SET facility_name = '".$this->db->escape($option_value['option_value_description'][$this->config->get('config_language_id')]['name'])."', facility_image=  '".$this->db->escape($option_value['image'])."',status= '".(int)$option_value['status']."',sort_order='".(int)$option_value['sort_order']."',facility_type = '2',facility_ocid ='".(int)$option_value_id."',owner = '".(int)$option_value['owner']."'");
      }
      //Hotel custom


      }

    }
  }
  public function getOrderOptions($order_id, $order_product_id) {
    $query = $this->db->query("SELECT oo.*,po.option_id FROM " . DB_PREFIX . "order_option oo LEFT JOIN ".DB_PREFIX."product_option po ON (oo.product_option_id=po.product_option_id) WHERE oo.order_id = '" . (int)$order_id . "' AND oo.order_product_id = '" . (int)$order_product_id . "'");

    return $query->rows;
  }
  public function getStatus($order_id){
    return $this->db->query("SELECT ws.status FROM ".DB_PREFIX."wk_booking_slots ws LEFT JOIN ".DB_PREFIX."wk_hotel_room wr ON(wr.product_id=ws.product_id) WHERE order_id = '".(int)$order_id."' AND wr.owner='".(int)$this->customer->getId()."'")->row;
  }

  public function getTotalBookings($start_date,$last_Date, $date = ''){
   $bookedSlots= $this->db->query("SELECT ws.*,pd.name FROM ".DB_PREFIX."wk_booking_slots ws LEFT JOIN ".DB_PREFIX."customerpartner_to_product cp ON(ws.product_id = cp.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON (cp.product_id=pd.product_id) WHERE NOT(( DATE(ws.start_day) < '".$this->db->escape($last_Date)."' AND DATE(ws.end_day) < '".$this->db->escape($start_date)."') OR (DATE(ws.start_day) > '".$this->db->escape($last_Date)."' AND DATE(ws.end_day) > '".$this->db->escape($start_date)."')) AND ws.status=1 AND cp.customer_id = '".(int)$this->customer->getId()."' AND pd.language_id = '".(int)$this->config->get('config_language_id')."'")->rows;
     return $bookedSlots;
  }
}
 ?>
