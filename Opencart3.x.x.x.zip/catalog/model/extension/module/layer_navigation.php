<?php
class ModelExtensionModuleLayerNavigation extends Model {
	/**
	 * [getHotelFromcity nearest hotel according to searched city latitude and longitude]
	 * @param  [float] $latitude  [latitude value of search city]
	 * @param  [float] $longitude [longitude of search city]
	 * @return [array]            [details of hotels according to distance]
	 */
	public function getHotelFromcity($latitude,$longitude,$category_id,$filter = array(),$total=false){
		//  Hotel/Category Details and product details
		$sql = "SELECT DISTINCT whd.category_id,whd.status as hotel_status, whd.address, whd.email, whd.latitude, whd.longitude, whd.website, whd.checkin, whd.checkin_ap, whd.checkout, whd.checkout_ap , c.image,cd.name,cd.description, SQRT(POW(69.1 * (latitude - ".$latitude."), 2) + POW(69.1 * (".$longitude." - longitude) * COS(latitude/57.3), 2)) AS distance,GROUP_CONCAT(DISTINCT p.product_id SEPARATOR ', ') as room_id";

		//Join product and room table

		$sql .= " FROM " . DB_PREFIX . "product p LEFT JOIN ".DB_PREFIX."wk_hotel_room wr ON(wr.product_id = p.product_id)";

		//Join product and category table for hotel description

		$sql .= " LEFT JOIN ".DB_PREFIX."product_to_category p2c ON (p2c.product_id=p.product_id)";

		//Join producttocategory from category and category description
		$sql .= " LEFT JOIN ".DB_PREFIX."category c ON (p2c.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (c.category_id=cd.category_id)";

		//Join category and hotel details for hotel information
		$sql .= " LEFT JOIN ".DB_PREFIX."wk_hotel_details whd ON (c.category_id=whd.category_id)
		";

		if(isset($filter['attr']) && $filter['attr']) {
			$attr_string='';
			$attr_counter = 0;
			$attributes = explode('_',$filter['attr']);
			foreach ($attributes as $key => $value) {
				if($value) {
					$attr_string.= $value.',';
					$attr_counter++;
				}
			}

			if($attr_string) {
				$attr_string = rtrim($attr_string,',');
				// $sql.= " LEFT JOIN ".DB_PREFIX."product_attribute pa ON (pa.product_id=p.product_id)
				// ";
			}
		}

		if(isset($filter['option_value']) && $filter['option_value']) {
			$op_string='';
			$op_counter = 0;
			$optionss = explode('_',$filter['option_value']);
			foreach ($optionss as $key => $value) {
				if($value) {
					$op_string.= $value.',';
					$op_counter++;
				}
			}

			if($op_string) {
				$op_string = rtrim($op_string,',');
				// $sql.= " LEFT JOIN ".DB_PREFIX."product_option_value pov ON (pov.product_id=p.product_id)
				// ";
			}
		}

		$sql.=" WHERE whd.category_id is NOT NULL AND wr.product_id is NOT NULL AND whd.category_id != ".(int)$this->config->get('wk_hotelbookingcat_categoryid')." AND cd.language_id = '".(int)$this->config->get('config_language_id')."' AND whd.status = 1";
		if((int)$this->config->get('module_wk_hotelbooking_res_range')) {
			$sql.= " AND  SQRT(POW(69.1 * (latitude - ".$latitude."), 2) + POW(69.1 * (".$longitude." - longitude) * COS(latitude/57.3), 2))  <= '".(int)$this->config->get('module_wk_hotelbooking_res_range')."'";
		}
		if(isset($filter['checkintime']) && $filter['checkintime']) {
			$sql.= " AND wr.start_from <= '".$this->db->escape($filter['checkouttime'])."' AND wr.till>='".$this->db->escape($filter['checkouttime'])."' AND  wr.start_from <= '".$this->db->escape($filter['checkintime'])."' AND wr.till>='".$this->db->escape($filter['checkintime'])."'";
		}
		if(isset($filter['adult']) && $filter['adult']) {
			$sql.= " AND wr.max_adult >= '".(int)$filter['adult']."'";
		}
		if(isset($filter['child']) && $filter['child']) {
			$sql.= " AND wr.max_child <= '".(int)$filter['child']."'";
		}
		if(isset($filter['room']) && $filter['room']) {
			$sql.= " AND p.quantity >= '".(int)$filter['room']."'";
		}

		$sql.= " AND p.price <= '".(float)$filter['max']."' AND p.price>='".(float)$filter['min']."'";
		$flag =1;

		if (isset($op_string) && isset($attr_string) && $op_string && $attr_string) {
			$flag=0;
			$sql.= "AND p.product_id IN (SELECT pov.product_id FROM ".DB_PREFIX."product_option_value pov WHERE pov.option_value_id IN(".$op_string.") GROUP BY pov.product_id HAVING count(pov.option_value_id)=".$op_counter.") AND p.product_id IN (SELECT pa.product_id FROM ".DB_PREFIX."product_attribute pa WHERE pa.attribute_id IN(".$attr_string.") GROUP BY pa.product_id HAVING count(pa.attribute_id)=".$attr_counter.")  GROUP BY whd.category_id" ;

		} elseif (isset($op_string) && $op_string) {
			$flag=0;
			$sql.= " AND p.product_id IN (SELECT pov.product_id FROM ".DB_PREFIX."product_option_value pov WHERE pov.option_value_id IN(".$op_string.") GROUP BY pov.product_id HAVING count(pov.option_value_id)=".$op_counter.") GROUP BY whd.category_id";

		} elseif (isset($attr_string) && $attr_string) {
			$flag=0;
			$sql.= " AND p.product_id IN (SELECT pa.product_id FROM ".DB_PREFIX."product_attribute pa WHERE pa.attribute_id IN(".$attr_string.") GROUP BY pa.product_id HAVING count(pa.attribute_id)=".$attr_counter.") GROUP BY whd.category_id";
		}

		if($flag) {
			$sql.=" GROUP BY whd.category_id";
		}

		if($category_id && $category_id!=$this->config->get('wk_hotelbookingcat_categoryid')) {
			$sql .= " ORDER BY c.category_id='".(int)$category_id."' DESC";
		} elseif (isset($filter['sort']) && $filter['sort']) {
			$sql .= " ORDER BY " . $filter['sort']." ".$filter['order'];
		} else {
			$sql .= " ORDER BY distance" ;
		}
		if (isset($filter['start']) && !$total) {
			if ($filter['start'] < 0) {
				$filter['start'] = 0;
			}

			$sql .= " LIMIT " . (int)$filter['start'] . ",5";
		}
		$results = $this->db->query($sql)->rows;
		return $results;
 }
 public function getHotel($category_id){
	 $sql = "SELECT whd.* ,c.image,cd.name,cd.description FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND whd.status=1 AND cd.category_id = '".(int)$category_id."'";

	 $result = $this->db->query($sql)->row;
	 return $result;
}
public function getHotelbyName($city){
	$sql = "SELECT whd.* FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND whd.status=1 AND cd.name = '".$this->db->escape($city)."'";

	 $result = $this->db->query($sql)->row;
	 return $result;
 }
}
?>
