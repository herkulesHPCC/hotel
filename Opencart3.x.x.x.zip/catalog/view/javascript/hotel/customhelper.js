Handlebars.registerHelper('ifeven', function(value, options) {
  if (value % 2) {
    return options.fn(this);;
  } else {
    return options.inverse(this);
  }
});
Handlebars.registerHelper('ifCond', function(v1, v2, options) {
  if(v1 === v2) {
    return options.fn(this);
  }
  return options.inverse(this);
});
Handlebars.registerHelper('ifLess', function(v1, v2, options) {
  if(v1 < v2) {
    return options.fn(this);
  }
  return options.inverse(this);
});
Handlebars.registerHelper('count', function(n, block) {
    var accum = '';
    for(var i = 1; i <= n; ++i)
        accum += block.fn(i);
    return accum;
});
