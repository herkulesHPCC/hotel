$('.increase').on('click',function() {
  $(this).parent().next().val(parseInt($(this).parent().next().val())+1);
})
$('.decrease').on('click',function() {
  if($(this).parent().prev().val() > 0)
    $(this).parent().prev().val(parseInt($(this).parent().prev().val())-1);
})
